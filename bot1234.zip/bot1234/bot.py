#!/usr/bin/env python3
"""
╔═══════════════════════════════════════════════════════════╗
║             GHOST VPS BOT — DOCKER EDITION               ║
║        Full Docker VPS Management for Discord            ║
║                  Run: python3 bot.py                     ║
╚═══════════════════════════════════════════════════════════╝
"""

# ──────────────────────────────────────────────────────────
#  IMPORTS
# ──────────────────────────────────────────────────────────
import discord
from discord.ext import commands, tasks
import asyncio
import json
import os
import sys
import time
import psutil
import random
import string
import shutil
import tempfile
import glob
import platform
from datetime import datetime, timedelta, timezone
from tinydb import TinyDB, Query
import config

# ──────────────────────────────────────────────────────────
#  DATABASE  (all stored in ./data/)
# ──────────────────────────────────────────────────────────
os.makedirs("data", exist_ok=True)
os.makedirs("backups", exist_ok=True)

_vps_db      = TinyDB("data/vps.json")
_guild_db    = TinyDB("data/guild.json")
_invites_db  = TinyDB("data/invites.json")
_bans_db     = TinyDB("data/bans.json")
_tickets_db  = TinyDB("data/tickets.json")
_warns_db    = TinyDB("data/warnings.json")
_settings_db = TinyDB("data/settings.json")

vps_tbl      = _vps_db.table("vps")
guild_tbl    = _guild_db.table("guild")
inv_tbl      = _invites_db.table("invites")
invited_tbl  = _invites_db.table("invited")
bans_tbl     = _bans_db.table("bans")
tickets_tbl  = _tickets_db.table("tickets")
warns_tbl    = _warns_db.table("warnings")
settings_tbl = _settings_db.table("settings")

Q          = Query()
START_TIME = time.time()
inv_cache: dict = {}   # guild_id -> list[discord.Invite]

# ──────────────────────────────────────────────────────────
#  HELPERS
# ──────────────────────────────────────────────────────────
def gen_id(n: int = 6) -> str:
    return "".join(random.choices(string.ascii_lowercase + string.digits, k=n))

def fmt_uptime(seconds: float) -> str:
    d, r = divmod(int(seconds), 86400)
    h, r = divmod(r, 3600)
    m, s = divmod(r, 60)
    return f"{d}d {h}h {m}m {s}s"

def safe_name(text: str, maxlen: int = 16) -> str:
    return "".join(c for c in text.lower() if c.isalnum())[:maxlen] or gen_id(6)

def is_admin(ctx) -> bool:
    uid = ctx.author.id if hasattr(ctx, "author") else ctx.id
    return uid in config.ADMIN_IDS

def is_banned(user_id) -> bool:
    return bans_tbl.contains(Q.user_id == str(user_id))

def get_ban(user_id) -> dict:
    return bans_tbl.get(Q.user_id == str(user_id)) or {}

def is_suspended(user_id) -> bool:
    return settings_tbl.contains((Q.type == "suspension") & (Q.user_id == str(user_id)))

def get_valid_invites(user_id) -> int:
    d = inv_tbl.get(Q.user_id == str(user_id)) or {}
    return max(0, d.get("valid", 0) + d.get("manual", 0) - d.get("leaves", 0))

def get_guild_cfg(guild_id) -> dict:
    g   = str(guild_id)
    cfg = guild_tbl.get(Q.guild_id == g)
    if not cfg:
        cfg = {
            "guild_id":        g,
            "prefix":          config.PREFIX,
            "log_channel":     None,
            "ticket_channel":  None,
            "announce_channel":None,
            "free_enabled":    True,
            "maintenance":     False,
            "vps_type":        "docker",
            "setup_done":      False,
        }
        guild_tbl.insert(cfg)
    return cfg

def upd_guild_cfg(guild_id, updates: dict):
    cfg = get_guild_cfg(guild_id)
    cfg.update(updates)
    guild_tbl.upsert(cfg, Q.guild_id == str(guild_id))

async def shell(cmd: str):
    """Run a shell command, return (stdout, stderr, returncode)."""
    p = await asyncio.create_subprocess_shell(
        cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    out, err = await p.communicate()
    return out.decode().strip(), err.decode().strip(), p.returncode

async def log(guild, title: str, desc: str, color: int = 0x5865F2):
    """Send embed to the guild log channel."""
    if not guild: return
    cfg = get_guild_cfg(guild.id)
    cid = cfg.get("log_channel") or (config.LOG_CHANNEL)
    if not cid: return
    ch = guild.get_channel(int(cid))
    if not ch: return
    e = discord.Embed(title=title, description=desc, color=color,
                      timestamp=datetime.now(timezone.utc))
    e.set_footer(text="Ghost VPS Bot • Log")
    try: await ch.send(embed=e)
    except Exception: pass

# ──────────────────────────────────────────────────────────
#  DOCKER HELPERS
# ──────────────────────────────────────────────────────────
async def docker_running(name: str) -> bool:
    out, _, _ = await shell(f"docker inspect -f '{{{{.State.Running}}}}' {name} 2>/dev/null")
    return out.strip() == "true"

async def docker_status(name: str) -> str:
    out, _, _ = await shell(f"docker inspect -f '{{{{.State.Status}}}}' {name} 2>/dev/null")
    return out.strip() or "unknown"

async def get_links(name: str):
    """Get tmate SSH + sshx link from a running container."""
    t_raw, _, _ = await shell(
        f"docker exec {name} grep 'ssh session: ssh' /root/tmate.log 2>/dev/null | tail -1")
    s_raw, _, _ = await shell(
        f"docker exec {name} grep -o 'https://sshx.io[^ ]*' /root/sshx.log 2>/dev/null | tail -1")
    tmate = ""
    if "ssh session: ssh" in t_raw:
        tmate = t_raw.split("ssh session: ")[1].strip()
    sshx = s_raw.strip()
    return tmate, sshx

async def wait_links(name: str, timeout: int = 120):
    """Poll for tmate/sshx links until they appear."""
    for _ in range(timeout // 4):
        t, s = await get_links(name)
        if t or s:
            return t, s
        await asyncio.sleep(4)
    return "", ""

# ── Setup script that runs INSIDE the container ────────────
# Uses nohup + sleep so it works even without systemd/init
SETUP_SCRIPT = r"""
export DEBIAN_FRONTEND=noninteractive
mkdir -p /root /var/run/sshd
apt-get update -qq 2>/dev/null
apt-get install -y -qq curl wget sudo tmate openssh-server screen htop 2>/dev/null
# Start SSH
/usr/sbin/sshd -D &
# Start tmate and capture link
nohup tmate -S /tmp/tmate.sock new-session -d >> /root/tmate.log 2>&1 &
sleep 10
tmate -S /tmp/tmate.sock display -p '#{tmate_ssh}' >> /root/tmate.log 2>&1
# Start sshx
nohup sh -c 'curl -sSf https://sshx.io/get | sh -s run >> /root/sshx.log 2>&1' &
echo "SETUP_DONE"
"""

async def create_docker_vps(cname: str, image: str, ram: str, cpus: str) -> None:
    """
    Create and configure a Docker VPS container.
    LXC-compatible: no --cap-add SYS_ADMIN, no cgroup mounts.
    Uses --security-opt seccomp=unconfined to bypass LXC sysctl restrictions.
    """
    # Step 1 — pull image
    pull_out, pull_err, pull_rc = await shell(f"docker pull {image}")
    if pull_rc != 0:
        raise RuntimeError(f"Failed to pull image `{image}`:\n{pull_err}")

    # Step 2 — create container (LXC-safe flags only)
    cmd = (
        f"docker run -d --name {cname} "
        f"--network {config.DOCKER_NETWORK} "
        f"--memory {ram} --cpus {cpus} "
        f"--restart {config.DOCKER_RESTART} "
        # ↓ These two replace --cap-add SYS_ADMIN and work inside LXC
        f"--security-opt seccomp=unconfined "
        f"--security-opt apparmor=unconfined "
        f"--ulimit nofile=1024:1024 "
        f"{image} /bin/sh -c 'tail -f /dev/null'"
    )
    _, err, rc = await shell(cmd)
    if rc != 0:
        # Fallback: try even simpler flags in case seccomp is also blocked
        cmd_fallback = (
            f"docker run -d --name {cname} "
            f"--network {config.DOCKER_NETWORK} "
            f"--memory {ram} --cpus {cpus} "
            f"--restart {config.DOCKER_RESTART} "
            f"{image} /bin/sh -c 'tail -f /dev/null'"
        )
        _, err2, rc2 = await shell(cmd_fallback)
        if rc2 != 0:
            raise RuntimeError(
                f"Docker run failed (both attempts):\n"
                f"Attempt 1: {err}\n"
                f"Attempt 2: {err2}\n\n"
                f"💡 Fix for LXC hosts: Run on the **host** (outside LXC):\n"
                f"   echo 'lxc.apparmor.profile = unconfined' >> /etc/pve/lxc/<ID>.conf\n"
                f"   echo 'lxc.cap.drop =' >> /etc/pve/lxc/<ID>.conf"
            )

    # Step 3 — wait for container to be ready
    await asyncio.sleep(4)

    # Step 4 — check which shell is available (alpine uses ash, not bash)
    _, _, bash_rc = await shell(f"docker exec {cname} which bash")
    shell_bin = "bash" if bash_rc == 0 else "sh"

    # Step 5 — install tools and start tmate/sshx
    # Write setup script to a temp file then copy it in (avoids quoting hell)
    with tempfile.NamedTemporaryFile(mode="w", suffix=".sh", delete=False) as f:
        f.write(SETUP_SCRIPT)
        tmp_path = f.name
    try:
        await shell(f"docker cp {tmp_path} {cname}:/root/_setup.sh")
    finally:
        os.unlink(tmp_path)

    # Run setup non-blocking (don't wait for tmate/sshx — wait_links() polls later)
    await shell(f"docker exec -d {cname} {shell_bin} /root/_setup.sh")

# ──────────────────────────────────────────────────────────
#  OS WIZARD LIST
# ──────────────────────────────────────────────────────────
OS_LIST = [
    "ubuntu:24.04",
    "ubuntu:22.04",
    "ubuntu:20.04",
    "debian:12",
    "debian:11",
    "alpine:3.19",
    "centos:7",
    "fedora:40",
    "archlinux",
    "rockylinux:9",
    "kalilinux/kali-rolling",
]

async def run_wizard(ctx) -> dict | None:
    """Asks admin a step-by-step setup for a new VPS. Returns params dict or None on timeout."""
    def chk(m): return m.author == ctx.author and m.channel == ctx.channel

    async def q(embed):
        await ctx.send(embed=embed)
        try:
            m = await bot.wait_for("message", check=chk, timeout=90)
            return m.content.strip()
        except asyncio.TimeoutError:
            await ctx.send(embed=discord.Embed(description="⏱ Setup timed out.", color=0xed4245))
            return None

    # ── Step 1: OS ──
    os_txt = "\n".join(f"`{i+1}` {o}" for i, o in enumerate(OS_LIST))
    raw = await q(discord.Embed(
        title="⚙️ Step 1 / 5 — Operating System",
        description=f"{os_txt}\n\nType the **number**:", color=0x5865f2))
    if raw is None: return None
    try:    image = OS_LIST[int(raw) - 1]
    except: image = "ubuntu:24.04"

    # ── Step 2: RAM ──
    raw = await q(discord.Embed(title="Step 2 / 5 — RAM",
        description="Enter RAM (e.g. `512m`, `1g`, `2g`, `4g`):", color=0x5865f2))
    if raw is None: return None
    ram = raw.lower()
    if not (ram.endswith("m") or ram.endswith("g")): ram += "g"

    # ── Step 3: CPU ──
    raw = await q(discord.Embed(title="Step 3 / 5 — CPU Cores",
        description="Enter CPU cores (e.g. `1`, `2`, `4`):", color=0x5865f2))
    if raw is None: return None
    try:    cpus = str(max(1, min(int(raw), 64)))
    except: cpus = "1"

    # ── Step 4: Storage ──
    raw = await q(discord.Embed(title="Step 4 / 5 — Storage Note",
        description="Enter storage size (e.g. `10GB`) — this is **displayed only** (Docker uses host disk):",
        color=0x5865f2))
    if raw is None: return None
    storage = (raw.upper() + "GB") if not raw.upper().endswith("GB") else raw.upper()

    # ── Step 5: Container name ──
    raw = await q(discord.Embed(title="Step 5 / 5 — VPS Name",
        description="Enter a short name for this VPS (letters/numbers only, max 16):", color=0x5865f2))
    if raw is None: return None
    name = safe_name(raw)

    return {"image": image, "ram": ram, "cpus": cpus, "storage": storage, "name": name}

# ──────────────────────────────────────────────────────────
#  PERSISTENT VIEWS
# ──────────────────────────────────────────────────────────
class VPSPanel(discord.ui.View):
    """DM control panel for a VPS owner."""
    def __init__(self, vps_id: str = "placeholder"):
        super().__init__(timeout=None)
        self.vps_id = vps_id

    def _rec(self):
        return vps_tbl.get(Q.vps_id == self.vps_id)

    @discord.ui.button(label="▶ Start",   emoji="🟢", style=discord.ButtonStyle.success,   custom_id="vp_start")
    async def btn_start(self, interaction: discord.Interaction, _):
        await interaction.response.defer(ephemeral=True)
        r = self._rec()
        if not r: return await interaction.followup.send("❌ VPS record not found.", ephemeral=True)
        n = r["cname"]
        if await docker_running(n):
            msg = await interaction.followup.send(embed=discord.Embed(
                description="⚠️ The VPS is **already running**!", color=0xfee75c), ephemeral=True)
            await asyncio.sleep(10)
            try: await msg.delete()
            except: pass
            return
        await shell(f"docker start {n}")
        await interaction.followup.send(embed=discord.Embed(
            description=f"✅ VPS `{n}` is starting...", color=0x57f287), ephemeral=True)

    @discord.ui.button(label="⏹ Stop",    emoji="🔴", style=discord.ButtonStyle.danger,    custom_id="vp_stop")
    async def btn_stop(self, interaction: discord.Interaction, _):
        await interaction.response.defer(ephemeral=True)
        r = self._rec()
        if not r: return await interaction.followup.send("❌ VPS not found.", ephemeral=True)
        msg = await interaction.followup.send(embed=discord.Embed(
            description="🛑 The VPS is stopping . . .", color=0xed4245), ephemeral=True)
        await shell(f"docker stop {r['cname']}")
        await asyncio.sleep(10)
        try: await msg.delete()
        except: pass

    @discord.ui.button(label="🔄 Restart", emoji="🔄", style=discord.ButtonStyle.secondary, custom_id="vp_restart")
    async def btn_restart(self, interaction: discord.Interaction, _):
        await interaction.response.defer(ephemeral=True)
        r = self._rec()
        if not r: return await interaction.followup.send("❌ VPS not found.", ephemeral=True)
        await shell(f"docker restart {r['cname']}")
        await interaction.followup.send(embed=discord.Embed(
            description="🔄 VPS restarted!", color=0x57f287), ephemeral=True)

    @discord.ui.button(label="📊 Refresh", emoji="📊", style=discord.ButtonStyle.secondary, custom_id="vp_refresh")
    async def btn_refresh(self, interaction: discord.Interaction, _):
        await interaction.response.defer(ephemeral=True)
        r = self._rec()
        if not r: return await interaction.followup.send("❌ VPS not found.", ephemeral=True)
        n      = r["cname"]
        status = await docker_status(n)
        ram    = psutil.virtual_memory()
        disk   = psutil.disk_usage("/")
        # Docker container stats
        st_raw, _, _ = await shell(
            f"docker stats {n} --no-stream --format '{{{{.CPUPerc}}}} {{{{.MemUsage}}}}' 2>/dev/null")
        cpu_use = st_raw.split()[0] if st_raw else "N/A"
        mem_use = " ".join(st_raw.split()[1:]) if st_raw else "N/A"
        dot = "🟢" if status == "running" else "🔴"
        e = discord.Embed(title=f"📊 VPS Status — {n}", color=0x2b2d31)
        e.add_field(name="Status",         value=f"{dot} `{status.upper()}`", inline=True)
        e.add_field(name="CPU Usage",      value=f"`{cpu_use}`",              inline=True)
        e.add_field(name="Container RAM",  value=f"`{mem_use}`",              inline=True)
        e.add_field(name="Node RAM",       value=f"`{ram.percent:.1f}%` used",inline=True)
        e.add_field(name="Node Disk",      value=f"`{disk.percent:.1f}%` used",inline=True)
        e.add_field(name="VPS ID",         value=f"`{self.vps_id}`",          inline=True)
        e.set_footer(text=f"OS: {r.get('image','?')} | RAM: {r.get('ram','?')} | CPUs: {r.get('cpus','?')}")
        await interaction.followup.send(embed=e, ephemeral=True)

    @discord.ui.button(label="🖥 SSHX",   emoji="🖥", style=discord.ButtonStyle.primary,   custom_id="vp_sshx")
    async def btn_sshx(self, interaction: discord.Interaction, _):
        await interaction.response.defer(ephemeral=True)
        r = self._rec()
        if not r: return await interaction.followup.send("❌ VPS not found.", ephemeral=True)
        _, sshx = await get_links(r["cname"])
        if sshx:
            await interaction.followup.send(embed=discord.Embed(
                title="🖥 SSHX Link", description=sshx, color=0x5865f2), ephemeral=True)
        else:
            await interaction.followup.send(embed=discord.Embed(
                description="❌ SSHX not ready yet. Is the VPS running?", color=0xed4245), ephemeral=True)

    @discord.ui.button(label="📟 tmate",  emoji="📟", style=discord.ButtonStyle.secondary, custom_id="vp_tmate")
    async def btn_tmate(self, interaction: discord.Interaction, _):
        await interaction.response.defer(ephemeral=True)
        r = self._rec()
        if not r: return await interaction.followup.send("❌ VPS not found.", ephemeral=True)
        tmate, _ = await get_links(r["cname"])
        if tmate:
            await interaction.followup.send(embed=discord.Embed(
                title="📟 tmate SSH", description=f"`{tmate}`", color=0x5865f2), ephemeral=True)
        else:
            await interaction.followup.send(embed=discord.Embed(
                description="❌ tmate not ready yet. Is the VPS running?", color=0xed4245), ephemeral=True)


class TicketPanel(discord.ui.View):
    """Ticket management panel — admins only."""
    def __init__(self):
        super().__init__(timeout=None)

    def _admin(self, user): return user.id in config.ADMIN_IDS

    @discord.ui.button(label="🔒 Lock",   style=discord.ButtonStyle.secondary, custom_id="tk_lock")
    async def btn_lock(self, i: discord.Interaction, _):
        if not self._admin(i.user):
            return await i.response.send_message("❌ Admins only.", ephemeral=True)
        tk = tickets_tbl.get(Q.channel_id == str(i.channel.id))
        if tk:
            m = i.guild.get_member(int(tk["user_id"]))
            if m: await i.channel.set_permissions(m, send_messages=False)
        await i.response.send_message(embed=discord.Embed(
            description="🔒 Ticket **locked**. User cannot type.", color=0xed4245))

    @discord.ui.button(label="🔓 Unlock", style=discord.ButtonStyle.success,   custom_id="tk_unlock")
    async def btn_unlock(self, i: discord.Interaction, _):
        if not self._admin(i.user):
            return await i.response.send_message("❌ Admins only.", ephemeral=True)
        tk = tickets_tbl.get(Q.channel_id == str(i.channel.id))
        if tk:
            m = i.guild.get_member(int(tk["user_id"]))
            if m: await i.channel.set_permissions(m, send_messages=True)
        await i.response.send_message(embed=discord.Embed(
            description="🔓 Ticket **unlocked**.", color=0x57f287))

    @discord.ui.button(label="✋ Claim",  style=discord.ButtonStyle.primary,   custom_id="tk_claim")
    async def btn_claim(self, i: discord.Interaction, _):
        if not self._admin(i.user):
            return await i.response.send_message("❌ Admins only.", ephemeral=True)
        tickets_tbl.update({"claimed_by": str(i.user.id)},
                           Q.channel_id == str(i.channel.id))
        await i.response.send_message(embed=discord.Embed(
            description=f"✋ Claimed by {i.user.mention}.", color=0x5865f2))

    @discord.ui.button(label="🗑 Delete", style=discord.ButtonStyle.danger,    custom_id="tk_delete")
    async def btn_delete(self, i: discord.Interaction, _):
        if not self._admin(i.user):
            return await i.response.send_message("❌ Admins only.", ephemeral=True)
        await i.response.send_message(embed=discord.Embed(
            description="🗑 Deleting ticket in **5 seconds**...", color=0xed4245))
        tickets_tbl.remove(Q.channel_id == str(i.channel.id))
        await asyncio.sleep(5)
        try: await i.channel.delete()
        except: pass


class OpenTicketView(discord.ui.View):
    """Panel posted in the tickets channel."""
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="🎫 Open a Ticket", style=discord.ButtonStyle.success,
                       emoji="📩", custom_id="openticket")
    async def btn_open(self, interaction: discord.Interaction, _):
        user  = interaction.user
        guild = interaction.guild
        if is_banned(user.id):
            bi = get_ban(user.id)
            return await interaction.response.send_message(embed=discord.Embed(
                title="🚫 You Are Banned",
                description=f"You cannot open tickets.\n**Reason:** {bi.get('reason','No reason given.')}",
                color=0xed4245), ephemeral=True)
        existing = tickets_tbl.get(
            (Q.guild_id == str(guild.id)) & (Q.user_id == str(user.id)) & (Q.status == "open"))
        if existing:
            ch = guild.get_channel(int(existing["channel_id"]))
            if ch:
                return await interaction.response.send_message(
                    f"❌ You already have a ticket open: {ch.mention}", ephemeral=True)
        await interaction.response.defer(ephemeral=True)
        ow = {
            guild.default_role: discord.PermissionOverwrite(read_messages=False),
            user:               discord.PermissionOverwrite(read_messages=True, send_messages=True),
            guild.me:           discord.PermissionOverwrite(read_messages=True, send_messages=True,
                                                            manage_channels=True),
        }
        for aid in config.ADMIN_IDS:
            m = guild.get_member(aid)
            if m:
                ow[m] = discord.PermissionOverwrite(read_messages=True, send_messages=True, manage_channels=True)
        try:
            ch = await guild.create_text_channel(
                f"ticket-{user.name[:10].lower()}-{gen_id(4)}",
                overwrites=ow,
                topic=f"Support ticket for {user} ({user.id})")
        except Exception as e:
            return await interaction.followup.send(f"❌ Could not create channel: {e}", ephemeral=True)
        tickets_tbl.insert({
            "guild_id":   str(guild.id), "channel_id": str(ch.id),
            "user_id":    str(user.id),  "status": "open",
            "claimed_by": None, "created_at": datetime.now().isoformat()
        })
        embed = discord.Embed(
            title="🎫 Ticket Opened",
            description=f"Welcome {user.mention}!\nOur staff will assist you shortly.\n\n"
                        f"**Opened by:** {user.mention} (`{user.id}`)",
            color=0x5865f2, timestamp=datetime.now(timezone.utc))
        await ch.send(embed=embed, view=TicketPanel())
        # Auto-detect pending VPS reward
        inv_data = inv_tbl.get(Q.user_id == str(user.id))
        if inv_data and inv_data.get("pending_vps"):
            asyncio.create_task(_deliver_tier_vps(ch, user, guild))
            inv_data["pending_vps"] = False
            inv_tbl.upsert(inv_data, Q.user_id == str(user.id))
        await interaction.followup.send(f"✅ Ticket created: {ch.mention}", ephemeral=True)
        await log(guild, "🎫 Ticket Opened",
                  f"**User:** {user.mention}\n**Channel:** {ch.mention}", 0x5865f2)


async def _deliver_tier_vps(channel, user, guild):
    """Run inside a ticket to auto-configure VPS for invite-reward recipients."""
    valid    = get_valid_invites(user.id)
    tier_key = None
    tier_inf = None
    for k, t in sorted(config.TIERS.items(), key=lambda x: x[1]["invites"], reverse=True):
        if valid >= t["invites"]:
            tier_key = k
            tier_inf = t
            break
    if not tier_inf:
        return

    await channel.send(embed=discord.Embed(
        title="🎉 VPS Reward!",
        description=(f"You've earned a **{tier_inf['name']}** VPS for your invites!\n"
                     f"Answer the questions below to set it up."),
        color=0x57f287))

    def chk(m): return m.author == user and m.channel == channel

    async def ask(prompt):
        await channel.send(embed=discord.Embed(description=prompt, color=0x5865f2))
        try:
            m = await bot.wait_for("message", check=chk, timeout=120)
            return m.content.strip()
        except asyncio.TimeoutError:
            return None

    os_txt = "\n".join(f"`{i+1}` {o}" for i, o in enumerate(OS_LIST))
    raw    = await ask(f"**Choose your OS:**\n{os_txt}\n\nType the number:")
    try:    image = OS_LIST[int(raw) - 1]
    except: image = tier_inf.get("image", "ubuntu:24.04")

    vid   = gen_id()
    clean = safe_name(user.name)
    cname = f"vps-{clean}-{vid}"
    msg   = await channel.send(embed=discord.Embed(
        title="🚀 Creating your VPS...",
        description=(f"OS: `{image}` | RAM: `{tier_inf['ram']}` | "
                     f"CPUs: `{tier_inf['cpus']}` | Storage: `{tier_inf['storage']}`"),
        color=0xfee75c))
    try:
        await create_docker_vps(cname, image, tier_inf["ram"], tier_inf["cpus"])
        tmate, sshx = await wait_links(cname)
        vps_tbl.insert({
            "owner_id": str(user.id), "vps_id": vid, "cname": cname,
            "image": image, "ram": tier_inf["ram"], "cpus": tier_inf["cpus"],
            "storage": tier_inf["storage"], "tier": tier_key,
            "created_at": datetime.now().isoformat(),
        })
        ok = discord.Embed(title="✅ VPS Ready!", color=0x57f287)
        ok.add_field(name="Container", value=f"`{cname}`",             inline=True)
        ok.add_field(name="VPS ID",    value=f"`{vid}`",               inline=True)
        ok.add_field(name="OS",        value=f"`{image}`",             inline=True)
        ok.add_field(name="RAM",       value=f"`{tier_inf['ram']}`",   inline=True)
        ok.add_field(name="CPUs",      value=f"`{tier_inf['cpus']}`",  inline=True)
        ok.add_field(name="Storage",   value=f"`{tier_inf['storage']}`",inline=True)
        if tmate: ok.add_field(name="📟 tmate SSH", value=f"`{tmate}`", inline=False)
        if sshx:  ok.add_field(name="🖥 SSHX Web",  value=sshx,        inline=False)
        await msg.edit(embed=ok)
        try:
            dm = discord.Embed(
                title="🖥 Your VPS Control Panel",
                description=f"**VPS ID:** `{vid}`\n**Container:** `{cname}`",
                color=0x5865f2)
            await user.send(embed=dm, view=VPSPanel(vid))
        except Exception:
            await channel.send(embed=discord.Embed(
                description="⚠️ Couldn't DM you the panel. Please enable DMs!", color=0xfee75c))
        await log(guild, "🎉 VPS Reward Delivered",
                  f"**User:** {user.mention}\n**Container:** `{cname}`\n"
                  f"**Tier:** {tier_inf['name']}", 0x57f287)
    except Exception as e:
        await msg.edit(embed=discord.Embed(
            title="❌ VPS Creation Failed", description=str(e)[:1800], color=0xed4245))

# ──────────────────────────────────────────────────────────
#  BOT SETUP
# ──────────────────────────────────────────────────────────
intents = discord.Intents.all()

def get_prefix(bot_, msg):
    if msg.guild:
        cfg = get_guild_cfg(msg.guild.id)
        return [cfg.get("prefix", config.PREFIX)]
    return [config.PREFIX]

bot = commands.Bot(command_prefix=get_prefix, intents=intents, help_command=None)

def admin_only():
    async def pred(ctx):
        if ctx.author.id not in config.ADMIN_IDS:
            await ctx.send(embed=discord.Embed(
                description="🚫 This command is **admin only**.", color=0xed4245), delete_after=6)
            return False
        return True
    return commands.check(pred)

# ──────────────────────────────────────────────────────────
#  EVENTS
# ──────────────────────────────────────────────────────────
@bot.event
async def on_ready():
    print("=" * 52)
    print(f"  ✅  {bot.user.name} is ONLINE")
    print(f"  🆔  ID      : {bot.user.id}")
    print(f"  🏠  Guilds  : {len(bot.guilds)}")
    print(f"  ⚡  Prefix  : {config.PREFIX}")
    print("=" * 52)
    for g in bot.guilds:
        try: inv_cache[g.id] = await g.invites()
        except: pass
    await bot.change_presence(
        activity=discord.Activity(type=discord.ActivityType.watching, name="🐳 Docker VPS"),
        status=discord.Status.online)
    bot.add_view(VPSPanel())
    bot.add_view(TicketPanel())
    bot.add_view(OpenTicketView())
    auto_backup.start()


@bot.event
async def on_guild_join(guild):
    owner = guild.owner
    embed = discord.Embed(
        title="👋 Hello! I'm Ghost VPS Bot 🐳",
        description=(
            f"Thanks for adding me to **{guild.name}**, {owner.mention if owner else 'Owner'}!\n\n"
            "**Get started:**\n"
            "`!setup` — First-time setup wizard\n"
            "`!installcheck` — Verify Docker is installed\n"
            "`!ticketpanel` — Post the ticket panel\n"
            "`!help` — Full command list\n\n"
            "I manage Docker VPS containers right from Discord! 🚀"
        ), color=0x5865f2)
    embed.set_thumbnail(url=bot.user.display_avatar.url)
    try:
        if owner: await owner.send(embed=embed)
    except Exception:
        for ch in guild.text_channels:
            if ch.permissions_for(guild.me).send_messages:
                await ch.send(embed=embed)
                break


@bot.event
async def on_invite_create(inv):
    try: inv_cache[inv.guild.id] = await inv.guild.invites()
    except: pass


@bot.event
async def on_invite_delete(inv):
    try: inv_cache[inv.guild.id] = await inv.guild.invites()
    except: pass


@bot.event
async def on_member_join(member):
    guild    = member.guild
    old_invs = inv_cache.get(guild.id, [])
    try:
        new_invs = await guild.invites()
    except Exception:
        return
    used = None
    for old in old_invs:
        for new in new_invs:
            if old.code == new.code and new.uses > old.uses:
                used = new; break
    inv_cache[guild.id] = new_invs
    if not used or not used.inviter: return

    age_days = (discord.utils.utcnow() - member.created_at).days
    fake = (age_days < config.MIN_ACCOUNT_AGE_DAYS or
            (config.REQUIRE_AVATAR and not member.avatar))

    data = inv_tbl.get(Q.user_id == str(used.inviter.id)) or {
        "user_id": str(used.inviter.id), "valid": 0,
        "fakes": 0, "leaves": 0, "manual": 0, "pending_vps": False
    }
    if fake:
        data["fakes"] = data.get("fakes", 0) + 1
    else:
        data["valid"] = data.get("valid", 0) + 1
        total = data["valid"] + data.get("manual", 0)
        # Tier unlock notification
        cfg = get_guild_cfg(guild.id)
        for k, t in sorted(config.TIERS.items(), key=lambda x: x[1]["invites"], reverse=True):
            if t["invites"] > 0 and total == t["invites"]:
                data["pending_vps"] = True
                try:
                    tk_ch = cfg.get("ticket_channel")
                    mention = f"<#{tk_ch}>" if tk_ch else "the ticket channel"
                    inviter_obj = await bot.fetch_user(int(used.inviter.id))
                    await inviter_obj.send(embed=discord.Embed(
                        title="🎉 VPS Tier Unlocked!",
                        description=(f"You now have **{total} valid invites** and unlocked "
                                     f"a **{t['name']}** VPS!\n\n"
                                     f"Open a ticket in {mention} to claim it! 🚀"),
                        color=0x57f287))
                except Exception: pass
                break
    inv_tbl.upsert(data, Q.user_id == str(used.inviter.id))
    invited_tbl.upsert({
        "member_id": str(member.id), "inviter_id": str(used.inviter.id),
        "fake": fake, "joined_at": datetime.now().isoformat()
    }, Q.member_id == str(member.id))


@bot.event
async def on_member_remove(member):
    rec = invited_tbl.get(Q.member_id == str(member.id))
    if not rec or rec.get("fake"): return
    data = inv_tbl.get(Q.user_id == rec["inviter_id"])
    if data:
        data["leaves"] = data.get("leaves", 0) + 1
        data["valid"]  = max(0, data.get("valid", 0) - 1)
        inv_tbl.upsert(data, Q.user_id == rec["inviter_id"])


@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.CommandNotFound): return
    if isinstance(error, commands.CheckFailure): return
    if isinstance(error, commands.MissingRequiredArgument):
        await ctx.send(embed=discord.Embed(
            description=f"❌ Missing: `{error.param.name}` — see `!help`",
            color=0xed4245), delete_after=8)

# ──────────────────────────────────────────────────────────
#  BACKGROUND TASKS
# ──────────────────────────────────────────────────────────
@tasks.loop(hours=6)
async def auto_backup():
    """Auto backup databases every 6 hours."""
    ts = datetime.now().strftime("%Y%m%d-%H%M")
    for f in ["vps", "guild", "invites", "bans", "tickets", "warnings", "settings"]:
        src = f"data/{f}.json"
        dst = f"backups/{f}-{ts}.json"
        if os.path.exists(src):
            shutil.copy2(src, dst)
    # Keep only last 10 backups per file
    for f in ["vps", "guild", "invites", "bans", "tickets", "warnings", "settings"]:
        files = sorted(glob.glob(f"backups/{f}-*.json"))
        for old in files[:-10]:
            os.remove(old)

# ──────────────────────────────────────────────────────────
#  ██╗   ██╗███████╗███████╗██████╗      ██████╗███╗
#  ██║   ██║██╔════╝██╔════╝██╔══██╗    ██╔════╝████╗
#  ██║   ██║███████╗█████╗  ██████╔╝    ██║     ██╔██╗
#  ██║   ██║╚════██║██╔══╝  ██╔══██╗    ██║     ██║╚██╗
#  ╚██████╔╝███████║███████╗██║  ██║    ╚██████╗██║ ╚██╗
#   ╚═════╝ ╚══════╝╚══════╝╚═╝  ╚═╝    ╚═════╝╚═╝  ╚═╝
#  USER COMMANDS  (anyone can use these)
# ──────────────────────────────────────────────────────────

@bot.command(name="help", aliases=["commands", "cmds", "h"])
async def cmd_help(ctx):
    """Show help menu."""
    adm   = is_admin(ctx)
    color = 0x5865f2
    e     = discord.Embed(title="🐳 Ghost VPS Bot — Help", color=color)
    e.set_thumbnail(url=bot.user.display_avatar.url)
    e.add_field(name="👤 Everyone",
                value=("`!status` — Your VPS status\n"
                       "`!sshx [id]` — Get SSHX link (DM)\n"
                       "`!tmate [id]` — Get tmate link (DM)\n"
                       "`!invites [@user]` — Invite stats\n"
                       "`!topinvites` — Top inviters leaderboard\n"
                       "`!ping` — Bot latency\n"
                       "`!botinfo` — Bot information\n"
                       "`!uptime` — Bot uptime\n"
                       "`!tiers` — View VPS invite tiers"),
                inline=False)
    if adm:
        e.add_field(name="🐳 Docker VPS (Admin)",
                    value=("`!createvps` — Create a Docker VPS (wizard)\n"
                           "`!givevps @user` — Give user a Docker VPS (wizard)\n"
                           "`!deletemyvps [id]` — Delete your own VPS\n"
                           "`!deletesomeonevps @user [id]` — Delete user VPS\n"
                           "`!startvps @user [id]` — Start a user VPS\n"
                           "`!stopvps @user [id]` — Stop a user VPS\n"
                           "`!restartvps @user [id]` — Restart a user VPS\n"
                           "`!rebuildvps @user [id]` — Rebuild a VPS (wipes data)\n"
                           "`!execvps @user <cmd>` — Run command inside VPS\n"
                           "`!renamevps @user <new>` — Rename a VPS label\n"
                           "`!vpsnote @user <note>` — Add note to user VPS"),
                    inline=False)
        e.add_field(name="📋 Listings (Admin)",
                    value=("`!listvps` — List all running VPS\n"
                           "`!listall` — All VPS in database\n"
                           "`!lookup @user` — User VPS list\n"
                           "`!vpsinfo [id]` — Detailed VPS info\n"
                           "`!dockerps` — Raw docker ps output\n"
                           "`!dockerstats` — Live docker stats"),
                    inline=False)
        e.add_field(name="🚫 User Management (Admin)",
                    value=("`!ban @user [reason]` — Ban user (removes VPS + panel)\n"
                           "`!unban @user [reason]` — Unban user\n"
                           "`!banlist` — List all bans\n"
                           "`!suspend @user` — Suspend user\n"
                           "`!unsuspend @user` — Unsuspend user\n"
                           "`!warn @user [reason]` — Issue warning\n"
                           "`!warnings @user` — View user warnings\n"
                           "`!clearwarnings @user` — Clear warnings\n"
                           "`!userinfo @user` — Full user info\n"
                           "`!transfervps @from @to [id]` — Transfer VPS ownership"),
                    inline=False)
        e.add_field(name="📨 Invite Management (Admin)",
                    value=("`!addinvites @user <n>` — Add manual invites\n"
                           "`!removeinvites @user <n>` — Remove invites\n"
                           "`!resetinvites @user` — Reset user invites\n"
                           "`!setminage <days>` — Set fake invite age threshold\n"
                           "`!invitecheck @user` — Full invite audit"),
                    inline=False)
        e.add_field(name="🎫 Ticket System (Admin)",
                    value=("`!ticketpanel` — Post the Open Ticket button\n"
                           "`!closeticket` — Close current ticket\n"
                           "`!listtickets` — All open tickets\n"
                           "`!addtoticket @user` — Add user to ticket\n"
                           "`!removeuser @user` — Remove user from ticket"),
                    inline=False)
        e.add_field(name="⚙️ System & Config (Admin)",
                    value=("`!node` — Node resource usage\n"
                           "`!installcheck` — Check Docker installed\n"
                           "`!setup` — First-time setup wizard\n"
                           "`!setprefix <p>` — Change command prefix\n"
                           "`!setlogs #channel` — Set log channel\n"
                           "`!setticket #channel` — Set ticket category\n"
                           "`!setannounce #channel` — Set announce channel\n"
                           "`!all <message>` — Announce to all VPS users\n"
                           "`!maintenance on/off` — Maintenance mode\n"
                           "`!shutdown` — Pause free VPS + stop all user VPS\n"
                           "`!resume` — Resume from shutdown\n"
                           "`!enablefree` / `!disablefree` — Toggle free tier\n"
                           "`!changenormal lxc/docker` — Set default VPS type label\n"
                           "`!botcustom` — Edit bot name/status/bio\n"
                           "`!backup` — Manual DB backup\n"
                           "`!restorebackup <file>` — Restore a DB backup\n"
                           "`!serverinfo` — Discord server info\n"
                           "`!limits @user [n]` — Set user VPS limit\n"
                           "`!wipeall` — Factory reset (delete all VPS + DB)"),
                    inline=False)
    e.set_footer(text="Admin commands only visible to admins • Ghost VPS Bot 🐳")
    await ctx.send(embed=e)


@bot.command(name="ping")
async def cmd_ping(ctx):
    lat = round(bot.latency * 1000)
    color = 0x57f287 if lat < 100 else 0xfee75c if lat < 250 else 0xed4245
    await ctx.send(embed=discord.Embed(
        title="🏓 Pong!",
        description=f"**Latency:** `{lat}ms`",
        color=color))


@bot.command(name="uptime")
async def cmd_uptime(ctx):
    await ctx.send(embed=discord.Embed(
        title="⏱ Bot Uptime",
        description=f"`{fmt_uptime(time.time() - START_TIME)}`",
        color=0x5865f2))


@bot.command(name="botinfo")
async def cmd_botinfo(ctx):
    e = discord.Embed(title="🤖 Ghost VPS Bot Info", color=0x5865f2)
    e.set_thumbnail(url=bot.user.display_avatar.url)
    e.add_field(name="Bot Name",   value=bot.user.name,                    inline=True)
    e.add_field(name="Bot ID",     value=str(bot.user.id),                 inline=True)
    e.add_field(name="Guilds",     value=str(len(bot.guilds)),             inline=True)
    e.add_field(name="Users",      value=str(len(bot.users)),              inline=True)
    e.add_field(name="Commands",   value=str(len(bot.commands)),           inline=True)
    e.add_field(name="Uptime",     value=fmt_uptime(time.time()-START_TIME),inline=True)
    e.add_field(name="Python",     value=platform.python_version(),        inline=True)
    e.add_field(name="discord.py", value=discord.__version__,              inline=True)
    e.add_field(name="Type",       value="Docker VPS Manager 🐳",         inline=True)
    await ctx.send(embed=e)


@bot.command(name="tiers")
async def cmd_tiers(ctx):
    """Show all VPS invite tiers."""
    e = discord.Embed(title="🐳 VPS Invite Tiers", color=0x5865f2)
    for k, t in config.TIERS.items():
        e.add_field(
            name=t["name"],
            value=(f"Invites needed: **{t['invites']}**\n"
                   f"RAM: `{t['ram']}` | CPUs: `{t['cpus']}` | Storage: `{t['storage']}`"),
            inline=False)
    await ctx.send(embed=e)


@bot.command(name="invites", aliases=["inv"])
async def cmd_invites(ctx, target: discord.User = None):
    target = target or ctx.author
    d = inv_tbl.get(Q.user_id == str(target.id)) or {}
    valid  = get_valid_invites(target.id)
    fakes  = d.get("fakes", 0)
    leaves = d.get("leaves", 0)
    manual = d.get("manual", 0)
    # Find next tier
    next_tier = None
    for k, t in sorted(config.TIERS.items(), key=lambda x: x[1]["invites"]):
        if t["invites"] > valid:
            next_tier = t
            break
    e = discord.Embed(title=f"📨 Invites — {target.display_name}", color=0x5865f2)
    e.set_thumbnail(url=target.display_avatar.url)
    e.add_field(name="✅ Valid",  value=f"`{valid}`",  inline=True)
    e.add_field(name="❌ Fake",   value=f"`{fakes}`",  inline=True)
    e.add_field(name="👋 Left",   value=f"`{leaves}`", inline=True)
    e.add_field(name="🎁 Manual", value=f"`{manual}`", inline=True)
    if next_tier:
        need = next_tier["invites"] - valid
        e.add_field(name="🎯 Next Tier",
                    value=f"{next_tier['name']} — **{need} more** invite(s) needed!", inline=False)
    await ctx.send(embed=e)


@bot.command(name="topinvites", aliases=["leaderboard", "lb"])
async def cmd_topinvites(ctx):
    all_inv = inv_tbl.all()
    sorted_inv = sorted(all_inv,
                        key=lambda x: x.get("valid", 0) + x.get("manual", 0) - x.get("leaves", 0),
                        reverse=True)[:10]
    if not sorted_inv:
        return await ctx.send(embed=discord.Embed(
            description="No invite data yet!", color=0x2b2d31))
    lines = []
    medals = ["🥇","🥈","🥉"] + ["🏅"]*7
    for i, d in enumerate(sorted_inv):
        total = d.get("valid", 0) + d.get("manual", 0) - d.get("leaves", 0)
        lines.append(f"{medals[i]} <@{d['user_id']}> — **{total}** valid invites")
    e = discord.Embed(title="🏆 Top Inviters", description="\n".join(lines), color=0xfee75c)
    await ctx.send(embed=e)


@bot.command(name="status")
async def cmd_status(ctx):
    """Check your own Docker VPS status."""
    uid     = str(ctx.author.id)
    records = vps_tbl.search(Q.owner_id == uid)
    if not records:
        return await ctx.send(embed=discord.Embed(
            description="❌ You have no VPS assigned to you.", color=0xed4245), delete_after=12)
    e = discord.Embed(title="📊 Your VPS Status", color=0x2b2d31)
    for r in records:
        n      = r["cname"]
        status = await docker_status(n)
        dot    = "🟢" if status == "running" else "🔴"
        st_raw, _, _ = await shell(
            f"docker stats {n} --no-stream --format '{{{{.CPUPerc}}}} {{{{.MemUsage}}}}' 2>/dev/null")
        extra = f" | CPU: `{st_raw.split()[0]}`" if st_raw else ""
        e.add_field(
            name=f"{dot} {n}",
            value=(f"ID: `{r['vps_id']}` | OS: `{r.get('image','?')}` | "
                   f"RAM: `{r.get('ram','?')}` | Status: `{status.upper()}`{extra}"),
            inline=False)
    await ctx.send(embed=e)


@bot.command(name="sshx")
async def cmd_sshx(ctx, vps_id: str = None):
    """Get your SSHX web link (sent via DM)."""
    uid = str(ctx.author.id)
    records = vps_tbl.search(Q.owner_id == uid)
    r = (next((x for x in records if x["vps_id"] == vps_id), None)
         if vps_id else (records[0] if records else None))
    if not r:
        return await ctx.send(embed=discord.Embed(
            description="❌ VPS not found.", color=0xed4245), delete_after=8)
    _, sshx = await get_links(r["cname"])
    if sshx:
        await ctx.author.send(embed=discord.Embed(
            title="🖥 SSHX Web Terminal", description=sshx, color=0x5865f2))
        await ctx.send(embed=discord.Embed(
            description="✅ SSHX link sent to your DMs!", color=0x57f287), delete_after=6)
    else:
        await ctx.send(embed=discord.Embed(
            description="❌ SSHX not available. Is your VPS running?", color=0xed4245), delete_after=8)


@bot.command(name="tmate")
async def cmd_tmate(ctx, vps_id: str = None):
    """Get your tmate SSH link (sent via DM)."""
    uid = str(ctx.author.id)
    records = vps_tbl.search(Q.owner_id == uid)
    r = (next((x for x in records if x["vps_id"] == vps_id), None)
         if vps_id else (records[0] if records else None))
    if not r:
        return await ctx.send(embed=discord.Embed(
            description="❌ VPS not found.", color=0xed4245), delete_after=8)
    tmate, _ = await get_links(r["cname"])
    if tmate:
        await ctx.author.send(embed=discord.Embed(
            title="📟 tmate SSH", description=f"`{tmate}`", color=0x5865f2))
        await ctx.send(embed=discord.Embed(
            description="✅ tmate link sent to your DMs!", color=0x57f287), delete_after=6)
    else:
        await ctx.send(embed=discord.Embed(
            description="❌ tmate not available. Is your VPS running?", color=0xed4245), delete_after=8)


# ──────────────────────────────────────────────────────────
#  ░█████╗░██████╗░███╗░░░███╗██╗███╗░░██╗
#  ██╔══██╗██╔══██╗████╗░████║██║████╗░██║
#  ███████║██║░░██║██╔████╔██║██║██╔██╗██║
#  ██╔══██║██║░░██║██║╚██╔╝██║██║██║╚████║
#  ██║░░██║██████╔╝██║░╚═╝░██║██║██║░╚███║
#  ADMIN — VPS MANAGEMENT
# ──────────────────────────────────────────────────────────

@bot.command(name="createvps")
@admin_only()
async def cmd_createvps(ctx):
    """Admin: Interactively create a Docker VPS for yourself."""
    params = await run_wizard(ctx)
    if not params: return
    vid   = gen_id()
    cname = f"vps-{params['name']}-{vid}"
    msg = await ctx.send(embed=discord.Embed(
        title="🚀 Creating Docker VPS...",
        description=(f"OS: `{params['image']}` | RAM: `{params['ram']}` | "
                     f"CPUs: `{params['cpus']}` | Storage: `{params['storage']}`"),
        color=0xfee75c))
    try:
        await create_docker_vps(cname, params["image"], params["ram"], params["cpus"])
        tmate, sshx = await wait_links(cname)
        vps_tbl.insert({
            "owner_id": str(ctx.author.id), "vps_id": vid, "cname": cname,
            "image": params["image"], "ram": params["ram"], "cpus": params["cpus"],
            "storage": params["storage"], "tier": "admin",
            "created_at": datetime.now().isoformat(),
        })
        ok = discord.Embed(title="✅ Docker VPS Created!", color=0x57f287)
        ok.add_field(name="Container", value=f"`{cname}`",        inline=True)
        ok.add_field(name="VPS ID",    value=f"`{vid}`",          inline=True)
        ok.add_field(name="OS",        value=f"`{params['image']}`",inline=True)
        ok.add_field(name="RAM",       value=f"`{params['ram']}`", inline=True)
        ok.add_field(name="CPUs",      value=f"`{params['cpus']}`",inline=True)
        if tmate: ok.add_field(name="📟 tmate SSH", value=f"`{tmate}`", inline=False)
        if sshx:  ok.add_field(name="🖥 SSHX Web",  value=sshx,        inline=False)
        await msg.edit(embed=ok)
        try:
            await ctx.author.send(
                embed=discord.Embed(title="🖥 VPS Control Panel",
                                    description=f"**ID:** `{vid}`\n**Container:** `{cname}`",
                                    color=0x5865f2),
                view=VPSPanel(vid))
        except Exception: pass
        await log(ctx.guild, "🖥 Admin Created VPS",
                  f"**Admin:** {ctx.author.mention}\n**Container:** `{cname}`\n**OS:** {params['image']}", 0x57f287)
    except Exception as e:
        await msg.edit(embed=discord.Embed(title="❌ Failed", description=str(e)[:1800], color=0xed4245))


@bot.command(name="givevps")
@admin_only()
async def cmd_givevps(ctx, target: discord.Member = None):
    """Admin: Give a Docker VPS to a user via wizard."""
    if not target:
        return await ctx.send(embed=discord.Embed(
            description="❌ Usage: `!givevps @user`", color=0xed4245))
    if is_banned(target.id):
        return await ctx.send(embed=discord.Embed(
            description="❌ That user is banned and cannot receive a VPS.", color=0xed4245))
    params = await run_wizard(ctx)
    if not params: return
    vid   = gen_id()
    clean = safe_name(target.name)
    cname = f"vps-{clean}-{vid}"
    msg = await ctx.send(embed=discord.Embed(
        title=f"🚀 Creating VPS for {target.display_name}...", color=0xfee75c))
    try:
        await create_docker_vps(cname, params["image"], params["ram"], params["cpus"])
        tmate, sshx = await wait_links(cname)
        vps_tbl.insert({
            "owner_id": str(target.id), "vps_id": vid, "cname": cname,
            "image": params["image"], "ram": params["ram"], "cpus": params["cpus"],
            "storage": params["storage"], "tier": "gifted",
            "created_at": datetime.now().isoformat(),
        })
        ok = discord.Embed(title=f"✅ VPS Given to {target.display_name}!", color=0x57f287)
        ok.add_field(name="Container", value=f"`{cname}`",         inline=True)
        ok.add_field(name="VPS ID",    value=f"`{vid}`",           inline=True)
        ok.add_field(name="OS",        value=f"`{params['image']}`",inline=True)
        ok.add_field(name="RAM",       value=f"`{params['ram']}`",  inline=True)
        ok.add_field(name="CPUs",      value=f"`{params['cpus']}`", inline=True)
        if tmate: ok.add_field(name="📟 tmate SSH", value=f"`{tmate}`", inline=False)
        if sshx:  ok.add_field(name="🖥 SSHX Web",  value=sshx,        inline=False)
        await msg.edit(embed=ok)
        try:
            dm = discord.Embed(
                title="🎁 You received a VPS!",
                description=(f"An admin gave you a Docker VPS!\n"
                             f"**ID:** `{vid}`\n**Container:** `{cname}`"))
            dm.add_field(name="OS",      value=f"`{params['image']}`",inline=True)
            dm.add_field(name="RAM",     value=f"`{params['ram']}`",  inline=True)
            dm.add_field(name="CPUs",    value=f"`{params['cpus']}`", inline=True)
            if tmate: dm.add_field(name="📟 tmate", value=f"`{tmate}`", inline=False)
            if sshx:  dm.add_field(name="🖥 SSHX",  value=sshx,        inline=False)
            await target.send(embed=dm, view=VPSPanel(vid))
        except Exception:
            await ctx.send(embed=discord.Embed(
                description=f"⚠️ Could not DM {target.mention} — they may have DMs disabled.",
                color=0xfee75c))
        await log(ctx.guild, "🎁 Admin Gave VPS",
                  f"**Admin:** {ctx.author.mention}\n**User:** {target.mention}\n**Container:** `{cname}`", 0x57f287)
    except Exception as e:
        await msg.edit(embed=discord.Embed(title="❌ Failed", description=str(e)[:1800], color=0xed4245))


@bot.command(name="deletemyvps")
@admin_only()
async def cmd_deletemyvps(ctx, vps_id: str = None):
    """Admin: Delete your own VPS."""
    uid     = str(ctx.author.id)
    records = vps_tbl.search(Q.owner_id == uid)
    r = (next((x for x in records if x["vps_id"] == vps_id), None)
         if vps_id else (records[0] if records else None))
    if not r:
        return await ctx.send(embed=discord.Embed(description="❌ VPS not found.", color=0xed4245))
    def chk(m): return m.author == ctx.author and m.channel == ctx.channel
    await ctx.send(embed=discord.Embed(
        title="⚠️ Confirm Delete",
        description=f"Type `confirm` to delete `{r['cname']}`. This is **permanent**!",
        color=0xfee75c))
    try:
        m = await bot.wait_for("message", check=chk, timeout=30)
        if m.content.lower() != "confirm":
            return await ctx.send(embed=discord.Embed(description="❌ Cancelled.", color=0x2b2d31))
    except asyncio.TimeoutError:
        return await ctx.send(embed=discord.Embed(description="⏱ Timed out. Cancelled.", color=0x2b2d31))
    await shell(f"docker rm -f {r['cname']}")
    vps_tbl.remove(Q.vps_id == r["vps_id"])
    await ctx.send(embed=discord.Embed(
        description=f"✅ VPS `{r['cname']}` deleted.", color=0x57f287))
    await log(ctx.guild, "🗑 VPS Deleted",
              f"**Admin:** {ctx.author.mention}\n**Container:** `{r['cname']}`", 0xed4245)


@bot.command(name="deletesomeonevps", aliases=["delvps", "removevps"])
@admin_only()
async def cmd_deletesomeonevps(ctx, target: discord.Member = None, vps_id: str = None):
    """Admin: Delete a user's VPS."""
    if not target:
        return await ctx.send(embed=discord.Embed(
            description="❌ Usage: `!deletesomeonevps @user [vps_id]`", color=0xed4245))
    uid     = str(target.id)
    records = vps_tbl.search(Q.owner_id == uid)
    r = (next((x for x in records if x["vps_id"] == vps_id), None)
         if vps_id else (records[0] if records else None))
    if not r:
        return await ctx.send(embed=discord.Embed(
            description=f"❌ No VPS found for {target.mention}.", color=0xed4245))
    await shell(f"docker rm -f {r['cname']}")
    vps_tbl.remove(Q.vps_id == r["vps_id"])
    await ctx.send(embed=discord.Embed(
        description=f"✅ Deleted VPS `{r['cname']}` from {target.mention}.", color=0x57f287))
    try:
        await target.send(embed=discord.Embed(
            title="⚠️ VPS Deleted",
            description=f"Your VPS `{r['cname']}` was deleted by an admin.",
            color=0xed4245))
    except Exception: pass
    await log(ctx.guild, "🗑 Admin Deleted User VPS",
              f"**Admin:** {ctx.author.mention}\n**User:** {target.mention}\n**Container:** `{r['cname']}`", 0xed4245)


@bot.command(name="startvps")
@admin_only()
async def cmd_startvps(ctx, target: discord.Member = None, vps_id: str = None):
    if not target:
        return await ctx.send(embed=discord.Embed(
            description="❌ Usage: `!startvps @user [id]`", color=0xed4245))
    records = vps_tbl.search(Q.owner_id == str(target.id))
    r = next((x for x in records if x["vps_id"] == vps_id), records[0] if records else None)
    if not r:
        return await ctx.send(embed=discord.Embed(description="❌ No VPS found.", color=0xed4245))
    if await docker_running(r["cname"]):
        return await ctx.send(embed=discord.Embed(
            description=f"⚠️ `{r['cname']}` is already running!", color=0xfee75c))
    await shell(f"docker start {r['cname']}")
    await ctx.send(embed=discord.Embed(
        description=f"✅ Started `{r['cname']}` for {target.mention}.", color=0x57f287))
    await log(ctx.guild, "▶ VPS Started",
              f"**Admin:** {ctx.author.mention}\n**User:** {target.mention}\n**Container:** `{r['cname']}`", 0x57f287)


@bot.command(name="stopvps")
@admin_only()
async def cmd_stopvps(ctx, target: discord.Member = None, vps_id: str = None):
    if not target:
        return await ctx.send(embed=discord.Embed(
            description="❌ Usage: `!stopvps @user [id]`", color=0xed4245))
    records = vps_tbl.search(Q.owner_id == str(target.id))
    r = next((x for x in records if x["vps_id"] == vps_id), records[0] if records else None)
    if not r:
        return await ctx.send(embed=discord.Embed(description="❌ No VPS found.", color=0xed4245))
    await shell(f"docker stop {r['cname']}")
    await ctx.send(embed=discord.Embed(
        description=f"✅ Stopped `{r['cname']}` for {target.mention}.", color=0x57f287))
    await log(ctx.guild, "⏹ VPS Stopped",
              f"**Admin:** {ctx.author.mention}\n**User:** {target.mention}\n**Container:** `{r['cname']}`", 0xed4245)


@bot.command(name="restartvps")
@admin_only()
async def cmd_restartvps(ctx, target: discord.Member = None, vps_id: str = None):
    if not target:
        return await ctx.send(embed=discord.Embed(
            description="❌ Usage: `!restartvps @user [id]`", color=0xed4245))
    records = vps_tbl.search(Q.owner_id == str(target.id))
    r = next((x for x in records if x["vps_id"] == vps_id), records[0] if records else None)
    if not r:
        return await ctx.send(embed=discord.Embed(description="❌ No VPS found.", color=0xed4245))
    await shell(f"docker restart {r['cname']}")
    await ctx.send(embed=discord.Embed(
        description=f"✅ Restarted `{r['cname']}` for {target.mention}.", color=0x57f287))
    await log(ctx.guild, "🔄 VPS Restarted",
              f"**Admin:** {ctx.author.mention}\n**User:** {target.mention}\n**Container:** `{r['cname']}`", 0xfee75c)


@bot.command(name="rebuildvps")
@admin_only()
async def cmd_rebuildvps(ctx, target: discord.Member = None, vps_id: str = None):
    """Admin: Rebuild (wipe & recreate) a user's VPS."""
    if not target:
        return await ctx.send(embed=discord.Embed(
            description="❌ Usage: `!rebuildvps @user [id]`", color=0xed4245))
    records = vps_tbl.search(Q.owner_id == str(target.id))
    r = next((x for x in records if x["vps_id"] == vps_id), records[0] if records else None)
    if not r: return await ctx.send(embed=discord.Embed(description="❌ No VPS found.", color=0xed4245))
    def chk(m): return m.author == ctx.author and m.channel == ctx.channel
    await ctx.send(embed=discord.Embed(
        title="⚠️ Confirm Rebuild",
        description=f"Type `confirm` to **wipe all data** on `{r['cname']}`!",
        color=0xfee75c))
    try:
        m = await bot.wait_for("message", check=chk, timeout=30)
        if m.content.lower() != "confirm":
            return await ctx.send(embed=discord.Embed(description="❌ Cancelled.", color=0x2b2d31))
    except asyncio.TimeoutError:
        return await ctx.send(embed=discord.Embed(description="⏱ Cancelled.", color=0x2b2d31))
    msg = await ctx.send(embed=discord.Embed(description=f"♻️ Rebuilding `{r['cname']}`...", color=0xfee75c))
    await shell(f"docker rm -f {r['cname']}")
    try:
        await create_docker_vps(r["cname"], r["image"], r["ram"], r["cpus"])
        tmate, sshx = await wait_links(r["cname"])
        ok = discord.Embed(title="✅ VPS Rebuilt!", color=0x57f287)
        if tmate: ok.add_field(name="📟 tmate", value=f"`{tmate}`", inline=False)
        if sshx:  ok.add_field(name="🖥 SSHX",  value=sshx,        inline=False)
        await msg.edit(embed=ok)
        try:
            await target.send(embed=discord.Embed(
                title="♻️ Your VPS was rebuilt",
                description=f"Container: `{r['cname']}`",
                color=0xfee75c))
        except Exception: pass
        await log(ctx.guild, "♻️ VPS Rebuilt",
                  f"**Admin:** {ctx.author.mention}\n**User:** {target.mention}\n**Container:** `{r['cname']}`", 0xfee75c)
    except Exception as e:
        await msg.edit(embed=discord.Embed(title="❌ Rebuild Failed", description=str(e)[:1800], color=0xed4245))


@bot.command(name="execvps")
@admin_only()
async def cmd_execvps(ctx, target: discord.Member = None, *, cmd: str = None):
    """Admin: Run a command inside a user's VPS container."""
    if not target or not cmd:
        return await ctx.send(embed=discord.Embed(
            description="❌ Usage: `!execvps @user <command>`", color=0xed4245))
    records = vps_tbl.search(Q.owner_id == str(target.id))
    if not records:
        return await ctx.send(embed=discord.Embed(description="❌ No VPS found.", color=0xed4245))
    r   = records[0]
    out, err, rc = await shell(f"docker exec {r['cname']} bash -c '{cmd}'")
    result = out or err or "(no output)"
    e = discord.Embed(title=f"⚙️ Exec on `{r['cname']}`", color=0x2b2d31)
    e.add_field(name="Command", value=f"`{cmd}`",              inline=False)
    e.add_field(name="Output",  value=f"```\n{result[:1000]}\n```", inline=False)
    e.add_field(name="Exit",    value=f"`{rc}`",               inline=True)
    await ctx.send(embed=e)


@bot.command(name="renamevps")
@admin_only()
async def cmd_renamevps(ctx, target: discord.Member = None, new_label: str = None):
    """Admin: Rename a VPS label in the database (display only)."""
    if not target or not new_label:
        return await ctx.send(embed=discord.Embed(
            description="❌ Usage: `!renamevps @user <new_label>`", color=0xed4245))
    records = vps_tbl.search(Q.owner_id == str(target.id))
    if not records:
        return await ctx.send(embed=discord.Embed(description="❌ No VPS found.", color=0xed4245))
    r = records[0]
    vps_tbl.update({"label": new_label}, Q.vps_id == r["vps_id"])
    await ctx.send(embed=discord.Embed(
        description=f"✅ VPS `{r['cname']}` labeled as `{new_label}`.", color=0x57f287))


@bot.command(name="vpsnote")
@admin_only()
async def cmd_vpsnote(ctx, target: discord.Member = None, *, note: str = None):
    """Admin: Add a note to a user's VPS record."""
    if not target or not note:
        return await ctx.send(embed=discord.Embed(
            description="❌ Usage: `!vpsnote @user <note>`", color=0xed4245))
    records = vps_tbl.search(Q.owner_id == str(target.id))
    if not records:
        return await ctx.send(embed=discord.Embed(description="❌ No VPS found.", color=0xed4245))
    vps_tbl.update({"note": note}, Q.owner_id == str(target.id))
    await ctx.send(embed=discord.Embed(
        description=f"✅ Note saved for {target.mention}:\n> {note}", color=0x57f287))


@bot.command(name="transfervps")
@admin_only()
async def cmd_transfervps(ctx, from_: discord.Member = None, to: discord.Member = None, vps_id: str = None):
    """Admin: Transfer VPS ownership from one user to another."""
    if not from_ or not to:
        return await ctx.send(embed=discord.Embed(
            description="❌ Usage: `!transfervps @from @to [vps_id]`", color=0xed4245))
    records = vps_tbl.search(Q.owner_id == str(from_.id))
    r = next((x for x in records if x["vps_id"] == vps_id), records[0] if records else None)
    if not r:
        return await ctx.send(embed=discord.Embed(description="❌ No VPS found.", color=0xed4245))
    vps_tbl.update({"owner_id": str(to.id)}, Q.vps_id == r["vps_id"])
    await ctx.send(embed=discord.Embed(
        description=f"✅ VPS `{r['cname']}` transferred from {from_.mention} to {to.mention}.",
        color=0x57f287))
    await log(ctx.guild, "🔁 VPS Transferred",
              f"**Admin:** {ctx.author.mention}\n**From:** {from_.mention}\n"
              f"**To:** {to.mention}\n**Container:** `{r['cname']}`", 0x5865f2)


# ──────────────────────────────────────────────────────────
#  ADMIN — LISTINGS
# ──────────────────────────────────────────────────────────

@bot.command(name="listvps")
@admin_only()
async def cmd_listvps(ctx):
    """Admin: List all running VPS with owners."""
    all_vps = vps_tbl.all()
    if not all_vps:
        return await ctx.send(embed=discord.Embed(description="No VPS in database.", color=0x2b2d31))
    lines = []
    for r in all_vps:
        status = await docker_status(r["cname"])
        dot    = "🟢" if status == "running" else "🔴"
        lines.append(f"{dot} `{r['cname']}` — <@{r['owner_id']}> | ID: `{r['vps_id']}`")
    chunks = [lines[i:i+10] for i in range(0, len(lines), 10)]
    for i, chunk in enumerate(chunks):
        e = discord.Embed(
            title=f"📋 All VPS ({i+1}/{len(chunks)}) — {len(all_vps)} total",
            description="\n".join(chunk), color=0x2b2d31)
        await ctx.send(embed=e)


@bot.command(name="listall")
@admin_only()
async def cmd_listall(ctx):
    """Admin: Full database VPS dump."""
    all_vps = vps_tbl.all()
    if not all_vps:
        return await ctx.send(embed=discord.Embed(description="No VPS in database.", color=0x2b2d31))
    lines = []
    for r in all_vps:
        lines.append(
            f"`{r['cname']}` | Owner: <@{r['owner_id']}> | "
            f"OS: `{r.get('image','?')}` | RAM: `{r.get('ram','?')}` | "
            f"Tier: `{r.get('tier','?')}` | Created: `{r.get('created_at','?')[:10]}`")
    chunks = [lines[i:i+5] for i in range(0, len(lines), 5)]
    for i, ch in enumerate(chunks):
        e = discord.Embed(
            title=f"🗄 Full VPS List ({i+1}/{len(chunks)})",
            description="\n\n".join(ch), color=0x2b2d31)
        await ctx.send(embed=e)


@bot.command(name="lookup")
@admin_only()
async def cmd_lookup(ctx, target: discord.Member = None):
    """Admin: View all VPS owned by a user."""
    if not target:
        return await ctx.send(embed=discord.Embed(
            description="❌ Usage: `!lookup @user`", color=0xed4245))
    records = vps_tbl.search(Q.owner_id == str(target.id))
    if not records:
        return await ctx.send(embed=discord.Embed(
            description=f"❌ {target.mention} has no VPS.", color=0x2b2d31))
    e = discord.Embed(title=f"🔍 VPS for {target.display_name}", color=0x2b2d31)
    for r in records:
        status = await docker_status(r["cname"])
        dot    = "🟢" if status == "running" else "🔴"
        e.add_field(
            name=f"{dot} {r['cname']}",
            value=(f"ID: `{r['vps_id']}` | OS: `{r.get('image','?')}` | "
                   f"RAM: `{r.get('ram','?')}` | CPUs: `{r.get('cpus','?')}` | "
                   f"Tier: `{r.get('tier','?')}`"
                   + (f"\nNote: {r['note']}" if r.get("note") else "")),
            inline=False)
    await ctx.send(embed=e)


@bot.command(name="vpsinfo")
@admin_only()
async def cmd_vpsinfo(ctx, vps_id: str = None):
    """Admin: Detailed info on a VPS by ID."""
    if not vps_id:
        return await ctx.send(embed=discord.Embed(
            description="❌ Usage: `!vpsinfo <vps_id>`", color=0xed4245))
    r = vps_tbl.get(Q.vps_id == vps_id)
    if not r:
        return await ctx.send(embed=discord.Embed(description="❌ VPS not found.", color=0xed4245))
    n      = r["cname"]
    status = await docker_status(n)
    st_raw, _, _ = await shell(
        f"docker stats {n} --no-stream --format '{{{{.CPUPerc}}}} {{{{.MemUsage}}}}' 2>/dev/null")
    dot = "🟢" if status == "running" else "🔴"
    e = discord.Embed(title=f"🔎 VPS Info — `{n}`", color=0x2b2d31)
    e.add_field(name="Status",   value=f"{dot} `{status.upper()}`",   inline=True)
    e.add_field(name="VPS ID",   value=f"`{vps_id}`",                 inline=True)
    e.add_field(name="Owner",    value=f"<@{r['owner_id']}>",         inline=True)
    e.add_field(name="OS",       value=f"`{r.get('image','?')}`",     inline=True)
    e.add_field(name="RAM",      value=f"`{r.get('ram','?')}`",       inline=True)
    e.add_field(name="CPUs",     value=f"`{r.get('cpus','?')}`",      inline=True)
    e.add_field(name="Storage",  value=f"`{r.get('storage','?')}`",   inline=True)
    e.add_field(name="Tier",     value=f"`{r.get('tier','?')}`",      inline=True)
    e.add_field(name="Created",  value=f"`{r.get('created_at','?')[:10]}`", inline=True)
    if st_raw:
        parts = st_raw.split()
        e.add_field(name="CPU Use",  value=f"`{parts[0]}`",           inline=True)
        e.add_field(name="RAM Use",  value=f"`{' '.join(parts[1:])}`",inline=True)
    if r.get("note"):
        e.add_field(name="📝 Note", value=r["note"], inline=False)
    await ctx.send(embed=e)


@bot.command(name="dockerps")
@admin_only()
async def cmd_dockerps(ctx):
    """Admin: Raw docker ps output."""
    out, _, _ = await shell("docker ps --format 'table {{.Names}}\\t{{.Status}}\\t{{.Image}}\\t{{.Ports}}'")
    await ctx.send(embed=discord.Embed(
        title="🐳 docker ps",
        description=f"```\n{out[:3900] or 'No containers running.'}\n```",
        color=0x2b2d31))


@bot.command(name="dockerstats")
@admin_only()
async def cmd_dockerstats(ctx):
    """Admin: Live docker stats snapshot."""
    out, _, _ = await shell(
        "docker stats --no-stream --format 'table {{.Name}}\\t{{.CPUPerc}}\\t{{.MemUsage}}\\t{{.NetIO}}'")
    await ctx.send(embed=discord.Embed(
        title="📊 Docker Stats",
        description=f"```\n{out[:3900] or 'No containers.'}\n```",
        color=0x2b2d31))


# ──────────────────────────────────────────────────────────
#  ADMIN — NODE & SYSTEM
# ──────────────────────────────────────────────────────────

@bot.command(name="node", aliases=["nodeinfo"])
@admin_only()
async def cmd_node(ctx):
    """Admin: Full node resource report."""
    cpu  = psutil.cpu_percent(interval=1)
    ram  = psutil.virtual_memory()
    disk = psutil.disk_usage("/")
    net  = psutil.net_io_counters()
    boot = datetime.fromtimestamp(psutil.boot_time()).strftime("%Y-%m-%d %H:%M")

    running, _, _ = await shell("docker ps -q | wc -l")
    total,   _, _ = await shell("docker ps -a -q | wc -l")

    e = discord.Embed(title="🖥 Node Status", color=0x2b2d31,
                      timestamp=datetime.now(timezone.utc))
    e.add_field(name="🔥 CPU",
                value=f"`{cpu:.1f}%` — {psutil.cpu_count()} cores", inline=True)
    e.add_field(name="🧠 RAM",
                value=f"`{ram.percent:.1f}%` — {ram.used//1024//1024}MB / {ram.total//1024//1024}MB",
                inline=True)
    e.add_field(name="💾 Disk",
                value=f"`{disk.percent:.1f}%` — {disk.used//1024//1024//1024}GB / {disk.total//1024//1024//1024}GB",
                inline=True)
    e.add_field(name="📡 Network",
                value=f"↑ {net.bytes_sent//1024//1024}MB  ↓ {net.bytes_recv//1024//1024}MB",
                inline=True)
    e.add_field(name="🐳 Containers",
                value=f"`{running.strip()}` running / `{total.strip()}` total", inline=True)
    e.add_field(name="🕐 Boot Time",    value=f"`{boot}`",                    inline=True)
    e.add_field(name="🤖 Bot Uptime",   value=f"`{fmt_uptime(time.time()-START_TIME)}`", inline=True)
    e.add_field(name="🐍 Python",       value=f"`{platform.python_version()}`",          inline=True)
    e.add_field(name="🖥 OS",           value=f"`{platform.system()} {platform.release()}`", inline=True)
    await ctx.send(embed=e)


@bot.command(name="installcheck")
@admin_only()
async def cmd_installcheck(ctx):
    """Admin: Check if Docker is installed and running."""
    docker_v, _, rc1 = await shell("docker --version")
    compose_v, _, _  = await shell("docker compose version 2>/dev/null || docker-compose --version 2>/dev/null")
    daemon,    _, rc3 = await shell("docker info --format 'Server Version: {{.ServerVersion}}' 2>/dev/null")
    net_out, _, _    = await shell(f"docker network ls | grep {config.DOCKER_NETWORK}")

    e = discord.Embed(title="🔍 Installation Check", color=0x2b2d31)
    e.add_field(name="🐳 Docker",
                value=f"✅ `{docker_v}`" if rc1 == 0 else "❌ Not installed!", inline=False)
    e.add_field(name="🔧 Docker Compose",
                value=f"✅ `{compose_v}`" if compose_v else "⚠️ Not found (optional)", inline=False)
    e.add_field(name="🟢 Docker Daemon",
                value=f"✅ Running — `{daemon}`" if rc3 == 0 and daemon else "❌ Daemon not running!", inline=False)
    e.add_field(name=f"🌐 Network `{config.DOCKER_NETWORK}`",
                value="✅ Exists" if net_out else f"⚠️ Not found — run: `docker network create {config.DOCKER_NETWORK}`",
                inline=False)
    if rc1 != 0:
        e.add_field(name="📥 Install Docker",
                    value="Run: `sudo bash install.sh` in the bot folder!", inline=False)
    await ctx.send(embed=e)


@bot.command(name="serverinfo")
@admin_only()
async def cmd_serverinfo(ctx):
    g = ctx.guild
    e = discord.Embed(title=f"📊 {g.name}", color=0x5865f2)
    e.set_thumbnail(url=g.icon.url if g.icon else None)
    e.add_field(name="Owner",    value=g.owner.mention if g.owner else "?", inline=True)
    e.add_field(name="Members",  value=str(g.member_count),                  inline=True)
    e.add_field(name="Channels", value=str(len(g.channels)),                 inline=True)
    e.add_field(name="Roles",    value=str(len(g.roles)),                    inline=True)
    e.add_field(name="Boost",    value=str(g.premium_subscription_count),    inline=True)
    e.add_field(name="Created",  value=g.created_at.strftime("%Y-%m-%d"),   inline=True)
    await ctx.send(embed=e)


@bot.command(name="setup")
@admin_only()
async def cmd_setup(ctx):
    """Admin: First-time setup wizard."""
    def chk(m): return m.author == ctx.author and m.channel == ctx.channel

    async def ask(prompt):
        await ctx.send(embed=discord.Embed(description=prompt, color=0x5865f2))
        try:
            m = await bot.wait_for("message", check=chk, timeout=60)
            return m.content.strip()
        except asyncio.TimeoutError:
            return None

    await ctx.send(embed=discord.Embed(
        title="⚙️ Ghost VPS Bot — Setup Wizard",
        description="Let's configure the bot! Answer each question.", color=0x5865f2))

    log_raw = await ask("**Step 1:** Mention or paste the ID of the **log channel** (e.g. #bot-logs):")
    if log_raw:
        log_id = log_raw.strip("<#>")
        upd_guild_cfg(ctx.guild.id, {"log_channel": log_id})

    tk_raw = await ask("**Step 2:** Mention or paste the ID of the **ticket category/channel**:")
    if tk_raw:
        tk_id = tk_raw.strip("<#>")
        upd_guild_cfg(ctx.guild.id, {"ticket_channel": tk_id})

    ann_raw = await ask("**Step 3:** Mention or paste the **announcement channel** ID:")
    if ann_raw:
        ann_id = ann_raw.strip("<#>")
        upd_guild_cfg(ctx.guild.id, {"announce_channel": ann_id})

    upd_guild_cfg(ctx.guild.id, {"setup_done": True})
    await ctx.send(embed=discord.Embed(
        title="✅ Setup Complete!",
        description=("Bot is configured!\n\n"
                     "Next: Use `!ticketpanel` to post the ticket button.\n"
                     "Use `!installcheck` to verify Docker is ready."),
        color=0x57f287))


@bot.command(name="ticketpanel")
@admin_only()
async def cmd_ticketpanel(ctx):
    """Admin: Post the open-ticket panel."""
    e = discord.Embed(
        title="🎫 Support & VPS Tickets",
        description=("Click the button below to open a ticket.\n\n"
                     "**Staff will help you with:**\n"
                     "• VPS setup and access\n"
                     "• Technical support\n"
                     "• Account questions\n\n"
                     "_Only you and staff can see your ticket._"),
        color=0x5865f2)
    e.set_footer(text="Ghost VPS Bot • Ticket System")
    await ctx.send(embed=e, view=OpenTicketView())
    await ctx.message.delete()


@bot.command(name="closeticket")
@admin_only()
async def cmd_closeticket(ctx):
    """Admin: Close the current ticket channel."""
    tk = tickets_tbl.get(Q.channel_id == str(ctx.channel.id))
    if not tk:
        return await ctx.send(embed=discord.Embed(
            description="❌ This is not a ticket channel.", color=0xed4245))
    await ctx.send(embed=discord.Embed(description="🗑 Closing in 5 seconds...", color=0xed4245))
    tickets_tbl.remove(Q.channel_id == str(ctx.channel.id))
    await asyncio.sleep(5)
    try: await ctx.channel.delete()
    except: pass


@bot.command(name="listtickets")
@admin_only()
async def cmd_listtickets(ctx):
    all_tk = tickets_tbl.search(Q.guild_id == str(ctx.guild.id))
    if not all_tk:
        return await ctx.send(embed=discord.Embed(description="No open tickets.", color=0x2b2d31))
    lines = []
    for tk in all_tk:
        ch = ctx.guild.get_channel(int(tk["channel_id"]))
        lines.append(f"<#{tk['channel_id']}> — <@{tk['user_id']}> | Status: `{tk['status']}`"
                     + (f" | Claimed: <@{tk['claimed_by']}>" if tk.get("claimed_by") else ""))
    e = discord.Embed(title=f"🎫 Open Tickets ({len(all_tk)})",
                      description="\n".join(lines), color=0x5865f2)
    await ctx.send(embed=e)


@bot.command(name="addtoticket")
@admin_only()
async def cmd_addtoticket(ctx, target: discord.Member = None):
    if not target:
        return await ctx.send(embed=discord.Embed(
            description="❌ Usage: `!addtoticket @user`", color=0xed4245))
    await ctx.channel.set_permissions(target, read_messages=True, send_messages=True)
    await ctx.send(embed=discord.Embed(
        description=f"✅ {target.mention} added to ticket.", color=0x57f287))


@bot.command(name="removeuser")
@admin_only()
async def cmd_removeuser(ctx, target: discord.Member = None):
    if not target:
        return await ctx.send(embed=discord.Embed(
            description="❌ Usage: `!removeuser @user`", color=0xed4245))
    await ctx.channel.set_permissions(target, overwrite=None)
    await ctx.send(embed=discord.Embed(
        description=f"✅ {target.mention} removed from ticket.", color=0x57f287))


# ──────────────────────────────────────────────────────────
#  ADMIN — USER MANAGEMENT
# ──────────────────────────────────────────────────────────

@bot.command(name="ban")
@admin_only()
async def cmd_ban(ctx, target: discord.Member = None, *, reason: str = "No reason given."):
    if not target:
        return await ctx.send(embed=discord.Embed(description="❌ Usage: `!ban @user [reason]`", color=0xed4245))
    if target.id in config.ADMIN_IDS:
        return await ctx.send(embed=discord.Embed(description="❌ Cannot ban another admin.", color=0xed4245))
    bans_tbl.upsert({"user_id": str(target.id), "reason": reason,
                     "banned_by": str(ctx.author.id), "banned_at": datetime.now().isoformat()},
                    Q.user_id == str(target.id))
    # Delete & stop all VPS
    records = vps_tbl.search(Q.owner_id == str(target.id))
    for r in records:
        await shell(f"docker rm -f {r['cname']}")
    vps_tbl.remove(Q.owner_id == str(target.id))
    # Notify user
    try:
        await target.send(embed=discord.Embed(
            title="🚫 You Have Been Banned",
            description=(f"You have been banned from the VPS service.\n"
                         f"**Reason:** {reason}\n\n"
                         f"All your VPS containers have been removed."),
            color=0xed4245))
    except Exception: pass
    await ctx.send(embed=discord.Embed(
        description=f"🚫 {target.mention} has been **banned**.\n**Reason:** {reason}\nAll VPS deleted.",
        color=0xed4245))
    await log(ctx.guild, "🚫 User Banned",
              f"**Admin:** {ctx.author.mention}\n**User:** {target.mention}\n**Reason:** {reason}", 0xed4245)


@bot.command(name="unban")
@admin_only()
async def cmd_unban(ctx, target: discord.User = None, *, reason: str = "No reason given."):
    if not target:
        return await ctx.send(embed=discord.Embed(description="❌ Usage: `!unban @user [reason]`", color=0xed4245))
    if not bans_tbl.contains(Q.user_id == str(target.id)):
        return await ctx.send(embed=discord.Embed(description="❌ That user is not banned.", color=0xed4245))
    bans_tbl.remove(Q.user_id == str(target.id))
    try:
        await target.send(embed=discord.Embed(
            title="✅ You Have Been Unbanned",
            description=f"You have been unbanned from the VPS service!\n**Reason:** {reason}",
            color=0x57f287))
        await asyncio.sleep(10)
    except Exception: pass
    await ctx.send(embed=discord.Embed(
        description=f"✅ {target.mention} has been **unbanned**.", color=0x57f287))
    await log(ctx.guild, "✅ User Unbanned",
              f"**Admin:** {ctx.author.mention}\n**User:** {target.mention}\n**Reason:** {reason}", 0x57f287)


@bot.command(name="banlist")
@admin_only()
async def cmd_banlist(ctx):
    bans = bans_tbl.all()
    if not bans:
        return await ctx.send(embed=discord.Embed(description="No users are banned.", color=0x2b2d31))
    lines = [f"<@{b['user_id']}> — `{b.get('reason','?')}` — by <@{b.get('banned_by','?')}>"
             for b in bans]
    await ctx.send(embed=discord.Embed(
        title=f"🚫 Banned Users ({len(bans)})", description="\n".join(lines), color=0xed4245))


@bot.command(name="suspend")
@admin_only()
async def cmd_suspend(ctx, target: discord.Member = None):
    if not target:
        return await ctx.send(embed=discord.Embed(description="❌ Usage: `!suspend @user`", color=0xed4245))
    settings_tbl.upsert({"type": "suspension", "user_id": str(target.id),
                          "by": str(ctx.author.id), "at": datetime.now().isoformat()},
                         (Q.type == "suspension") & (Q.user_id == str(target.id)))
    records = vps_tbl.search(Q.owner_id == str(target.id))
    for r in records: await shell(f"docker stop {r['cname']}")
    await ctx.send(embed=discord.Embed(
        description=f"⏸ {target.mention} suspended. All VPS stopped.", color=0xfee75c))
    try:
        await target.send(embed=discord.Embed(
            title="⏸ Account Suspended",
            description="Your account has been suspended. All VPS stopped. Contact an admin.",
            color=0xfee75c))
    except Exception: pass
    await log(ctx.guild, "⏸ User Suspended",
              f"**Admin:** {ctx.author.mention}\n**User:** {target.mention}", 0xfee75c)


@bot.command(name="unsuspend")
@admin_only()
async def cmd_unsuspend(ctx, target: discord.Member = None):
    if not target:
        return await ctx.send(embed=discord.Embed(description="❌ Usage: `!unsuspend @user`", color=0xed4245))
    settings_tbl.remove((Q.type == "suspension") & (Q.user_id == str(target.id)))
    await ctx.send(embed=discord.Embed(
        description=f"▶ {target.mention} unsuspended.", color=0x57f287))
    try:
        await target.send(embed=discord.Embed(
            title="▶ Account Unsuspended",
            description="Your account suspension has been lifted!", color=0x57f287))
    except Exception: pass
    await log(ctx.guild, "▶ User Unsuspended",
              f"**Admin:** {ctx.author.mention}\n**User:** {target.mention}", 0x57f287)


@bot.command(name="warn")
@admin_only()
async def cmd_warn(ctx, target: discord.Member = None, *, reason: str = "No reason given."):
    if not target:
        return await ctx.send(embed=discord.Embed(description="❌ Usage: `!warn @user [reason]`", color=0xed4245))
    warns_tbl.insert({
        "user_id": str(target.id), "reason": reason,
        "by": str(ctx.author.id), "at": datetime.now().isoformat()})
    count = len(warns_tbl.search(Q.user_id == str(target.id)))
    await ctx.send(embed=discord.Embed(
        description=f"⚠️ {target.mention} warned. Total warnings: **{count}**\n**Reason:** {reason}",
        color=0xfee75c))
    try:
        await target.send(embed=discord.Embed(
            title="⚠️ You Received a Warning",
            description=f"**Reason:** {reason}\n**Total Warnings:** {count}",
            color=0xfee75c))
    except Exception: pass
    await log(ctx.guild, "⚠️ User Warned",
              f"**Admin:** {ctx.author.mention}\n**User:** {target.mention}\n**Reason:** {reason}\n**Total:** {count}",
              0xfee75c)


@bot.command(name="warnings")
@admin_only()
async def cmd_warnings(ctx, target: discord.Member = None):
    if not target:
        return await ctx.send(embed=discord.Embed(description="❌ Usage: `!warnings @user`", color=0xed4245))
    w = warns_tbl.search(Q.user_id == str(target.id))
    if not w:
        return await ctx.send(embed=discord.Embed(
            description=f"{target.mention} has no warnings.", color=0x57f287))
    lines = [f"`{i+1}.` {x['reason']} — by <@{x['by']}> on `{x['at'][:10]}`"
             for i, x in enumerate(w)]
    await ctx.send(embed=discord.Embed(
        title=f"⚠️ Warnings for {target.display_name} ({len(w)})",
        description="\n".join(lines), color=0xfee75c))


@bot.command(name="clearwarnings")
@admin_only()
async def cmd_clearwarnings(ctx, target: discord.Member = None):
    if not target:
        return await ctx.send(embed=discord.Embed(description="❌ Usage: `!clearwarnings @user`", color=0xed4245))
    warns_tbl.remove(Q.user_id == str(target.id))
    await ctx.send(embed=discord.Embed(
        description=f"✅ All warnings cleared for {target.mention}.", color=0x57f287))


@bot.command(name="userinfo")
@admin_only()
async def cmd_userinfo(ctx, target: discord.Member = None):
    target = target or ctx.author
    vps    = vps_tbl.search(Q.owner_id == str(target.id))
    inv    = inv_tbl.get(Q.user_id == str(target.id)) or {}
    warns  = warns_tbl.search(Q.user_id == str(target.id))
    banned = is_banned(target.id)
    susp   = is_suspended(target.id)
    e = discord.Embed(title=f"👤 {target.display_name}", color=0x5865f2)
    e.set_thumbnail(url=target.display_avatar.url)
    e.add_field(name="ID",       value=str(target.id),                              inline=True)
    e.add_field(name="Joined",   value=target.joined_at.strftime("%Y-%m-%d") if target.joined_at else "?", inline=True)
    e.add_field(name="Created",  value=target.created_at.strftime("%Y-%m-%d"),      inline=True)
    e.add_field(name="🐳 VPS",   value=str(len(vps)),                               inline=True)
    e.add_field(name="📨 Invites",value=str(get_valid_invites(target.id)),           inline=True)
    e.add_field(name="⚠️ Warns", value=str(len(warns)),                             inline=True)
    e.add_field(name="🚫 Banned",value="Yes" if banned else "No",                   inline=True)
    e.add_field(name="⏸ Suspended",value="Yes" if susp else "No",                  inline=True)
    if banned:
        bi = get_ban(target.id)
        e.add_field(name="Ban Reason", value=bi.get("reason","?"), inline=False)
    await ctx.send(embed=e)


# ──────────────────────────────────────────────────────────
#  ADMIN — INVITE MANAGEMENT
# ──────────────────────────────────────────────────────────

@bot.command(name="addinvites")
@admin_only()
async def cmd_addinvites(ctx, target: discord.Member = None, amount: int = None):
    if not target or amount is None:
        return await ctx.send(embed=discord.Embed(
            description="❌ Usage: `!addinvites @user <number>`", color=0xed4245))
    data = inv_tbl.get(Q.user_id == str(target.id)) or {
        "user_id": str(target.id), "valid": 0, "fakes": 0, "leaves": 0, "manual": 0}
    data["manual"] = data.get("manual", 0) + amount
    inv_tbl.upsert(data, Q.user_id == str(target.id))
    await ctx.send(embed=discord.Embed(
        description=f"✅ Added **{amount}** manual invites to {target.mention}.\n"
                    f"Total valid: **{get_valid_invites(target.id)}**", color=0x57f287))
    await log(ctx.guild, "📨 Invites Added",
              f"**Admin:** {ctx.author.mention}\n**User:** {target.mention}\n**Amount:** +{amount}", 0x5865f2)


@bot.command(name="removeinvites")
@admin_only()
async def cmd_removeinvites(ctx, target: discord.Member = None, amount: int = None):
    if not target or amount is None:
        return await ctx.send(embed=discord.Embed(
            description="❌ Usage: `!removeinvites @user <number>`", color=0xed4245))
    data = inv_tbl.get(Q.user_id == str(target.id)) or {
        "user_id": str(target.id), "valid": 0, "fakes": 0, "leaves": 0, "manual": 0}
    data["manual"] = data.get("manual", 0) - amount
    inv_tbl.upsert(data, Q.user_id == str(target.id))
    await ctx.send(embed=discord.Embed(
        description=f"✅ Removed **{amount}** invites from {target.mention}.\n"
                    f"Total valid: **{get_valid_invites(target.id)}**", color=0x57f287))


@bot.command(name="resetinvites")
@admin_only()
async def cmd_resetinvites(ctx, target: discord.Member = None):
    if not target:
        return await ctx.send(embed=discord.Embed(
            description="❌ Usage: `!resetinvites @user`", color=0xed4245))
    inv_tbl.remove(Q.user_id == str(target.id))
    await ctx.send(embed=discord.Embed(
        description=f"✅ Invites reset for {target.mention}.", color=0x57f287))


@bot.command(name="setminage")
@admin_only()
async def cmd_setminage(ctx, days: int = None):
    if days is None:
        return await ctx.send(embed=discord.Embed(
            description="❌ Usage: `!setminage <days>`", color=0xed4245))
    config.MIN_ACCOUNT_AGE_DAYS = days
    await ctx.send(embed=discord.Embed(
        description=f"✅ Minimum account age for valid invites set to **{days} days**.", color=0x57f287))


@bot.command(name="invitecheck")
@admin_only()
async def cmd_invitecheck(ctx, target: discord.Member = None):
    if not target:
        return await ctx.send(embed=discord.Embed(
            description="❌ Usage: `!invitecheck @user`", color=0xed4245))
    data   = inv_tbl.get(Q.user_id == str(target.id)) or {}
    people = invited_tbl.search(Q.inviter_id == str(target.id))
    lines  = []
    for p in people[:15]:
        tag  = "❌ Fake" if p.get("fake") else "✅ Valid"
        date = p.get("joined_at", "?")[:10]
        lines.append(f"{tag} — <@{p['member_id']}> — joined `{date}`")
    e = discord.Embed(title=f"🔍 Invite Audit — {target.display_name}", color=0x5865f2)
    e.add_field(name="Valid",   value=str(data.get("valid",  0)), inline=True)
    e.add_field(name="Fakes",  value=str(data.get("fakes",  0)), inline=True)
    e.add_field(name="Leaves", value=str(data.get("leaves", 0)), inline=True)
    e.add_field(name="Manual", value=str(data.get("manual", 0)), inline=True)
    if lines:
        e.add_field(name="Invited Users (up to 15)",
                    value="\n".join(lines) if lines else "None", inline=False)
    await ctx.send(embed=e)


# ──────────────────────────────────────────────────────────
#  ADMIN — SYSTEM CONFIG
# ──────────────────────────────────────────────────────────

@bot.command(name="setprefix")
@admin_only()
async def cmd_setprefix(ctx, prefix: str = None):
    if not prefix:
        return await ctx.send(embed=discord.Embed(
            description="❌ Usage: `!setprefix <char>`", color=0xed4245))
    upd_guild_cfg(ctx.guild.id, {"prefix": prefix})
    await ctx.send(embed=discord.Embed(
        description=f"✅ Prefix changed to `{prefix}`", color=0x57f287))


@bot.command(name="setlogs")
@admin_only()
async def cmd_setlogs(ctx, channel: discord.TextChannel = None):
    if not channel:
        return await ctx.send(embed=discord.Embed(
            description="❌ Usage: `!setlogs #channel`", color=0xed4245))
    upd_guild_cfg(ctx.guild.id, {"log_channel": str(channel.id)})
    await ctx.send(embed=discord.Embed(
        description=f"✅ Log channel set to {channel.mention}", color=0x57f287))


@bot.command(name="setticket")
@admin_only()
async def cmd_setticket(ctx, channel: discord.TextChannel = None):
    if not channel:
        return await ctx.send(embed=discord.Embed(
            description="❌ Usage: `!setticket #channel`", color=0xed4245))
    upd_guild_cfg(ctx.guild.id, {"ticket_channel": str(channel.id)})
    await ctx.send(embed=discord.Embed(
        description=f"✅ Ticket channel set to {channel.mention}", color=0x57f287))


@bot.command(name="setannounce")
@admin_only()
async def cmd_setannounce(ctx, channel: discord.TextChannel = None):
    if not channel:
        return await ctx.send(embed=discord.Embed(
            description="❌ Usage: `!setannounce #channel`", color=0xed4245))
    upd_guild_cfg(ctx.guild.id, {"announce_channel": str(channel.id)})
    await ctx.send(embed=discord.Embed(
        description=f"✅ Announcement channel set to {channel.mention}", color=0x57f287))


@bot.command(name="all")
@admin_only()
async def cmd_all(ctx, *, message: str = None):
    """Admin: Broadcast a message to all VPS owners via DM and announce channel."""
    if not message:
        return await ctx.send(embed=discord.Embed(
            description="❌ Usage: `!all <message>`", color=0xed4245))
    users = list({r["owner_id"] for r in vps_tbl.all()})
    sent  = 0
    prog  = await ctx.send(embed=discord.Embed(
        description=f"📢 Sending to {len(users)} users...", color=0xfee75c))
    for uid in users:
        try:
            u = await bot.fetch_user(int(uid))
            await u.send(embed=discord.Embed(
                title="📢 Announcement from Ghost VPS",
                description=message, color=0xfee75c,
                timestamp=datetime.now(timezone.utc)))
            sent += 1
        except Exception: pass
    # Also post in announce channel
    cfg = get_guild_cfg(ctx.guild.id)
    ann_id = cfg.get("announce_channel")
    if ann_id:
        ch = ctx.guild.get_channel(int(ann_id))
        if ch:
            await ch.send(
                content=" ".join([f"<@{r['owner_id']}>" for r in vps_tbl.all()[:50]]),
                embed=discord.Embed(title="📢 Announcement",
                                    description=f"# {message}", color=0xfee75c,
                                    timestamp=datetime.now(timezone.utc)))
    await prog.edit(embed=discord.Embed(
        description=f"✅ Announcement sent to **{sent}/{len(users)}** users.", color=0x57f287))
    await log(ctx.guild, "📢 Announcement Sent",
              f"**Admin:** {ctx.author.mention}\n**Message:** {message}\n**Sent:** {sent}/{len(users)}", 0xfee75c)


@bot.command(name="maintenance")
@admin_only()
async def cmd_maintenance(ctx, mode: str = None):
    if mode not in ("on", "off"):
        return await ctx.send(embed=discord.Embed(
            description="❌ Usage: `!maintenance on` or `!maintenance off`", color=0xed4245))
    upd_guild_cfg(ctx.guild.id, {"maintenance": mode == "on"})
    color = 0xfee75c if mode == "on" else 0x57f287
    await ctx.send(embed=discord.Embed(
        description=f"🔧 Maintenance mode: **{'ON' if mode=='on' else 'OFF'}**", color=color))


@bot.command(name="shutdown")
@admin_only()
async def cmd_shutdown(ctx):
    """Admin: Stop ALL non-admin VPS and disable free tier."""
    def chk(m): return m.author == ctx.author and m.channel == ctx.channel
    await ctx.send(embed=discord.Embed(
        title="⚠️ Confirm Shutdown",
        description="Type `confirm` to **stop all normal VPS** and pause free tier.",
        color=0xfee75c))
    try:
        m = await bot.wait_for("message", check=chk, timeout=30)
        if m.content.lower() != "confirm":
            return await ctx.send(embed=discord.Embed(description="❌ Cancelled.", color=0x2b2d31))
    except asyncio.TimeoutError:
        return await ctx.send(embed=discord.Embed(description="⏱ Cancelled.", color=0x2b2d31))

    upd_guild_cfg(ctx.guild.id, {"free_enabled": False})
    all_vps = vps_tbl.search(Q.tier != "admin")
    stopped = 0
    for r in all_vps:
        await shell(f"docker stop {r['cname']}")
        stopped += 1
    await ctx.send(embed=discord.Embed(
        description=f"🔴 **Shutdown complete.** Stopped `{stopped}` VPS. Free tier disabled.",
        color=0xed4245))
    await log(ctx.guild, "🔴 System Shutdown",
              f"**Admin:** {ctx.author.mention}\n**VPS Stopped:** {stopped}", 0xed4245)


@bot.command(name="resume")
@admin_only()
async def cmd_resume(ctx):
    """Admin: Start all previously stopped VPS and re-enable free tier."""
    upd_guild_cfg(ctx.guild.id, {"free_enabled": True})
    all_vps = vps_tbl.search(Q.tier != "admin")
    started = 0
    for r in all_vps:
        await shell(f"docker start {r['cname']}")
        started += 1
    await ctx.send(embed=discord.Embed(
        description=f"🟢 **Resumed.** Started `{started}` VPS. Free tier enabled.",
        color=0x57f287))
    await log(ctx.guild, "🟢 System Resumed",
              f"**Admin:** {ctx.author.mention}\n**VPS Started:** {started}", 0x57f287)


@bot.command(name="enablefree")
@admin_only()
async def cmd_enablefree(ctx):
    upd_guild_cfg(ctx.guild.id, {"free_enabled": True})
    await ctx.send(embed=discord.Embed(description="✅ Free VPS tier **enabled**.", color=0x57f287))


@bot.command(name="disablefree")
@admin_only()
async def cmd_disablefree(ctx):
    upd_guild_cfg(ctx.guild.id, {"free_enabled": False})
    await ctx.send(embed=discord.Embed(description="🚫 Free VPS tier **disabled**.", color=0xed4245))


@bot.command(name="changenormal")
@admin_only()
async def cmd_changenormal(ctx, vps_type: str = None):
    if vps_type not in ("lxc", "docker"):
        return await ctx.send(embed=discord.Embed(
            description="❌ Usage: `!changenormal lxc` or `!changenormal docker`", color=0xed4245))
    upd_guild_cfg(ctx.guild.id, {"vps_type": vps_type})
    await ctx.send(embed=discord.Embed(
        description=f"✅ Default VPS type label set to **{vps_type.upper()}**.", color=0x57f287))


@bot.command(name="limits")
@admin_only()
async def cmd_limits(ctx, target: discord.Member = None, n: int = None):
    """Admin: Set max VPS count for a user."""
    if not target:
        return await ctx.send(embed=discord.Embed(
            description="❌ Usage: `!limits @user [max_vps]`", color=0xed4245))
    if n is None:
        # Show current
        rec = settings_tbl.get((Q.type == "limit") & (Q.user_id == str(target.id)))
        cur = rec["limit"] if rec else 1
        return await ctx.send(embed=discord.Embed(
            description=f"📊 {target.mention} VPS limit: **{cur}**", color=0x2b2d31))
    settings_tbl.upsert({"type": "limit", "user_id": str(target.id), "limit": n},
                         (Q.type == "limit") & (Q.user_id == str(target.id)))
    await ctx.send(embed=discord.Embed(
        description=f"✅ VPS limit for {target.mention} set to **{n}**.", color=0x57f287))


@bot.command(name="botcustom")
@admin_only()
async def cmd_botcustom(ctx):
    """Admin: Customize bot status."""
    def chk(m): return m.author == ctx.author and m.channel == ctx.channel

    async def ask(prompt):
        await ctx.send(embed=discord.Embed(description=prompt, color=0x5865f2))
        try:
            m = await bot.wait_for("message", check=chk, timeout=60)
            return m.content.strip()
        except asyncio.TimeoutError: return None

    status_txt = await ask(
        "**Bot Custom Status**\nEnter new status text (or `skip`):")
    if status_txt and status_txt.lower() != "skip":
        await bot.change_presence(
            activity=discord.Activity(type=discord.ActivityType.watching, name=status_txt),
            status=discord.Status.online)

    status_type = await ask(
        "**Status Type** — type one: `online` `idle` `dnd` `invisible`:")
    if status_type:
        mapping = {"online": discord.Status.online, "idle": discord.Status.idle,
                   "dnd": discord.Status.dnd, "invisible": discord.Status.invisible}
        st = mapping.get(status_type.lower(), discord.Status.online)
        await bot.change_presence(status=st)

    await ctx.send(embed=discord.Embed(description="✅ Bot appearance updated!", color=0x57f287))


@bot.command(name="backup")
@admin_only()
async def cmd_backup(ctx):
    """Admin: Manually trigger a database backup."""
    ts = datetime.now().strftime("%Y%m%d-%H%M%S")
    backed = []
    for f in ["vps","guild","invites","bans","tickets","warnings","settings"]:
        src = f"data/{f}.json"
        if os.path.exists(src):
            dst = f"backups/{f}-{ts}.json"
            shutil.copy2(src, dst)
            backed.append(f)
    await ctx.send(embed=discord.Embed(
        title="💾 Backup Complete",
        description=f"Backed up: `{'`, `'.join(backed)}`\nTimestamp: `{ts}`",
        color=0x57f287))


@bot.command(name="restorebackup")
@admin_only()
async def cmd_restorebackup(ctx, filename: str = None):
    """Admin: Restore a specific DB backup file."""
    if not filename:
        files = sorted(glob.glob("backups/*.json"))[-20:]
        names = "\n".join(f"`{os.path.basename(f)}`" for f in files)
        return await ctx.send(embed=discord.Embed(
            title="💾 Available Backups",
            description=names or "No backups found.", color=0x2b2d31))
    src = f"backups/{filename}"
    if not os.path.exists(src):
        return await ctx.send(embed=discord.Embed(description="❌ File not found.", color=0xed4245))
    table = filename.split("-")[0]
    dst   = f"data/{table}.json"
    shutil.copy2(src, dst)
    await ctx.send(embed=discord.Embed(
        description=f"✅ Restored `{filename}` → `{dst}`.\n⚠️ Restart the bot for full effect.",
        color=0x57f287))


@bot.command(name="wipeall")
@admin_only()
async def cmd_wipeall(ctx):
    """Admin: Factory reset — delete ALL VPS and clear DB."""
    def chk(m): return m.author == ctx.author and m.channel == ctx.channel
    await ctx.send(embed=discord.Embed(
        title="☢️ DANGER — Factory Reset",
        description="Type `CONFIRM WIPE` to **delete ALL VPS containers and clear the database!**",
        color=0xed4245))
    try:
        m = await bot.wait_for("message", check=chk, timeout=30)
        if m.content != "CONFIRM WIPE":
            return await ctx.send(embed=discord.Embed(description="❌ Cancelled.", color=0x2b2d31))
    except asyncio.TimeoutError:
        return await ctx.send(embed=discord.Embed(description="⏱ Cancelled.", color=0x2b2d31))
    # Delete all containers
    all_vps = vps_tbl.all()
    for r in all_vps:
        await shell(f"docker rm -f {r['cname']}")
    vps_tbl.truncate()
    await ctx.send(embed=discord.Embed(
        description=f"☢️ **Wiped.** Deleted `{len(all_vps)}` containers and cleared VPS database.",
        color=0xed4245))
    await log(ctx.guild, "☢️ Factory Reset",
              f"**Admin:** {ctx.author.mention}\n**Deleted:** {len(all_vps)} containers", 0xed4245)


# ──────────────────────────────────────────────────────────
#  START
# ──────────────────────────────────────────────────────────
if __name__ == "__main__":
    print("Starting Ghost VPS Bot...")
    bot.run(config.TOKEN)
