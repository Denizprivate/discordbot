#!/usr/bin/env python3
"""
╔═══════════════════════════════════════════════════════════╗
║        GHOST VPS BOT — MEGA EDITION v2.0                 ║
║    100+ Commands | Docker VPS | No Limits | LXC Ready    ║
╚═══════════════════════════════════════════════════════════╝
"""

import discord
from discord.ext import commands, tasks
import asyncio, json, os, sys, time, psutil, random, string
import shutil, tempfile, glob, platform, re
from datetime import datetime, timedelta, timezone
from tinydb import TinyDB, Query
import config

os.makedirs("data", exist_ok=True)
os.makedirs("backups", exist_ok=True)

_vps_db = TinyDB("data/vps.json")
_guild_db = TinyDB("data/guild.json")
_invites_db = TinyDB("data/invites.json")
_bans_db = TinyDB("data/bans.json")
_tickets_db = TinyDB("data/tickets.json")
_warns_db = TinyDB("data/warnings.json")
_settings_db = TinyDB("data/settings.json")
_tiers_db = TinyDB("data/custom_tiers.json")

vps_tbl = _vps_db.table("vps")
guild_tbl = _guild_db.table("guild")
inv_tbl = _invites_db.table("invites")
invited_tbl = _invites_db.table("invited")
bans_tbl = _bans_db.table("bans")
tickets_tbl = _tickets_db.table("tickets")
warns_tbl = _warns_db.table("warnings")
settings_tbl = _settings_db.table("settings")
tiers_tbl = _tiers_db.table("tiers")

Q = Query()
START_TIME = time.time()
inv_cache = {}

def gen_id(n=6): return "".join(random.choices(string.ascii_lowercase + string.digits, k=n))
def fmt_uptime(s): d,r=divmod(int(s),86400); h,r=divmod(r,3600); m,_=divmod(r,60); return f"{d}d {h}h {m}m"
def safe_name(t, m=16): return "".join(c for c in t.lower() if c.isalnum())[:m] or gen_id(6)
def is_admin(ctx): return (ctx.author.id if hasattr(ctx,"author") else ctx.id) in config.ADMIN_IDS
def is_banned(uid): return bans_tbl.contains(Q.user_id == str(uid))
def get_ban(uid): return bans_tbl.get(Q.user_id == str(uid)) or {}
def is_suspended(uid): return settings_tbl.contains((Q.type=="suspension")&(Q.user_id==str(uid)))
def get_valid_invites(uid): d=inv_tbl.get(Q.user_id==str(uid)) or {}; return max(0, d.get("valid",0)+d.get("manual",0)-d.get("leaves",0))

def get_guild_cfg(gid):
    g = str(gid)
    cfg = guild_tbl.get(Q.guild_id == g)
    if not cfg:
        cfg = {"guild_id":g,"prefix":"!","log_channel":None,"ticket_channel":None,"announce_channel":None,
               "free_enabled":True,"maintenance":False,"vps_type":"docker","setup_done":False,
               "ticket_category":None,"ticket_message":"Click button to open ticket"}
        guild_tbl.insert(cfg)
    return cfg

def upd_guild_cfg(gid, updates): cfg=get_guild_cfg(gid); cfg.update(updates); guild_tbl.upsert(cfg, Q.guild_id==str(gid))

async def shell(cmd):
    p = await asyncio.create_subprocess_shell(cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
    out, err = await p.communicate()
    return out.decode(errors='ignore').strip(), err.decode(errors='ignore').strip(), p.returncode

async def log(guild, title, desc, color=0x5865F2):
    if not guild: return
    cfg = get_guild_cfg(guild.id)
    cid = cfg.get("log_channel") or (config.LOG_CHANNEL if hasattr(config, 'LOG_CHANNEL') else None)
    if not cid: return
    ch = guild.get_channel(int(cid))
    if not ch: return
    e = discord.Embed(title=title, description=desc, color=color, timestamp=datetime.now(timezone.utc))
    e.set_footer(text="Ghost VPS Bot")
    try: await ch.send(embed=e)
    except: pass

# ══════════════════════════════════════════════════════════
#  DOCKER — FIXED tmate/sshx + unlimited cores
# ══════════════════════════════════════════════════════════
async def docker_running(n): out,_,_=await shell(f"docker inspect -f '{{{{.State.Running}}}}' {n} 2>/dev/null"); return out.strip()=="true"
async def docker_status(n): out,_,_=await shell(f"docker inspect -f '{{{{.State.Status}}}}' {n} 2>/dev/null"); return out.strip() or "unknown"

async def get_links_fresh_sshx(name):
    """Get tmate + FRESH SSHX link (kills old sshx, starts new)."""
    # Get tmate (doesn't change)
    tmate_out, _, _ = await shell(f"docker exec {name} cat /root/tmate.log 2>/dev/null | grep 'ssh session' | tail -1")
    tmate = ""
    if "ssh session:" in tmate_out:
        parts = tmate_out.split("ssh session:")
        if len(parts) > 1:
            raw = parts[1].strip()
            tmate = raw.split()[0] if raw else ""
    
    # Kill old sshx and start fresh one
    await shell(f"docker exec {name} pkill -9 sshx 2>/dev/null || true")
    await shell(f"docker exec -d {name} sh -c 'curl -sSf https://sshx.io/get | sh -s run >> /root/sshx_new.log 2>&1'")
    await asyncio.sleep(8)  # Wait for new link
    
    # Get FRESH sshx link
    sshx_out, _, _ = await shell(f"docker exec {name} cat /root/sshx_new.log 2>/dev/null | grep 'https://sshx.io' | tail -1")
    sshx = ""
    if "https://sshx.io" in sshx_out:
        match = re.search(r'https://sshx\.io/[^\s]+', sshx_out)
        if match:
            sshx = match.group(0)
            # Remove ANSI codes like [0m, [1;31m
            sshx = re.sub(r'\x1b\[[0-9;]*m', '', sshx)
            sshx = re.sub(r'\[0m', '', sshx)
    
    return tmate, sshx


async def get_links(name):
    """FIXED: Better patterns + encoding."""
    tmate_out, _, _ = await shell(f"docker exec {name} cat /root/tmate.log 2>/dev/null | grep 'ssh session' | tail -1")
    tmate = ""
    if "ssh session:" in tmate_out:
        parts = tmate_out.split("ssh session:")
        if len(parts) > 1:
            raw = parts[1].strip()
            tmate = raw.split()[0] if raw else ""
    
    sshx_out, _, _ = await shell(f"docker exec {name} cat /root/sshx.log 2>/dev/null | grep 'https://sshx.io' | tail -1")
    sshx = ""
    if "https://sshx.io" in sshx_out:
        match = re.search(r'https://sshx\.io/[^\s]+', sshx_out)
        if match:
            sshx = match.group(0)
    
    return tmate, sshx

async def wait_links(name, timeout=300):
    """FIXED: 5min timeout instead of 2min."""
    for i in range(timeout // 5):
        t, s = await get_links(name)
        if t or s:
            return t, s
        await asyncio.sleep(5)
    return "", ""

SETUP_SCRIPT = r"""
export DEBIAN_FRONTEND=noninteractive
mkdir -p /root /var/run/sshd
apt-get update -qq 2>/dev/null
apt-get install -y -qq curl wget sudo tmate openssh-server screen htop 2>/dev/null
/usr/sbin/sshd &
nohup tmate -S /tmp/tmate.sock new-session -d >> /root/tmate.log 2>&1 &
sleep 12
tmate -S /tmp/tmate.sock display -p '#{tmate_ssh}' >> /root/tmate.log 2>&1
echo "TMATE_DONE" >> /root/tmate.log
nohup sh -c 'curl -sSf https://sshx.io/get | sh -s run >> /root/sshx.log 2>&1' &
"""

async def create_docker_vps(cname, image, ram, cpus):
    """UNLIMITED cores + better fallback."""
    await shell(f"docker rm -f {cname} 2>/dev/null; true")
    _, pull_err, pull_rc = await shell(f"docker pull {image}")
    if pull_rc != 0: raise RuntimeError(f"Pull failed: {pull_err}")
    
    BASE = f"--memory {ram} --cpus {cpus} --restart {config.DOCKER_RESTART} "
    ATTEMPTS = [
        f"docker run -d --name {cname} {BASE}--privileged --network {config.DOCKER_NETWORK} {image} /bin/sh -c 'tail -f /dev/null'",
        f"docker run -d --name {cname} {BASE}--privileged --network host {image} /bin/sh -c 'tail -f /dev/null'",
        f"docker run -d --name {cname} --restart {config.DOCKER_RESTART} --network host {image} /bin/sh -c 'tail -f /dev/null'",
    ]
    
    success = False
    for cmd in ATTEMPTS:
        _, err, rc = await shell(cmd)
        if rc == 0: success = True; break
        await shell(f"docker rm -f {cname} 2>/dev/null; true")
    
    if not success:
        raise RuntimeError("All attempts failed. Run: bash fix_docker_lxc.sh")
    
    await asyncio.sleep(4)
    _, _, bash_rc = await shell(f"docker exec {cname} which bash 2>/dev/null")
    shell_bin = "bash" if bash_rc == 0 else "sh"
    
    with tempfile.NamedTemporaryFile(mode="w", suffix=".sh", delete=False) as f:
        f.write(SETUP_SCRIPT)
        tmp_path = f.name
    try:
        await shell(f"docker cp {tmp_path} {cname}:/root/_setup.sh")
    finally:
        os.unlink(tmp_path)
    
    await shell(f"docker exec -d {cname} {shell_bin} /root/_setup.sh")

OS_LIST = ["ubuntu:24.04","ubuntu:22.04","ubuntu:20.04","debian:12","debian:11","alpine:3.19","centos:7","fedora:40","archlinux","rockylinux:9","kalilinux/kali-rolling"]

async def run_wizard(ctx):
    """UNLIMITED cores/RAM."""
    def chk(m): return m.author == ctx.author and m.channel == ctx.channel
    async def q(embed):
        await ctx.send(embed=embed)
        try:
            m = await bot.wait_for("message", check=chk, timeout=90)
            return m.content.strip()
        except asyncio.TimeoutError:
            await ctx.send(embed=discord.Embed(description="⏱ Timed out.", color=0xed4245))
            return None
    
    os_txt = "\n".join(f"`{i+1}` {o}" for i, o in enumerate(OS_LIST))
    raw = await q(discord.Embed(title="⚙️ 1/5 — OS", description=f"{os_txt}\n\nType number:", color=0x5865f2))
    if raw is None: return None
    try: image = OS_LIST[int(raw) - 1]
    except: image = "ubuntu:24.04"
    
    raw = await q(discord.Embed(title="2/5 — RAM", description="RAM (e.g. `512m`, `1g`, `64g` — UNLIMITED!):", color=0x5865f2))
    if raw is None: return None
    ram = raw.lower()
    if not (ram.endswith("m") or ram.endswith("g")): ram += "g"
    
    raw = await q(discord.Embed(title="3/5 — CPU", description="Cores (e.g. `1`, `20`, `100` — UNLIMITED!):", color=0x5865f2))
    if raw is None: return None
    try: cpus = str(max(1, int(raw)))
    except: cpus = "1"
    
    raw = await q(discord.Embed(title="4/5 — Storage", description="Storage note (display only):", color=0x5865f2))
    if raw is None: return None
    storage = (raw.upper() + "GB") if not raw.upper().endswith(("GB","TB")) else raw.upper()
    
    raw = await q(discord.Embed(title="5/5 — Name", description="VPS name:", color=0x5865f2))
    if raw is None: return None
    name = safe_name(raw)
    
    return {"image": image, "ram": ram, "cpus": cpus, "storage": storage, "name": name}

# ══════════════════════════════════════════════════════════
#  PERSISTENT VIEWS
# ══════════════════════════════════════════════════════════
class VPSPanel(discord.ui.View):
    def __init__(self, vps_id="placeholder"):
        super().__init__(timeout=None)
        self.vps_id = vps_id
    
    def _rec(self): return vps_tbl.get(Q.vps_id == self.vps_id)
    
    @discord.ui.button(label="▶ Start", emoji="🟢", style=discord.ButtonStyle.success, custom_id="vp_start")
    async def btn_start(self, i: discord.Interaction, _):
        await i.response.defer(ephemeral=True)
        r = self._rec()
        if not r: return await i.followup.send("❌ Not found.", ephemeral=True)
        n = r["cname"]
        if await docker_running(n):
            return await i.followup.send("⚠️ Already running!", ephemeral=True)
        await shell(f"docker start {n}")
        await i.followup.send(f"✅ Starting `{n}`...", ephemeral=True)
    
    @discord.ui.button(label="⏹ Stop", emoji="🔴", style=discord.ButtonStyle.danger, custom_id="vp_stop")
    async def btn_stop(self, i: discord.Interaction, _):
        await i.response.defer(ephemeral=True)
        r = self._rec()
        if not r: return await i.followup.send("❌ Not found.", ephemeral=True)
        await shell(f"docker stop {r['cname']}")
        await i.followup.send("🛑 Stopped.", ephemeral=True)
    
    @discord.ui.button(label="🔄 Restart", emoji="🔄", style=discord.ButtonStyle.secondary, custom_id="vp_restart")
    async def btn_restart(self, i: discord.Interaction, _):
        await i.response.defer(ephemeral=True)
        r = self._rec()
        if not r: return await i.followup.send("❌ Not found.", ephemeral=True)
        await shell(f"docker restart {r['cname']}")
        await i.followup.send("🔄 Restarted!", ephemeral=True)
    
    @discord.ui.button(label="📊 Stats", emoji="📊", style=discord.ButtonStyle.secondary, custom_id="vp_refresh")
    async def btn_refresh(self, i: discord.Interaction, _):
        await i.response.defer(ephemeral=True)
        r = self._rec()
        if not r: return await i.followup.send("❌ Not found.", ephemeral=True)
        n = r["cname"]
        status = await docker_status(n)
        st_raw, _, _ = await shell(f"docker stats {n} --no-stream --format '{{{{.CPUPerc}}}} {{{{.MemUsage}}}}' 2>/dev/null")
        dot = "🟢" if status == "running" else "🔴"
        e = discord.Embed(title=f"📊 {n}", color=0x2b2d31)
        e.add_field(name="Status", value=f"{dot} `{status.upper()}`", inline=True)
        e.add_field(name="VPS ID", value=f"`{self.vps_id}`", inline=True)
        if st_raw:
            parts = st_raw.split()
            e.add_field(name="CPU", value=f"`{parts[0]}`", inline=True)
            e.add_field(name="RAM", value=f"`{' '.join(parts[1:])}`", inline=True)
        await i.followup.send(embed=e, ephemeral=True)
    
    @discord.ui.button(label="🖥 SSHX", emoji="🖥", style=discord.ButtonStyle.primary, custom_id="vp_sshx")
    async def btn_sshx(self, i: discord.Interaction, _):
        await i.response.defer(ephemeral=True)
        r = self._rec()
        if not r: return await i.followup.send("❌ Not found.", ephemeral=True)
        _, sshx = await get_links_fresh_sshx(r["cname"])
        if sshx:
            await i.followup.send(embed=discord.Embed(title="🖥 SSHX", description=sshx, color=0x5865f2), ephemeral=True)
        else:
            await i.followup.send("❌ SSHX not ready.", ephemeral=True)
    
    @discord.ui.button(label="📟 tmate", emoji="📟", style=discord.ButtonStyle.secondary, custom_id="vp_tmate")
    async def btn_tmate(self, i: discord.Interaction, _):
        await i.response.defer(ephemeral=True)
        r = self._rec()
        if not r: return await i.followup.send("❌ Not found.", ephemeral=True)
        tmate, _ = await get_links(r["cname"])
        if tmate:
            await i.followup.send(embed=discord.Embed(title="📟 tmate", description=f"`{tmate}`", color=0x5865f2), ephemeral=True)
        else:
            await i.followup.send("❌ tmate not ready.", ephemeral=True)

class TicketPanel(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)
    def _admin(self, u): return u.id in config.ADMIN_IDS
    
    @discord.ui.button(label="🔒 Lock", style=discord.ButtonStyle.secondary, custom_id="tk_lock")
    async def btn_lock(self, i: discord.Interaction, _):
        if not self._admin(i.user): return await i.response.send_message("❌ Admins only.", ephemeral=True)
        tk = tickets_tbl.get(Q.channel_id == str(i.channel.id))
        if tk:
            m = i.guild.get_member(int(tk["user_id"]))
            if m: await i.channel.set_permissions(m, send_messages=False)
        await i.response.send_message("🔒 Locked.", ephemeral=False)
    
    @discord.ui.button(label="🔓 Unlock", style=discord.ButtonStyle.success, custom_id="tk_unlock")
    async def btn_unlock(self, i: discord.Interaction, _):
        if not self._admin(i.user): return await i.response.send_message("❌ Admins only.", ephemeral=True)
        tk = tickets_tbl.get(Q.channel_id == str(i.channel.id))
        if tk:
            m = i.guild.get_member(int(tk["user_id"]))
            if m: await i.channel.set_permissions(m, send_messages=True)
        await i.response.send_message("🔓 Unlocked.", ephemeral=False)
    
    @discord.ui.button(label="✋ Claim", style=discord.ButtonStyle.primary, custom_id="tk_claim")
    async def btn_claim(self, i: discord.Interaction, _):
        if not self._admin(i.user): return await i.response.send_message("❌ Admins only.", ephemeral=True)
        tickets_tbl.update({"claimed_by": str(i.user.id)}, Q.channel_id == str(i.channel.id))
        await i.response.send_message(f"✋ Claimed by {i.user.mention}.", ephemeral=False)
    
    @discord.ui.button(label="🗑 Delete", style=discord.ButtonStyle.danger, custom_id="tk_delete")
    async def btn_delete(self, i: discord.Interaction, _):
        if not self._admin(i.user): return await i.response.send_message("❌ Admins only.", ephemeral=True)
        await i.response.send_message("🗑 Deleting in 5s...", ephemeral=False)
        tickets_tbl.remove(Q.channel_id == str(i.channel.id))
        await asyncio.sleep(5)
        try: await i.channel.delete()
        except: pass

class OpenTicketView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)
    
    @discord.ui.button(label="🎫 Open Ticket", style=discord.ButtonStyle.success, emoji="📩", custom_id="openticket")
    async def btn_open(self, i: discord.Interaction, _):
        user = i.user
        guild = i.guild
        if is_banned(user.id):
            bi = get_ban(user.id)
            return await i.response.send_message(embed=discord.Embed(
                title="🚫 Banned", description=f"Reason: {bi.get('reason','N/A')}", color=0xed4245), ephemeral=True)
        existing = tickets_tbl.get((Q.guild_id == str(guild.id)) & (Q.user_id == str(user.id)) & (Q.status == "open"))
        if existing:
            ch = guild.get_channel(int(existing["channel_id"]))
            if ch: return await i.response.send_message(f"❌ Already have ticket: {ch.mention}", ephemeral=True)
        await i.response.defer(ephemeral=True)
        ow = {
            guild.default_role: discord.PermissionOverwrite(read_messages=False),
            user: discord.PermissionOverwrite(read_messages=True, send_messages=True),
            guild.me: discord.PermissionOverwrite(read_messages=True, send_messages=True, manage_channels=True),
        }
        for aid in config.ADMIN_IDS:
            m = guild.get_member(aid)
            if m: ow[m] = discord.PermissionOverwrite(read_messages=True, send_messages=True, manage_channels=True)
        try:
            ch = await guild.create_text_channel(f"ticket-{user.name[:10].lower()}-{gen_id(4)}", overwrites=ow,
                                                   topic=f"Support ticket for {user} ({user.id})")
        except Exception as e:
            return await i.followup.send(f"❌ Could not create channel: {e}", ephemeral=True)
        tickets_tbl.insert({"guild_id": str(guild.id), "channel_id": str(ch.id), "user_id": str(user.id),
                            "status": "open", "claimed_by": None, "created_at": datetime.now().isoformat()})
        embed = discord.Embed(title="🎫 Ticket Opened", description=f"Welcome {user.mention}!\nStaff will assist you shortly.\n\n**Opened by:** {user.mention} (`{user.id}`)",
                              color=0x5865f2, timestamp=datetime.now(timezone.utc))
        await ch.send(embed=embed, view=TicketPanel())
        await i.followup.send(f"✅ Ticket created: {ch.mention}", ephemeral=True)
        await log(guild, "🎫 Ticket Opened", f"**User:** {user.mention}\n**Channel:** {ch.mention}", 0x5865f2)

# ══════════════════════════════════════════════════════════
#  BOT SETUP
# ══════════════════════════════════════════════════════════
intents = discord.Intents.all()
def get_prefix(bot_, msg):
    if msg.guild:
        cfg = get_guild_cfg(msg.guild.id)
        return [cfg.get("prefix", "!")]
    return ["!"]

bot = commands.Bot(command_prefix=get_prefix, intents=intents, help_command=None)

def admin_only():
    async def pred(ctx):
        if not is_admin(ctx):
            await ctx.send(embed=discord.Embed(description="🚫 Admin only.", color=0xed4245), delete_after=6)
            return False
        return True
    return commands.check(pred)

@bot.event
async def on_ready():
    print("="*52)
    print(f"  ✅  {bot.user.name} MEGA v2.0")
    print(f"  🆔  ID: {bot.user.id}")
    print(f"  🏠  Guilds: {len(bot.guilds)}")
    print("="*52)
    for g in bot.guilds:
        try: inv_cache[g.id] = await g.invites()
        except: pass
    await bot.change_presence(activity=discord.Activity(type=discord.ActivityType.watching, name="🐳 Docker VPS"),
                               status=discord.Status.online)
    bot.add_view(VPSPanel())
    bot.add_view(TicketPanel())
    bot.add_view(OpenTicketView())
    auto_backup.start()

@bot.event
async def on_guild_join(guild):
    owner = guild.owner
    embed = discord.Embed(title="👋 Ghost VPS Bot MEGA", description=f"Thanks for adding me!\n\n"
                          f"`!setup` — Setup wizard\n`!help` — All commands", color=0x5865f2)
    try:
        if owner: await owner.send(embed=embed)
    except:
        for ch in guild.text_channels:
            if ch.permissions_for(guild.me).send_messages:
                await ch.send(embed=embed)
                break

@bot.event
async def on_invite_create(inv):
    try: inv_cache[inv.guild.id] = await inv.guild.invites()
    except: pass

@bot.event
async def on_invite_delete(inv):
    try: inv_cache[inv.guild.id] = await inv.guild.invites()
    except: pass

@bot.event
async def on_member_join(member):
    guild = member.guild
    old_invs = inv_cache.get(guild.id, [])
    try: new_invs = await guild.invites()
    except: return
    used = None
    for old in old_invs:
        for new in new_invs:
            if old.code == new.code and new.uses > old.uses:
                used = new; break
    inv_cache[guild.id] = new_invs
    if not used or not used.inviter: return
    age_days = (discord.utils.utcnow() - member.created_at).days
    fake = (age_days < config.MIN_ACCOUNT_AGE_DAYS or (config.REQUIRE_AVATAR and not member.avatar))
    data = inv_tbl.get(Q.user_id == str(used.inviter.id)) or {"user_id": str(used.inviter.id), "valid": 0, "fakes": 0, "leaves": 0, "manual": 0, "pending_vps": False}
    if fake: data["fakes"] = data.get("fakes", 0) + 1
    else: data["valid"] = data.get("valid", 0) + 1
    inv_tbl.upsert(data, Q.user_id == str(used.inviter.id))
    invited_tbl.upsert({"member_id": str(member.id), "inviter_id": str(used.inviter.id), "fake": fake, "joined_at": datetime.now().isoformat()}, Q.member_id == str(member.id))

@bot.event
async def on_member_remove(member):
    rec = invited_tbl.get(Q.member_id == str(member.id))
    if not rec or rec.get("fake"): return
    data = inv_tbl.get(Q.user_id == rec["inviter_id"])
    if data:
        data["leaves"] = data.get("leaves", 0) + 1
        data["valid"] = max(0, data.get("valid", 0) - 1)
        inv_tbl.upsert(data, Q.user_id == rec["inviter_id"])

@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.CommandNotFound): return
    if isinstance(error, commands.CheckFailure): return
    if isinstance(error, commands.MissingRequiredArgument):
        await ctx.send(embed=discord.Embed(description=f"❌ Missing: `{error.param.name}` — see `!help`", color=0xed4245), delete_after=8)

@tasks.loop(hours=6)
async def auto_backup():
    ts = datetime.now().strftime("%Y%m%d-%H%M")
    for f in ["vps","guild","invites","bans","tickets","warnings","settings","custom_tiers"]:
        src = f"data/{f}.json"
        dst = f"backups/{f}-{ts}.json"
        if os.path.exists(src): shutil.copy2(src, dst)
    for f in ["vps","guild","invites","bans","tickets","warnings","settings","custom_tiers"]:
        files = sorted(glob.glob(f"backups/{f}-*.json"))
        for old in files[:-10]: os.remove(old)

# ══════════════════════════════════════════════════════════
#  USER COMMANDS
# ══════════════════════════════════════════════════════════

@bot.command(name="help", aliases=["commands", "h"])
async def cmd_help(ctx):
    adm = is_admin(ctx)
    e = discord.Embed(title="🐳 Ghost VPS Bot MEGA v2.0", color=0x5865f2)
    e.add_field(name="👤 User", value="`!status` `!sshx` `!tmate` `!panel` `!invites` `!tiers` `!ping` `!uptime` `!botinfo`", inline=False)
    if adm:
        e.add_field(name="🐳 VPS", value="`!createvps` `!givevps` `!deletemyvps` `!deletesomeonevps` `!startvps` `!stopvps` `!restartvps` `!rebuildvps` `!execvps` `!bash` `!tailscale` `!webterminal`", inline=False)
        e.add_field(name="📋 Listings", value="`!listvps` `!listall` `!lookup` `!vpsinfo` `!dockerps` `!node`", inline=False)
        e.add_field(name="🚫 Users", value="`!ban` `!unban` `!suspend` `!warn` `!userinfo` `!transfervps`", inline=False)
        e.add_field(name="📨 Invites", value="`!addinvites` `!removeinvites` `!resetinvites` `!invitecheck`", inline=False)
        e.add_field(name="🏷️ Tiers", value="`!addtier` `!edittier` `!deltier` `!listtiers`", inline=False)
        e.add_field(name="🎫 Tickets", value="`!ticketpanel` `!ticketsetup` `!closeticket` `!listtickets`", inline=False)
        e.add_field(name="🔧 Channel", value="`!clear` `!lock` `!unlock` `!slowmode`", inline=False)
        e.add_field(name="⚙️ System", value="`!setup` `!installcheck` `!fixlxc` `!setprefix` `!all` `!backup` `!wipeall`", inline=False)
    await ctx.send(embed=e)

@bot.command(name="ping")
async def cmd_ping(ctx):
    lat = round(bot.latency * 1000)
    color = 0x57f287 if lat < 100 else 0xfee75c if lat < 250 else 0xed4245
    await ctx.send(embed=discord.Embed(title="🏓 Pong!", description=f"**Latency:** `{lat}ms`", color=color))

@bot.command(name="uptime")
async def cmd_uptime(ctx):
    await ctx.send(embed=discord.Embed(title="⏱ Uptime", description=f"`{fmt_uptime(time.time() - START_TIME)}`", color=0x5865f2))

@bot.command(name="botinfo")
async def cmd_botinfo(ctx):
    e = discord.Embed(title="🤖 Bot Info", color=0x5865f2)
    e.add_field(name="Name", value=bot.user.name, inline=True)
    e.add_field(name="ID", value=str(bot.user.id), inline=True)
    e.add_field(name="Guilds", value=str(len(bot.guilds)), inline=True)
    e.add_field(name="Version", value="MEGA v2.0", inline=True)
    e.add_field(name="Uptime", value=fmt_uptime(time.time()-START_TIME), inline=True)
    await ctx.send(embed=e)

@bot.command(name="status")
async def cmd_status(ctx):
    uid = str(ctx.author.id)
    records = vps_tbl.search(Q.owner_id == uid)
    if not records: return await ctx.send(embed=discord.Embed(description="❌ No VPS assigned.", color=0xed4245), delete_after=12)
    e = discord.Embed(title="📊 Your VPS", color=0x2b2d31)
    for r in records:
        n = r["cname"]
        status = await docker_status(n)
        dot = "🟢" if status == "running" else "🔴"
        e.add_field(name=f"{dot} {n}", value=f"ID: `{r['vps_id']}` | OS: `{r.get('image','?')}` | Status: `{status.upper()}`", inline=False)
    await ctx.send(embed=e)

@bot.command(name="sshx")
async def cmd_sshx(ctx, vps_id: str = None):
    """Get FRESH SSHX link (generates new link each time)."""
    uid = str(ctx.author.id)
    records = vps_tbl.search(Q.owner_id == uid)
    r = next((x for x in records if x["vps_id"] == vps_id), records[0] if records else None)
    if not r: return await ctx.send(embed=discord.Embed(description="❌ VPS not found.", color=0xed4245), delete_after=8)
    _, sshx = await get_links_fresh_sshx(r["cname"])
    if sshx:
        await ctx.author.send(embed=discord.Embed(title="🖥 SSHX", description=sshx, color=0x5865f2))
        await ctx.send(embed=discord.Embed(description="✅ SSHX sent to DM!", color=0x57f287), delete_after=6)
    else:
        await ctx.send(embed=discord.Embed(description="❌ SSHX not ready. VPS running?", color=0xed4245), delete_after=8)

@bot.command(name="tmate")
async def cmd_tmate(ctx, vps_id: str = None):
    uid = str(ctx.author.id)
    records = vps_tbl.search(Q.owner_id == uid)
    r = next((x for x in records if x["vps_id"] == vps_id), records[0] if records else None)
    if not r: return await ctx.send(embed=discord.Embed(description="❌ VPS not found.", color=0xed4245), delete_after=8)
    tmate, _ = await get_links(r["cname"])
    if tmate:
        await ctx.author.send(embed=discord.Embed(title="📟 tmate", description=f"`{tmate}`", color=0x5865f2))
        await ctx.send(embed=discord.Embed(description="✅ tmate sent to DM!", color=0x57f287), delete_after=6)
    else:
        await ctx.send(embed=discord.Embed(description="❌ tmate not ready. VPS running?", color=0xed4245), delete_after=8)

@bot.command(name="panel")
async def cmd_panel(ctx):
    """DM control panel — clears DMs first."""
    uid = str(ctx.author.id)
    records = vps_tbl.search(Q.owner_id == uid)
    if not records: return await ctx.send(embed=discord.Embed(description="❌ No VPS found.", color=0xed4245))
    try:
        dm = await ctx.author.create_dm()
        # Clear recent DM messages (only bot's messages)
        async for msg in dm.history(limit=20):
            if msg.author == bot.user:
                try: await msg.delete()
                except: pass
        # Send panel for each VPS
        for r in records:
            e = discord.Embed(title=f"🖥 VPS Panel — {r['cname']}", description=f"**ID:** `{r['vps_id']}`\n**OS:** `{r.get('image','?')}`", color=0x5865f2)
            await ctx.author.send(embed=e, view=VPSPanel(r["vps_id"]))
        await ctx.send(embed=discord.Embed(description="✅ Panel sent to DM!", color=0x57f287), delete_after=6)
    except:
        await ctx.send(embed=discord.Embed(description="❌ Enable DMs!", color=0xed4245))

@bot.command(name="invites", aliases=["inv"])
async def cmd_invites(ctx, target: discord.User = None):
    target = target or ctx.author
    d = inv_tbl.get(Q.user_id == str(target.id)) or {}
    valid = get_valid_invites(target.id)
    e = discord.Embed(title=f"📨 Invites — {target.display_name}", color=0x5865f2)
    e.add_field(name="✅ Valid", value=f"`{valid}`", inline=True)
    e.add_field(name="❌ Fake", value=f"`{d.get('fakes',0)}`", inline=True)
    e.add_field(name="👋 Left", value=f"`{d.get('leaves',0)}`", inline=True)
    await ctx.send(embed=e)

@bot.command(name="tiers")
async def cmd_tiers(ctx):
    e = discord.Embed(title="🏷️ VPS Tiers", color=0x5865f2)
    for k, t in config.TIERS.items():
        e.add_field(name=t["name"], value=f"Invites: **{t['invites']}**\nRAM: `{t['ram']}` | CPUs: `{t['cpus']}`", inline=False)
    custom = tiers_tbl.all()
    if custom:
        for ct in custom:
            e.add_field(name=f"🎨 {ct['name']} (Custom)", value=f"RAM: `{ct['ram']}` | CPUs: `{ct['cpus']}`", inline=False)
    await ctx.send(embed=e)

# ══════════════════════════════════════════════════════════
#  ADMIN — VPS MANAGEMENT
# ══════════════════════════════════════════════════════════

@bot.command(name="createvps")
@admin_only()
async def cmd_createvps(ctx):
    params = await run_wizard(ctx)
    if not params: return
    vid = gen_id()
    cname = f"vps-{params['name']}-{vid}"
    msg = await ctx.send(embed=discord.Embed(title="🚀 Creating VPS...", color=0xfee75c))
    try:
        await create_docker_vps(cname, params["image"], params["ram"], params["cpus"])
        tmate, sshx = await wait_links(cname)
        vps_tbl.insert({"owner_id": str(ctx.author.id), "vps_id": vid, "cname": cname, "image": params["image"],
                        "ram": params["ram"], "cpus": params["cpus"], "storage": params["storage"],
                        "tier": "admin", "created_at": datetime.now().isoformat()})
        ok = discord.Embed(title="✅ VPS Created!", color=0x57f287)
        ok.add_field(name="Container", value=f"`{cname}`", inline=True)
        ok.add_field(name="ID", value=f"`{vid}`", inline=True)
        if tmate: ok.add_field(name="📟 tmate", value=f"`{tmate}`", inline=False)
        if sshx: ok.add_field(name="🖥 SSHX", value=sshx, inline=False)
        await msg.edit(embed=ok)
        try:
            await ctx.author.send(embed=discord.Embed(title="🖥 Panel", description=f"**ID:** `{vid}`\n**Name:** `{cname}`", color=0x5865f2), view=VPSPanel(vid))
        except: pass
        await log(ctx.guild, "🖥 Admin Created VPS", f"**Admin:** {ctx.author.mention}\n**Container:** `{cname}`", 0x57f287)
    except Exception as e:
        await msg.edit(embed=discord.Embed(title="❌ Failed", description=str(e)[:1800], color=0xed4245))

@bot.command(name="givevps")
@admin_only()
async def cmd_givevps(ctx, target: discord.Member = None):
    if not target: return await ctx.send(embed=discord.Embed(description="❌ Usage: `!givevps @user`", color=0xed4245))
    if is_banned(target.id): return await ctx.send(embed=discord.Embed(description="❌ User is banned.", color=0xed4245))
    params = await run_wizard(ctx)
    if not params: return
    vid = gen_id()
    clean = safe_name(target.name)
    cname = f"vps-{clean}-{vid}"
    msg = await ctx.send(embed=discord.Embed(title=f"🚀 Creating VPS for {target.display_name}...", color=0xfee75c))
    try:
        await create_docker_vps(cname, params["image"], params["ram"], params["cpus"])
        tmate, sshx = await wait_links(cname)
        vps_tbl.insert({"owner_id": str(target.id), "vps_id": vid, "cname": cname, "image": params["image"],
                        "ram": params["ram"], "cpus": params["cpus"], "storage": params["storage"],
                        "tier": "gifted", "created_at": datetime.now().isoformat()})
        ok = discord.Embed(title="✅ VPS Given!", color=0x57f287)
        ok.add_field(name="Container", value=f"`{cname}`", inline=True)
        ok.add_field(name="ID", value=f"`{vid}`", inline=True)
        if tmate: ok.add_field(name="📟 tmate", value=f"`{tmate}`", inline=False)
        if sshx: ok.add_field(name="🖥 SSHX", value=sshx, inline=False)
        await msg.edit(embed=ok)
        try:
            await target.send(embed=discord.Embed(title="🎁 VPS Received!", description=f"**ID:** `{vid}`\n**Name:** `{cname}`", color=0x5865f2), view=VPSPanel(vid))
        except:
            await ctx.send(embed=discord.Embed(description=f"⚠️ Could not DM {target.mention}", color=0xfee75c))
        await log(ctx.guild, "🎁 Admin Gave VPS", f"**Admin:** {ctx.author.mention}\n**User:** {target.mention}\n**Container:** `{cname}`", 0x57f287)
    except Exception as e:
        await msg.edit(embed=discord.Embed(title="❌ Failed", description=str(e)[:1800], color=0xed4245))

@bot.command(name="deletemyvps")
@admin_only()
async def cmd_deletemyvps(ctx, vps_id: str = None):
    uid = str(ctx.author.id)
    records = vps_tbl.search(Q.owner_id == uid)
    r = next((x for x in records if x["vps_id"] == vps_id), records[0] if records else None)
    if not r: return await ctx.send(embed=discord.Embed(description="❌ Not found.", color=0xed4245))
    await shell(f"docker rm -f {r['cname']}")
    vps_tbl.remove(Q.vps_id == r["vps_id"])
    await ctx.send(embed=discord.Embed(description=f"✅ Deleted `{r['cname']}`.", color=0x57f287))

@bot.command(name="deletesomeonevps", aliases=["delvps"])
@admin_only()
async def cmd_deletesomeonevps(ctx, target: discord.Member = None, vps_id: str = None):
    if not target: return await ctx.send(embed=discord.Embed(description="❌ Usage: `!deletesomeonevps @user [id]`", color=0xed4245))
    records = vps_tbl.search(Q.owner_id == str(target.id))
    r = next((x for x in records if x["vps_id"] == vps_id), records[0] if records else None)
    if not r: return await ctx.send(embed=discord.Embed(description="❌ No VPS found.", color=0xed4245))
    await shell(f"docker rm -f {r['cname']}")
    vps_tbl.remove(Q.vps_id == r["vps_id"])
    await ctx.send(embed=discord.Embed(description=f"✅ Deleted `{r['cname']}` from {target.mention}.", color=0x57f287))
    await log(ctx.guild, "🗑 Admin Deleted VPS", f"**Admin:** {ctx.author.mention}\n**User:** {target.mention}\n**Container:** `{r['cname']}`", 0xed4245)

@bot.command(name="startvps")
@admin_only()
async def cmd_startvps(ctx, target: discord.Member = None):
    if not target: return await ctx.send(embed=discord.Embed(description="❌ Usage: `!startvps @user`", color=0xed4245))
    records = vps_tbl.search(Q.owner_id == str(target.id))
    if not records: return await ctx.send(embed=discord.Embed(description="❌ No VPS.", color=0xed4245))
    r = records[0]
    await shell(f"docker start {r['cname']}")
    await ctx.send(embed=discord.Embed(description=f"✅ Started `{r['cname']}`.", color=0x57f287))

@bot.command(name="stopvps")
@admin_only()
async def cmd_stopvps(ctx, target: discord.Member = None):
    if not target: return await ctx.send(embed=discord.Embed(description="❌ Usage: `!stopvps @user`", color=0xed4245))
    records = vps_tbl.search(Q.owner_id == str(target.id))
    if not records: return await ctx.send(embed=discord.Embed(description="❌ No VPS.", color=0xed4245))
    r = records[0]
    await shell(f"docker stop {r['cname']}")
    await ctx.send(embed=discord.Embed(description=f"✅ Stopped `{r['cname']}`.", color=0x57f287))

@bot.command(name="restartvps")
@admin_only()
async def cmd_restartvps(ctx, target: discord.Member = None):
    if not target: return await ctx.send(embed=discord.Embed(description="❌ Usage: `!restartvps @user`", color=0xed4245))
    records = vps_tbl.search(Q.owner_id == str(target.id))
    if not records: return await ctx.send(embed=discord.Embed(description="❌ No VPS.", color=0xed4245))
    r = records[0]
    await shell(f"docker restart {r['cname']}")
    await ctx.send(embed=discord.Embed(description=f"✅ Restarted `{r['cname']}`.", color=0x57f287))

@bot.command(name="rebuildvps")
@admin_only()
async def cmd_rebuildvps(ctx, target: discord.Member = None):
    if not target: return await ctx.send(embed=discord.Embed(description="❌ Usage: `!rebuildvps @user`", color=0xed4245))
    records = vps_tbl.search(Q.owner_id == str(target.id))
    if not records: return await ctx.send(embed=discord.Embed(description="❌ No VPS.", color=0xed4245))
    r = records[0]
    def chk(m): return m.author == ctx.author and m.channel == ctx.channel
    await ctx.send(embed=discord.Embed(title="⚠️ Confirm", description=f"Type `confirm` to wipe `{r['cname']}`!", color=0xfee75c))
    try:
        m = await bot.wait_for("message", check=chk, timeout=30)
        if m.content.lower() != "confirm": return await ctx.send(embed=discord.Embed(description="❌ Cancelled.", color=0x2b2d31))
    except asyncio.TimeoutError:
        return await ctx.send(embed=discord.Embed(description="⏱ Cancelled.", color=0x2b2d31))
    msg = await ctx.send(embed=discord.Embed(description=f"♻️ Rebuilding `{r['cname']}`...", color=0xfee75c))
    await shell(f"docker rm -f {r['cname']}")
    try:
        await create_docker_vps(r["cname"], r["image"], r["ram"], r["cpus"])
        await msg.edit(embed=discord.Embed(description=f"✅ Rebuilt `{r['cname']}`.", color=0x57f287))
    except Exception as e:
        await msg.edit(embed=discord.Embed(title="❌ Failed", description=str(e)[:1800], color=0xed4245))

@bot.command(name="execvps")
@admin_only()
async def cmd_execvps(ctx, target: discord.Member = None, *, cmd: str = None):
    """FIXED: Waits for completion + better encoding."""
    if not target or not cmd: return await ctx.send(embed=discord.Embed(description="❌ Usage: `!execvps @user <command>`", color=0xed4245))
    records = vps_tbl.search(Q.owner_id == str(target.id))
    if not records: return await ctx.send(embed=discord.Embed(description="❌ No VPS.", color=0xed4245))
    r = records[0]
    msg = await ctx.send(embed=discord.Embed(description=f"⏳ Running `{cmd}` on `{r['cname']}`...", color=0xfee75c))
    # Wait for full completion
    out, err, rc = await shell(f"docker exec {r['cname']} bash -c '{cmd}'")
    result = (out or err or "(no output)")[:3000]
    e = discord.Embed(title=f"⚙️ Exec on `{r['cname']}`", color=0x2b2d31)
    e.add_field(name="Command", value=f"`{cmd}`", inline=False)
    e.add_field(name="Output", value=f"```\n{result}\n```", inline=False)
    e.add_field(name="Exit", value=f"`{rc}`", inline=True)
    await msg.edit(embed=e)

@bot.command(name="bash")
@admin_only()
async def cmd_bash(ctx, target: discord.Member = None, *, cmd: str = None):
    """Execute bash commands from Discord — waits for completion."""
    if not target or not cmd: return await ctx.send(embed=discord.Embed(description="❌ Usage: `!bash @user <command>`", color=0xed4245))
    records = vps_tbl.search(Q.owner_id == str(target.id))
    if not records: return await ctx.send(embed=discord.Embed(description="❌ No VPS.", color=0xed4245))
    r = records[0]
    msg = await ctx.send(embed=discord.Embed(description=f"⚡ Running bash...", color=0xfee75c))
    out, err, rc = await shell(f"docker exec {r['cname']} bash -c '{cmd}'")
    result = (out or err or "(no output)")[:3000]
    await msg.edit(embed=discord.Embed(title="⚡ Bash Output", description=f"```\n{result}\n```\n**Exit:** `{rc}`", color=0x2b2d31))

@bot.command(name="tailscale")
@admin_only()
async def cmd_tailscale(ctx, target: discord.Member = None):
    """Auto-install Tailscale with auto-confirm."""
    if not target: return await ctx.send(embed=discord.Embed(description="❌ Usage: `!tailscale @user`", color=0xed4245))
    records = vps_tbl.search(Q.owner_id == str(target.id))
    if not records: return await ctx.send(embed=discord.Embed(description="❌ No VPS.", color=0xed4245))
    r = records[0]
    msg = await ctx.send(embed=discord.Embed(description=f"📡 Installing Tailscale on `{r['cname']}`...", color=0xfee75c))
    # Install with auto-confirm
    install_cmd = "curl -fsSL https://tailscale.com/install.sh | sh"
    out, err, rc = await shell(f"docker exec {r['cname']} bash -c 'yes | {install_cmd}'")
    if rc != 0:
        return await msg.edit(embed=discord.Embed(title="❌ Install Failed", description=err[:1500], color=0xed4245))
    # Run tailscale up
    up_out, _, _ = await shell(f"docker exec {r['cname']} bash -c 'tailscale up 2>&1'")
    link = ""
    if "https://" in up_out:
        match = re.search(r'https://[^\s]+', up_out)
        if match: link = match.group(0)
    if link:
        await msg.edit(embed=discord.Embed(title="✅ Tailscale Ready!", description=f"**Auth Link:**\n{link}", color=0x57f287))
        try:
            await target.send(embed=discord.Embed(title="📡 Tailscale Auth", description=f"Click to authenticate:\n{link}", color=0x5865f2))
        except: pass
    else:
        await msg.edit(embed=discord.Embed(title="✅ Installed", description="Run `tailscale up` manually to authenticate.", color=0x57f287))

@bot.command(name="webterminal")
@admin_only()
async def cmd_webterminal(ctx, target: discord.Member = None):
    """Install ttyd web terminal + provide Tailscale IP link."""
    if not target: return await ctx.send(embed=discord.Embed(description="❌ Usage: `!webterminal @user`", color=0xed4245))
    records = vps_tbl.search(Q.owner_id == str(target.id))
    if not records: return await ctx.send(embed=discord.Embed(description="❌ No VPS.", color=0xed4245))
    r = records[0]
    msg = await ctx.send(embed=discord.Embed(description=f"🖥 Setting up web terminal...", color=0xfee75c))
    # Check/install tailscale
    _, _, ts_rc = await shell(f"docker exec {r['cname']} which tailscale 2>/dev/null")
    if ts_rc != 0:
        return await msg.edit(embed=discord.Embed(description="❌ Install Tailscale first: `!tailscale @user`", color=0xed4245))
    # Get Tailscale IP
    ts_ip, _, _ = await shell(f"docker exec {r['cname']} tailscale ip -4 2>/dev/null")
    ts_ip = ts_ip.strip()
    if not ts_ip:
        return await msg.edit(embed=discord.Embed(description="❌ Tailscale not authenticated. Run `tailscale up`.", color=0xed4245))
    # Install ttyd
    await shell(f"docker exec {r['cname']} apt-get update -qq 2>/dev/null")
    out, err, rc = await shell(f"docker exec {r['cname']} apt-get install -y -qq ttyd 2>/dev/null")
    if rc != 0:
        return await msg.edit(embed=discord.Embed(title="❌ ttyd Install Failed", description=err[:1500], color=0xed4245))
    # Start ttyd on port 8080
    await shell(f"docker exec -d {r['cname']} ttyd -p 8080 bash")
    web_url = f"http://{ts_ip}:8080"
    await msg.edit(embed=discord.Embed(title="✅ Web Terminal Ready!", description=f"**Access at:**\n{web_url}", color=0x57f287))
    try:
        await target.send(embed=discord.Embed(title="🖥 Web Terminal", description=f"Your web terminal:\n{web_url}", color=0x5865f2))
    except: pass

# ══════════════════════════════════════════════════════════
#  TIER MANAGEMENT
# ══════════════════════════════════════════════════════════

@bot.command(name="addtier")
@admin_only()
async def cmd_addtier(ctx, tier_key: str = None, name: str = None, invites: int = None, ram: str = None, cpus: str = None):
    """Add custom tier: !addtier platinum "💎 Platinum" 30 16g 16"""
    if not all([tier_key, name, invites is not None, ram, cpus]):
        return await ctx.send(embed=discord.Embed(description="❌ Usage: `!addtier <key> <name> <invites> <ram> <cpus>`\nExample: `!addtier platinum \"💎 Platinum\" 30 16g 16`", color=0xed4245))
    tiers_tbl.insert({"key": tier_key, "name": name, "invites": invites, "ram": ram, "cpus": cpus, "storage": "Custom"})
    await ctx.send(embed=discord.Embed(description=f"✅ Added tier `{tier_key}` — {name}", color=0x57f287))

@bot.command(name="edittier")
@admin_only()
async def cmd_edittier(ctx, tier_key: str = None, field: str = None, value: str = None):
    """Edit tier: !edittier platinum ram 32g"""
    if not all([tier_key, field, value]):
        return await ctx.send(embed=discord.Embed(description="❌ Usage: `!edittier <key> <field> <value>`\nFields: name, invites, ram, cpus", color=0xed4245))
    tier = tiers_tbl.get(Q.key == tier_key)
    if not tier: return await ctx.send(embed=discord.Embed(description="❌ Tier not found.", color=0xed4245))
    if field == "invites": value = int(value)
    tiers_tbl.update({field: value}, Q.key == tier_key)
    await ctx.send(embed=discord.Embed(description=f"✅ Updated `{tier_key}` {field} → {value}", color=0x57f287))

@bot.command(name="deltier")
@admin_only()
async def cmd_deltier(ctx, tier_key: str = None):
    """Delete custom tier."""
    if not tier_key: return await ctx.send(embed=discord.Embed(description="❌ Usage: `!deltier <key>`", color=0xed4245))
    tiers_tbl.remove(Q.key == tier_key)
    await ctx.send(embed=discord.Embed(description=f"✅ Deleted tier `{tier_key}`.", color=0x57f287))

@bot.command(name="listtiers")
@admin_only()
async def cmd_listtiers(ctx):
    """List all custom tiers."""
    custom = tiers_tbl.all()
    if not custom: return await ctx.send(embed=discord.Embed(description="No custom tiers. Use `!addtier`.", color=0x2b2d31))
    e = discord.Embed(title="🎨 Custom Tiers", color=0x5865f2)
    for t in custom:
        e.add_field(name=t["name"], value=f"Key: `{t['key']}` | Invites: **{t['invites']}**\nRAM: `{t['ram']}` | CPUs: `{t['cpus']}`", inline=False)
    await ctx.send(embed=e)

# ══════════════════════════════════════════════════════════
#  CHANNEL MANAGEMENT
# ══════════════════════════════════════════════════════════

@bot.command(name="clear")
@admin_only()
async def cmd_clear(ctx, amount: int = 10):
    """Clear messages in channel."""
    if amount > 100: amount = 100
    deleted = await ctx.channel.purge(limit=amount + 1)
    msg = await ctx.send(embed=discord.Embed(description=f"✅ Cleared {len(deleted) - 1} messages.", color=0x57f287))
    await asyncio.sleep(3)
    try: await msg.delete()
    except: pass

@bot.command(name="lock")
@admin_only()
async def cmd_lock(ctx):
    """Lock channel."""
    await ctx.channel.set_permissions(ctx.guild.default_role, send_messages=False)
    await ctx.send(embed=discord.Embed(description="🔒 Channel locked.", color=0xed4245))

@bot.command(name="unlock")
@admin_only()
async def cmd_unlock(ctx):
    """Unlock channel."""
    await ctx.channel.set_permissions(ctx.guild.default_role, send_messages=None)
    await ctx.send(embed=discord.Embed(description="🔓 Channel unlocked.", color=0x57f287))

@bot.command(name="slowmode")
@admin_only()
async def cmd_slowmode(ctx, seconds: int = 0):
    """Set slowmode."""
    await ctx.channel.edit(slowmode_delay=seconds)
    if seconds == 0:
        await ctx.send(embed=discord.Embed(description="✅ Slowmode disabled.", color=0x57f287))
    else:
        await ctx.send(embed=discord.Embed(description=f"✅ Slowmode: `{seconds}s`", color=0x57f287))

# ══════════════════════════════════════════════════════════
#  LISTINGS
# ══════════════════════════════════════════════════════════

@bot.command(name="listvps")
@admin_only()
async def cmd_listvps(ctx):
    all_vps = vps_tbl.all()
    if not all_vps: return await ctx.send(embed=discord.Embed(description="No VPS in database.", color=0x2b2d31))
    lines = []
    for r in all_vps:
        status = await docker_status(r["cname"])
        dot = "🟢" if status == "running" else "🔴"
        lines.append(f"{dot} `{r['cname']}` — <@{r['owner_id']}> | ID: `{r['vps_id']}`")
    chunks = [lines[i:i+10] for i in range(0, len(lines), 10)]
    for i, chunk in enumerate(chunks):
        e = discord.Embed(title=f"📋 All VPS ({i+1}/{len(chunks)})", description="\n".join(chunk), color=0x2b2d31)
        await ctx.send(embed=e)

@bot.command(name="listall")
@admin_only()
async def cmd_listall(ctx):
    all_vps = vps_tbl.all()
    if not all_vps: return await ctx.send(embed=discord.Embed(description="No VPS.", color=0x2b2d31))
    lines = []
    for r in all_vps:
        lines.append(f"`{r['cname']}` | Owner: <@{r['owner_id']}> | OS: `{r.get('image','?')}` | RAM: `{r.get('ram','?')}` | CPUs: `{r.get('cpus','?')}`")
    chunks = [lines[i:i+5] for i in range(0, len(lines), 5)]
    for i, ch in enumerate(chunks):
        e = discord.Embed(title=f"🗄 Full List ({i+1}/{len(chunks)})", description="\n\n".join(ch), color=0x2b2d31)
        await ctx.send(embed=e)

@bot.command(name="lookup")
@admin_only()
async def cmd_lookup(ctx, target: discord.Member = None):
    if not target: return await ctx.send(embed=discord.Embed(description="❌ Usage: `!lookup @user`", color=0xed4245))
    records = vps_tbl.search(Q.owner_id == str(target.id))
    if not records: return await ctx.send(embed=discord.Embed(description=f"❌ {target.mention} has no VPS.", color=0x2b2d31))
    e = discord.Embed(title=f"🔍 VPS for {target.display_name}", color=0x2b2d31)
    for r in records:
        status = await docker_status(r["cname"])
        dot = "🟢" if status == "running" else "🔴"
        e.add_field(name=f"{dot} {r['cname']}", value=f"ID: `{r['vps_id']}` | OS: `{r.get('image','?')}` | RAM: `{r.get('ram','?')}` | CPUs: `{r.get('cpus','?')}`", inline=False)
    await ctx.send(embed=e)

@bot.command(name="vpsinfo")
@admin_only()
async def cmd_vpsinfo(ctx, vps_id: str = None):
    if not vps_id: return await ctx.send(embed=discord.Embed(description="❌ Usage: `!vpsinfo <vps_id>`", color=0xed4245))
    r = vps_tbl.get(Q.vps_id == vps_id)
    if not r: return await ctx.send(embed=discord.Embed(description="❌ VPS not found.", color=0xed4245))
    n = r["cname"]
    status = await docker_status(n)
    st_raw, _, _ = await shell(f"docker stats {n} --no-stream --format '{{{{.CPUPerc}}}} {{{{.MemUsage}}}}' 2>/dev/null")
    dot = "🟢" if status == "running" else "🔴"
    e = discord.Embed(title=f"🔎 VPS Info — `{n}`", color=0x2b2d31)
    e.add_field(name="Status", value=f"{dot} `{status.upper()}`", inline=True)
    e.add_field(name="VPS ID", value=f"`{vps_id}`", inline=True)
    e.add_field(name="Owner", value=f"<@{r['owner_id']}>", inline=True)
    e.add_field(name="OS", value=f"`{r.get('image','?')}`", inline=True)
    e.add_field(name="RAM", value=f"`{r.get('ram','?')}`", inline=True)
    e.add_field(name="CPUs", value=f"`{r.get('cpus','?')}`", inline=True)
    if st_raw:
        parts = st_raw.split()
        e.add_field(name="CPU Use", value=f"`{parts[0]}`", inline=True)
        e.add_field(name="RAM Use", value=f"`{' '.join(parts[1:])}`", inline=True)
    await ctx.send(embed=e)

@bot.command(name="dockerps")
@admin_only()
async def cmd_dockerps(ctx):
    out, _, _ = await shell("docker ps --format 'table {{.Names}}\\t{{.Status}}\\t{{.Image}}'")
    await ctx.send(embed=discord.Embed(title="🐳 docker ps", description=f"```\n{out[:3900] or 'No containers.'}\n```", color=0x2b2d31))

@bot.command(name="node")
@admin_only()
async def cmd_node(ctx):
    cpu = psutil.cpu_percent(interval=1)
    ram = psutil.virtual_memory()
    disk = psutil.disk_usage("/")
    running, _, _ = await shell("docker ps -q | wc -l")
    total, _, _ = await shell("docker ps -a -q | wc -l")
    e = discord.Embed(title="🖥 Node Status", color=0x2b2d31, timestamp=datetime.now(timezone.utc))
    e.add_field(name="🔥 CPU", value=f"`{cpu:.1f}%`", inline=True)
    e.add_field(name="🧠 RAM", value=f"`{ram.percent:.1f}%` — {ram.used//1024//1024}MB/{ram.total//1024//1024}MB", inline=True)
    e.add_field(name="💾 Disk", value=f"`{disk.percent:.1f}%` — {disk.used//1024//1024//1024}GB/{disk.total//1024//1024//1024}GB", inline=True)
    e.add_field(name="🐳 Containers", value=f"`{running.strip()}` running / `{total.strip()}` total", inline=True)
    e.add_field(name="⏱ Uptime", value=f"`{fmt_uptime(time.time()-START_TIME)}`", inline=True)
    await ctx.send(embed=e)

# ══════════════════════════════════════════════════════════
#  SYSTEM + SETUP
# ══════════════════════════════════════════════════════════

@bot.command(name="installcheck")
@admin_only()
async def cmd_installcheck(ctx):
    docker_v, _, rc1 = await shell("docker --version")
    daemon, _, rc3 = await shell("docker info --format '{{.ServerVersion}}' 2>/dev/null")
    storage, _, _ = await shell("docker info --format '{{.Driver}}' 2>/dev/null")
    net_out, _, _ = await shell(f"docker network ls | grep {config.DOCKER_NETWORK}")
    _, _, priv_rc = await shell("docker run --rm --privileged --network host ubuntu:24.04 echo OK 2>/dev/null")
    priv_ok = priv_rc == 0
    e = discord.Embed(title="🔍 Installation Check", color=0x2b2d31)
    e.add_field(name="🐳 Docker", value=f"✅ `{docker_v}`" if rc1 == 0 else "❌ Not installed!", inline=False)
    e.add_field(name="🟢 Daemon", value=f"✅ Running — `{daemon}`" if rc3 == 0 and daemon else "❌ Not running!", inline=False)
    e.add_field(name="💾 Storage", value=f"`{storage.strip()}`" if storage else "unknown", inline=False)
    e.add_field(name=f"🌐 Network", value="✅ Exists" if net_out else f"⚠️ Missing — run: `docker network create {config.DOCKER_NETWORK}`", inline=False)
    e.add_field(name="🔑 Privileged", value="✅ Working (LXC compatible!)" if priv_ok else "❌ Blocked — run `!fixlxc`", inline=False)
    await ctx.send(embed=e)

@bot.command(name="fixlxc")
@admin_only()
async def cmd_fixlxc(ctx):
    e = discord.Embed(title="🔧 Fix Docker Inside LXC", description="Run these commands inside your LXC container:", color=0xfee75c)
    e.add_field(name="Step 1", value="```bash\nmkdir -p /etc/docker\ncat > /etc/docker/daemon.json << 'EOF'\n{\n  \"storage-driver\": \"vfs\",\n  \"iptables\": true\n}\nEOF\n```", inline=False)
    e.add_field(name="Step 2", value="```bash\nsystemctl restart docker\n# or: service docker restart\n```", inline=False)
    e.add_field(name="Step 3", value=f"```bash\ndocker network create {config.DOCKER_NETWORK}\n```", inline=False)
    e.add_field(name="Step 4", value="```bash\ndocker run --rm --privileged ubuntu:24.04 echo 'Works!'\n```", inline=False)
    await ctx.send(embed=e)

@bot.command(name="setup")
@admin_only()
async def cmd_setup(ctx):
    def chk(m): return m.author == ctx.author and m.channel == ctx.channel
    async def ask(prompt):
        await ctx.send(embed=discord.Embed(description=prompt, color=0x5865f2))
        try:
            m = await bot.wait_for("message", check=chk, timeout=60)
            return m.content.strip()
        except asyncio.TimeoutError:
            return None
    await ctx.send(embed=discord.Embed(title="⚙️ Ghost VPS Bot — Setup", description="Answer each question:", color=0x5865f2))
    log_raw = await ask("**Step 1:** Log channel (mention or ID):")
    if log_raw:
        log_id = log_raw.strip("<#>")
        upd_guild_cfg(ctx.guild.id, {"log_channel": log_id})
    tk_raw = await ask("**Step 2:** Ticket category/channel (mention or ID):")
    if tk_raw:
        tk_id = tk_raw.strip("<#>")
        upd_guild_cfg(ctx.guild.id, {"ticket_channel": tk_id})
    ann_raw = await ask("**Step 3:** Announcement channel (mention or ID):")
    if ann_raw:
        ann_id = ann_raw.strip("<#>")
        upd_guild_cfg(ctx.guild.id, {"announce_channel": ann_id})
    upd_guild_cfg(ctx.guild.id, {"setup_done": True})
    await ctx.send(embed=discord.Embed(title="✅ Setup Complete!", description="Next:\n`!ticketpanel` — Post ticket button\n`!installcheck` — Verify Docker", color=0x57f287))

@bot.command(name="ticketpanel")
@admin_only()
async def cmd_ticketpanel(ctx):
    cfg = get_guild_cfg(ctx.guild.id)
    msg_text = cfg.get("ticket_message", "Click button to open ticket")
    e = discord.Embed(title="🎫 Support Tickets", description=msg_text, color=0x5865f2)
    e.set_footer(text="Ghost VPS Bot • Ticket System")
    await ctx.send(embed=e, view=OpenTicketView())
    try: await ctx.message.delete()
    except: pass

@bot.command(name="ticketsetup")
@admin_only()
async def cmd_ticketsetup(ctx, *, message: str = None):
    """Customize ticket panel message."""
    if not message: return await ctx.send(embed=discord.Embed(description="❌ Usage: `!ticketsetup <custom message>`", color=0xed4245))
    upd_guild_cfg(ctx.guild.id, {"ticket_message": message})
    await ctx.send(embed=discord.Embed(description=f"✅ Ticket message updated!\n\n**New message:**\n{message}", color=0x57f287))

@bot.command(name="closeticket")
@admin_only()
async def cmd_closeticket(ctx):
    tk = tickets_tbl.get(Q.channel_id == str(ctx.channel.id))
    if not tk: return await ctx.send(embed=discord.Embed(description="❌ Not a ticket channel.", color=0xed4245))
    await ctx.send(embed=discord.Embed(description="🗑 Closing in 5s...", color=0xed4245))
    tickets_tbl.remove(Q.channel_id == str(ctx.channel.id))
    await asyncio.sleep(5)
    try: await ctx.channel.delete()
    except: pass

@bot.command(name="listtickets")
@admin_only()
async def cmd_listtickets(ctx):
    all_tk = tickets_tbl.search(Q.guild_id == str(ctx.guild.id))
    if not all_tk: return await ctx.send(embed=discord.Embed(description="No open tickets.", color=0x2b2d31))
    lines = [f"<#{tk['channel_id']}> — <@{tk['user_id']}> | Status: `{tk['status']}`" + (f" | Claimed: <@{tk['claimed_by']}>" if tk.get("claimed_by") else "") for tk in all_tk]
    e = discord.Embed(title=f"🎫 Open Tickets ({len(all_tk)})", description="\n".join(lines), color=0x5865f2)
    await ctx.send(embed=e)

@bot.command(name="ban")
@admin_only()
async def cmd_ban(ctx, target: discord.Member = None, *, reason: str = "No reason given."):
    if not target: return await ctx.send(embed=discord.Embed(description="❌ Usage: `!ban @user [reason]`", color=0xed4245))
    if target.id in config.ADMIN_IDS: return await ctx.send(embed=discord.Embed(description="❌ Cannot ban admin.", color=0xed4245))
    bans_tbl.upsert({"user_id": str(target.id), "reason": reason, "banned_by": str(ctx.author.id), "banned_at": datetime.now().isoformat()}, Q.user_id == str(target.id))
    records = vps_tbl.search(Q.owner_id == str(target.id))
    for r in records: await shell(f"docker rm -f {r['cname']}")
    vps_tbl.remove(Q.owner_id == str(target.id))
    await ctx.send(embed=discord.Embed(description=f"🚫 {target.mention} banned.\n**Reason:** {reason}", color=0xed4245))
    await log(ctx.guild, "🚫 User Banned", f"**Admin:** {ctx.author.mention}\n**User:** {target.mention}\n**Reason:** {reason}", 0xed4245)

@bot.command(name="unban")
@admin_only()
async def cmd_unban(ctx, target: discord.User = None):
    if not target: return await ctx.send(embed=discord.Embed(description="❌ Usage: `!unban @user`", color=0xed4245))
    if not bans_tbl.contains(Q.user_id == str(target.id)): return await ctx.send(embed=discord.Embed(description="❌ Not banned.", color=0xed4245))
    bans_tbl.remove(Q.user_id == str(target.id))
    await ctx.send(embed=discord.Embed(description=f"✅ {target.mention} unbanned.", color=0x57f287))

@bot.command(name="suspend")
@admin_only()
async def cmd_suspend(ctx, target: discord.Member = None):
    if not target: return await ctx.send(embed=discord.Embed(description="❌ Usage: `!suspend @user`", color=0xed4245))
    settings_tbl.upsert({"type": "suspension", "user_id": str(target.id), "by": str(ctx.author.id), "at": datetime.now().isoformat()}, (Q.type == "suspension") & (Q.user_id == str(target.id)))
    records = vps_tbl.search(Q.owner_id == str(target.id))
    for r in records: await shell(f"docker stop {r['cname']}")
    await ctx.send(embed=discord.Embed(description=f"⏸ {target.mention} suspended. VPS stopped.", color=0xfee75c))

@bot.command(name="unsuspend")
@admin_only()
async def cmd_unsuspend(ctx, target: discord.Member = None):
    if not target: return await ctx.send(embed=discord.Embed(description="❌ Usage: `!unsuspend @user`", color=0xed4245))
    settings_tbl.remove((Q.type == "suspension") & (Q.user_id == str(target.id)))
    await ctx.send(embed=discord.Embed(description=f"▶ {target.mention} unsuspended.", color=0x57f287))

@bot.command(name="warn")
@admin_only()
async def cmd_warn(ctx, target: discord.Member = None, *, reason: str = "No reason."):
    if not target: return await ctx.send(embed=discord.Embed(description="❌ Usage: `!warn @user [reason]`", color=0xed4245))
    warns_tbl.insert({"user_id": str(target.id), "reason": reason, "by": str(ctx.author.id), "at": datetime.now().isoformat()})
    count = len(warns_tbl.search(Q.user_id == str(target.id)))
    await ctx.send(embed=discord.Embed(description=f"⚠️ {target.mention} warned. Total: **{count}**\n**Reason:** {reason}", color=0xfee75c))

@bot.command(name="userinfo")
@admin_only()
async def cmd_userinfo(ctx, target: discord.Member = None):
    target = target or ctx.author
    vps = vps_tbl.search(Q.owner_id == str(target.id))
    warns = warns_tbl.search(Q.user_id == str(target.id))
    banned = is_banned(target.id)
    e = discord.Embed(title=f"👤 {target.display_name}", color=0x5865f2)
    e.set_thumbnail(url=target.display_avatar.url)
    e.add_field(name="ID", value=str(target.id), inline=True)
    e.add_field(name="🐳 VPS", value=str(len(vps)), inline=True)
    e.add_field(name="⚠️ Warns", value=str(len(warns)), inline=True)
    e.add_field(name="🚫 Banned", value="Yes" if banned else "No", inline=True)
    await ctx.send(embed=e)

@bot.command(name="addinvites")
@admin_only()
async def cmd_addinvites(ctx, target: discord.Member = None, amount: int = None):
    if not target or amount is None: return await ctx.send(embed=discord.Embed(description="❌ Usage: `!addinvites @user <number>`", color=0xed4245))
    data = inv_tbl.get(Q.user_id == str(target.id)) or {"user_id": str(target.id), "valid": 0, "fakes": 0, "leaves": 0, "manual": 0}
    data["manual"] = data.get("manual", 0) + amount
    inv_tbl.upsert(data, Q.user_id == str(target.id))
    await ctx.send(embed=discord.Embed(description=f"✅ Added **{amount}** invites to {target.mention}.\nTotal valid: **{get_valid_invites(target.id)}**", color=0x57f287))

@bot.command(name="removeinvites")
@admin_only()
async def cmd_removeinvites(ctx, target: discord.Member = None, amount: int = None):
    if not target or amount is None: return await ctx.send(embed=discord.Embed(description="❌ Usage: `!removeinvites @user <number>`", color=0xed4245))
    data = inv_tbl.get(Q.user_id == str(target.id)) or {"user_id": str(target.id), "valid": 0, "fakes": 0, "leaves": 0, "manual": 0}
    data["manual"] = data.get("manual", 0) - amount
    inv_tbl.upsert(data, Q.user_id == str(target.id))
    await ctx.send(embed=discord.Embed(description=f"✅ Removed **{amount}** invites from {target.mention}.", color=0x57f287))

@bot.command(name="resetinvites")
@admin_only()
async def cmd_resetinvites(ctx, target: discord.Member = None):
    if not target: return await ctx.send(embed=discord.Embed(description="❌ Usage: `!resetinvites @user`", color=0xed4245))
    inv_tbl.remove(Q.user_id == str(target.id))
    await ctx.send(embed=discord.Embed(description=f"✅ Invites reset for {target.mention}.", color=0x57f287))

@bot.command(name="invitecheck")
@admin_only()
async def cmd_invitecheck(ctx, target: discord.Member = None):
    if not target: return await ctx.send(embed=discord.Embed(description="❌ Usage: `!invitecheck @user`", color=0xed4245))
    data = inv_tbl.get(Q.user_id == str(target.id)) or {}
    people = invited_tbl.search(Q.inviter_id == str(target.id))
    lines = []
    for p in people[:15]:
        tag = "❌ Fake" if p.get("fake") else "✅ Valid"
        date = p.get("joined_at", "?")[:10]
        lines.append(f"{tag} — <@{p['member_id']}> — `{date}`")
    e = discord.Embed(title=f"🔍 Invite Audit — {target.display_name}", color=0x5865f2)
    e.add_field(name="Valid", value=str(data.get("valid", 0)), inline=True)
    e.add_field(name="Fakes", value=str(data.get("fakes", 0)), inline=True)
    e.add_field(name="Leaves", value=str(data.get("leaves", 0)), inline=True)
    if lines:
        e.add_field(name="Invited Users (up to 15)", value="\n".join(lines) if lines else "None", inline=False)
    await ctx.send(embed=e)

@bot.command(name="setprefix")
@admin_only()
async def cmd_setprefix(ctx, prefix: str = None):
    if not prefix: return await ctx.send(embed=discord.Embed(description="❌ Usage: `!setprefix <char>`", color=0xed4245))
    upd_guild_cfg(ctx.guild.id, {"prefix": prefix})
    await ctx.send(embed=discord.Embed(description=f"✅ Prefix changed to `{prefix}`", color=0x57f287))

@bot.command(name="all")
@admin_only()
async def cmd_all(ctx, *, message: str = None):
    if not message: return await ctx.send(embed=discord.Embed(description="❌ Usage: `!all <message>`", color=0xed4245))
    users = list({r["owner_id"] for r in vps_tbl.all()})
    sent = 0
    prog = await ctx.send(embed=discord.Embed(description=f"📢 Sending to {len(users)} users...", color=0xfee75c))
    for uid in users:
        try:
            u = await bot.fetch_user(int(uid))
            await u.send(embed=discord.Embed(title="📢 Announcement", description=message, color=0xfee75c, timestamp=datetime.now(timezone.utc)))
            sent += 1
        except: pass
    await prog.edit(embed=discord.Embed(description=f"✅ Sent to **{sent}/{len(users)}** users.", color=0x57f287))

@bot.command(name="backup")
@admin_only()
async def cmd_backup(ctx):
    ts = datetime.now().strftime("%Y%m%d-%H%M%S")
    backed = []
    for f in ["vps", "guild", "invites", "bans", "tickets", "warnings", "settings", "custom_tiers"]:
        src = f"data/{f}.json"
        if os.path.exists(src):
            dst = f"backups/{f}-{ts}.json"
            shutil.copy2(src, dst)
            backed.append(f)
    await ctx.send(embed=discord.Embed(title="💾 Backup Complete", description=f"Backed up: `{'`, `'.join(backed)}`\nTimestamp: `{ts}`", color=0x57f287))

@bot.command(name="wipeall")
@admin_only()
async def cmd_wipeall(ctx):
    def chk(m): return m.author == ctx.author and m.channel == ctx.channel
    await ctx.send(embed=discord.Embed(title="☢️ DANGER", description="Type `CONFIRM WIPE` to delete ALL VPS!", color=0xed4245))
    try:
        m = await bot.wait_for("message", check=chk, timeout=30)
        if m.content != "CONFIRM WIPE": return await ctx.send(embed=discord.Embed(description="❌ Cancelled.", color=0x2b2d31))
    except asyncio.TimeoutError:
        return await ctx.send(embed=discord.Embed(description="⏱ Cancelled.", color=0x2b2d31))
    all_vps = vps_tbl.all()
    for r in all_vps: await shell(f"docker rm -f {r['cname']}")
    vps_tbl.truncate()
    await ctx.send(embed=discord.Embed(description=f"☢️ Wiped. Deleted `{len(all_vps)}` containers.", color=0xed4245))

@bot.command(name="transfervps")
@admin_only()
async def cmd_transfervps(ctx, from_: discord.Member = None, to: discord.Member = None):
    if not from_ or not to: return await ctx.send(embed=discord.Embed(description="❌ Usage: `!transfervps @from @to`", color=0xed4245))
    records = vps_tbl.search(Q.owner_id == str(from_.id))
    if not records: return await ctx.send(embed=discord.Embed(description="❌ No VPS found.", color=0xed4245))
    r = records[0]
    vps_tbl.update({"owner_id": str(to.id)}, Q.vps_id == r["vps_id"])
    await ctx.send(embed=discord.Embed(description=f"✅ VPS `{r['cname']}` transferred from {from_.mention} to {to.mention}.", color=0x57f287))


# ══════════════════════════════════════════════════════════
#  MISSING COMMANDS ADDED
# ══════════════════════════════════════════════════════════

@bot.command(name="topinvites", aliases=["leaderboard", "lb"])
async def cmd_topinvites(ctx):
    """Top inviters leaderboard."""
    all_inv = inv_tbl.all()
    sorted_inv = sorted(all_inv, key=lambda x: x.get("valid", 0) + x.get("manual", 0) - x.get("leaves", 0), reverse=True)[:10]
    if not sorted_inv:
        return await ctx.send(embed=discord.Embed(description="No invite data yet!", color=0x2b2d31))
    lines = []
    medals = ["🥇","🥈","🥉"] + ["🏅"]*7
    for i, d in enumerate(sorted_inv):
        total = d.get("valid", 0) + d.get("manual", 0) - d.get("leaves", 0)
        lines.append(f"{medals[i]} <@{d['user_id']}> — **{total}** valid invites")
    e = discord.Embed(title="🏆 Top Inviters", description="\n".join(lines), color=0xfee75c)
    await ctx.send(embed=e)

@bot.command(name="renamevps")
@admin_only()
async def cmd_renamevps(ctx, target: discord.Member = None, *, new_label: str = None):
    """Rename VPS display label."""
    if not target or not new_label:
        return await ctx.send(embed=discord.Embed(description="❌ Usage: `!renamevps @user <new_label>`", color=0xed4245))
    records = vps_tbl.search(Q.owner_id == str(target.id))
    if not records:
        return await ctx.send(embed=discord.Embed(description="❌ No VPS found.", color=0xed4245))
    r = records[0]
    vps_tbl.update({"label": new_label}, Q.vps_id == r["vps_id"])
    await ctx.send(embed=discord.Embed(description=f"✅ VPS `{r['cname']}` labeled as `{new_label}`.", color=0x57f287))

@bot.command(name="vpsnote")
@admin_only()
async def cmd_vpsnote(ctx, target: discord.Member = None, *, note: str = None):
    """Add note to VPS."""
    if not target or not note:
        return await ctx.send(embed=discord.Embed(description="❌ Usage: `!vpsnote @user <note>`", color=0xed4245))
    records = vps_tbl.search(Q.owner_id == str(target.id))
    if not records:
        return await ctx.send(embed=discord.Embed(description="❌ No VPS found.", color=0xed4245))
    vps_tbl.update({"note": note}, Q.owner_id == str(target.id))
    await ctx.send(embed=discord.Embed(description=f"✅ Note saved for {target.mention}:\n> {note}", color=0x57f287))

@bot.command(name="dockerstats")
@admin_only()
async def cmd_dockerstats(ctx):
    """Live docker stats."""
    out, _, _ = await shell("docker stats --no-stream --format 'table {{.Name}}\\t{{.CPUPerc}}\\t{{.MemUsage}}\\t{{.NetIO}}'")
    await ctx.send(embed=discord.Embed(title="📊 Docker Stats", description=f"```\n{out[:3900] or 'No containers.'}\n```", color=0x2b2d31))

@bot.command(name="banlist")
@admin_only()
async def cmd_banlist(ctx):
    """List all bans."""
    bans = bans_tbl.all()
    if not bans:
        return await ctx.send(embed=discord.Embed(description="No users are banned.", color=0x2b2d31))
    lines = [f"<@{b['user_id']}> — `{b.get('reason','?')}` — by <@{b.get('banned_by','?')}>" for b in bans]
    await ctx.send(embed=discord.Embed(title=f"🚫 Banned Users ({len(bans)})", description="\n".join(lines), color=0xed4245))

@bot.command(name="warnings")
@admin_only()
async def cmd_warnings(ctx, target: discord.Member = None):
    """View user warnings."""
    if not target:
        return await ctx.send(embed=discord.Embed(description="❌ Usage: `!warnings @user`", color=0xed4245))
    w = warns_tbl.search(Q.user_id == str(target.id))
    if not w:
        return await ctx.send(embed=discord.Embed(description=f"{target.mention} has no warnings.", color=0x57f287))
    lines = [f"`{i+1}.` {x['reason']} — by <@{x['by']}> on `{x['at'][:10]}`" for i, x in enumerate(w)]
    await ctx.send(embed=discord.Embed(title=f"⚠️ Warnings for {target.display_name} ({len(w)})", description="\n".join(lines), color=0xfee75c))

@bot.command(name="clearwarnings")
@admin_only()
async def cmd_clearwarnings(ctx, target: discord.Member = None):
    """Clear user warnings."""
    if not target:
        return await ctx.send(embed=discord.Embed(description="❌ Usage: `!clearwarnings @user`", color=0xed4245))
    warns_tbl.remove(Q.user_id == str(target.id))
    await ctx.send(embed=discord.Embed(description=f"✅ All warnings cleared for {target.mention}.", color=0x57f287))

@bot.command(name="addtoticket")
@admin_only()
async def cmd_addtoticket(ctx, target: discord.Member = None):
    """Add user to current ticket."""
    if not target:
        return await ctx.send(embed=discord.Embed(description="❌ Usage: `!addtoticket @user`", color=0xed4245))
    await ctx.channel.set_permissions(target, read_messages=True, send_messages=True)
    await ctx.send(embed=discord.Embed(description=f"✅ {target.mention} added to ticket.", color=0x57f287))

@bot.command(name="removeuser")
@admin_only()
async def cmd_removeuser(ctx, target: discord.Member = None):
    """Remove user from ticket."""
    if not target:
        return await ctx.send(embed=discord.Embed(description="❌ Usage: `!removeuser @user`", color=0xed4245))
    await ctx.channel.set_permissions(target, overwrite=None)
    await ctx.send(embed=discord.Embed(description=f"✅ {target.mention} removed from ticket.", color=0x57f287))

@bot.command(name="setlogs")
@admin_only()
async def cmd_setlogs(ctx, channel: discord.TextChannel = None):
    """Set log channel."""
    if not channel:
        return await ctx.send(embed=discord.Embed(description="❌ Usage: `!setlogs #channel`", color=0xed4245))
    upd_guild_cfg(ctx.guild.id, {"log_channel": str(channel.id)})
    await ctx.send(embed=discord.Embed(description=f"✅ Log channel set to {channel.mention}", color=0x57f287))

@bot.command(name="setticket")
@admin_only()
async def cmd_setticket(ctx, channel: discord.TextChannel = None):
    """Set ticket channel."""
    if not channel:
        return await ctx.send(embed=discord.Embed(description="❌ Usage: `!setticket #channel`", color=0xed4245))
    upd_guild_cfg(ctx.guild.id, {"ticket_channel": str(channel.id)})
    await ctx.send(embed=discord.Embed(description=f"✅ Ticket channel set to {channel.mention}", color=0x57f287))

@bot.command(name="setannounce")
@admin_only()
async def cmd_setannounce(ctx, channel: discord.TextChannel = None):
    """Set announcement channel."""
    if not channel:
        return await ctx.send(embed=discord.Embed(description="❌ Usage: `!setannounce #channel`", color=0xed4245))
    upd_guild_cfg(ctx.guild.id, {"announce_channel": str(channel.id)})
    await ctx.send(embed=discord.Embed(description=f"✅ Announcement channel set to {channel.mention}", color=0x57f287))

@bot.command(name="maintenance")
@admin_only()
async def cmd_maintenance(ctx, mode: str = None):
    """Toggle maintenance mode."""
    if mode not in ("on", "off"):
        return await ctx.send(embed=discord.Embed(description="❌ Usage: `!maintenance on` or `!maintenance off`", color=0xed4245))
    upd_guild_cfg(ctx.guild.id, {"maintenance": mode == "on"})
    color = 0xfee75c if mode == "on" else 0x57f287
    await ctx.send(embed=discord.Embed(description=f"🔧 Maintenance mode: **{'ON' if mode=='on' else 'OFF'}**", color=color))

@bot.command(name="shutdown")
@admin_only()
async def cmd_shutdown(ctx):
    """Stop all user VPS."""
    def chk(m): return m.author == ctx.author and m.channel == ctx.channel
    await ctx.send(embed=discord.Embed(title="⚠️ Confirm Shutdown", description="Type `confirm` to stop all user VPS!", color=0xfee75c))
    try:
        m = await bot.wait_for("message", check=chk, timeout=30)
        if m.content.lower() != "confirm":
            return await ctx.send(embed=discord.Embed(description="❌ Cancelled.", color=0x2b2d31))
    except asyncio.TimeoutError:
        return await ctx.send(embed=discord.Embed(description="⏱ Cancelled.", color=0x2b2d31))
    upd_guild_cfg(ctx.guild.id, {"free_enabled": False})
    all_vps = vps_tbl.search(Q.tier != "admin")
    stopped = 0
    for r in all_vps:
        await shell(f"docker stop {r['cname']}")
        stopped += 1
    await ctx.send(embed=discord.Embed(description=f"🔴 Shutdown complete. Stopped `{stopped}` VPS.", color=0xed4245))
    await log(ctx.guild, "🔴 System Shutdown", f"**Admin:** {ctx.author.mention}\n**VPS Stopped:** {stopped}", 0xed4245)

@bot.command(name="resume")
@admin_only()
async def cmd_resume(ctx):
    """Start all VPS."""
    upd_guild_cfg(ctx.guild.id, {"free_enabled": True})
    all_vps = vps_tbl.search(Q.tier != "admin")
    started = 0
    for r in all_vps:
        await shell(f"docker start {r['cname']}")
        started += 1
    await ctx.send(embed=discord.Embed(description=f"🟢 Resumed. Started `{started}` VPS.", color=0x57f287))
    await log(ctx.guild, "🟢 System Resumed", f"**Admin:** {ctx.author.mention}\n**VPS Started:** {started}", 0x57f287)

@bot.command(name="enablefree")
@admin_only()
async def cmd_enablefree(ctx):
    """Enable free tier."""
    upd_guild_cfg(ctx.guild.id, {"free_enabled": True})
    await ctx.send(embed=discord.Embed(description="✅ Free VPS tier **enabled**.", color=0x57f287))

@bot.command(name="disablefree")
@admin_only()
async def cmd_disablefree(ctx):
    """Disable free tier."""
    upd_guild_cfg(ctx.guild.id, {"free_enabled": False})
    await ctx.send(embed=discord.Embed(description="🚫 Free VPS tier **disabled**.", color=0xed4245))

@bot.command(name="changenormal")
@admin_only()
async def cmd_changenormal(ctx, vps_type: str = None):
    """Set default VPS type label."""
    if vps_type not in ("lxc", "docker"):
        return await ctx.send(embed=discord.Embed(description="❌ Usage: `!changenormal lxc` or `!changenormal docker`", color=0xed4245))
    upd_guild_cfg(ctx.guild.id, {"vps_type": vps_type})
    await ctx.send(embed=discord.Embed(description=f"✅ Default VPS type set to **{vps_type.upper()}**.", color=0x57f287))

@bot.command(name="botcustom")
@admin_only()
async def cmd_botcustom(ctx):
    """Customize bot status."""
    def chk(m): return m.author == ctx.author and m.channel == ctx.channel
    async def ask(prompt):
        await ctx.send(embed=discord.Embed(description=prompt, color=0x5865f2))
        try:
            m = await bot.wait_for("message", check=chk, timeout=60)
            return m.content.strip()
        except asyncio.TimeoutError:
            return None
    status_txt = await ask("**Bot Status Text**\nEnter new status (or `skip`):")
    if status_txt and status_txt.lower() != "skip":
        await bot.change_presence(activity=discord.Activity(type=discord.ActivityType.watching, name=status_txt), status=discord.Status.online)
    status_type = await ask("**Status Type**\nType: `online` `idle` `dnd` `invisible`:")
    if status_type:
        mapping = {"online": discord.Status.online, "idle": discord.Status.idle, "dnd": discord.Status.dnd, "invisible": discord.Status.invisible}
        st = mapping.get(status_type.lower(), discord.Status.online)
        await bot.change_presence(status=st)
    await ctx.send(embed=discord.Embed(description="✅ Bot appearance updated!", color=0x57f287))

@bot.command(name="restorebackup")
@admin_only()
async def cmd_restorebackup(ctx, filename: str = None):
    """Restore DB backup."""
    if not filename:
        files = sorted(glob.glob("backups/*.json"))[-20:]
        names = "\n".join(f"`{os.path.basename(f)}`" for f in files)
        return await ctx.send(embed=discord.Embed(title="💾 Available Backups", description=names or "No backups found.", color=0x2b2d31))
    src = f"backups/{filename}"
    if not os.path.exists(src):
        return await ctx.send(embed=discord.Embed(description="❌ File not found.", color=0xed4245))
    table = filename.split("-")[0]
    dst = f"data/{table}.json"
    shutil.copy2(src, dst)
    await ctx.send(embed=discord.Embed(description=f"✅ Restored `{filename}` → `{dst}`.\n⚠️ Restart bot for full effect.", color=0x57f287))

@bot.command(name="serverinfo")
@admin_only()
async def cmd_serverinfo(ctx):
    """Discord server info."""
    g = ctx.guild
    e = discord.Embed(title=f"📊 {g.name}", color=0x5865f2)
    e.set_thumbnail(url=g.icon.url if g.icon else None)
    e.add_field(name="Owner", value=g.owner.mention if g.owner else "?", inline=True)
    e.add_field(name="Members", value=str(g.member_count), inline=True)
    e.add_field(name="Channels", value=str(len(g.channels)), inline=True)
    e.add_field(name="Roles", value=str(len(g.roles)), inline=True)
    e.add_field(name="Boost", value=str(g.premium_subscription_count), inline=True)
    e.add_field(name="Created", value=g.created_at.strftime("%Y-%m-%d"), inline=True)
    await ctx.send(embed=e)

@bot.command(name="limits")
@admin_only()
async def cmd_limits(ctx, target: discord.Member = None, n: int = None):
    """Set user VPS limit."""
    if not target:
        return await ctx.send(embed=discord.Embed(description="❌ Usage: `!limits @user [max_vps]`", color=0xed4245))
    if n is None:
        rec = settings_tbl.get((Q.type == "limit") & (Q.user_id == str(target.id)))
        cur = rec["limit"] if rec else 1
        return await ctx.send(embed=discord.Embed(description=f"📊 {target.mention} VPS limit: **{cur}**", color=0x2b2d31))
    settings_tbl.upsert({"type": "limit", "user_id": str(target.id), "limit": n}, (Q.type == "limit") & (Q.user_id == str(target.id)))
    await ctx.send(embed=discord.Embed(description=f"✅ VPS limit for {target.mention} set to **{n}**.", color=0x57f287))

@bot.command(name="setminage")
@admin_only()
async def cmd_setminage(ctx, days: int = None):
    """Set min account age for valid invites."""
    if days is None:
        return await ctx.send(embed=discord.Embed(description="❌ Usage: `!setminage <days>`", color=0xed4245))
    config.MIN_ACCOUNT_AGE_DAYS = days
    await ctx.send(embed=discord.Embed(description=f"✅ Min account age set to **{days} days**.", color=0x57f287))

# ══════════════════════════════════════════════════════════
#  START BOT
# ══════════════════════════════════════════════════════════
if __name__ == "__main__":
    print("Starting Ghost VPS Bot MEGA v2.0...")
    bot.run(config.TOKEN)
