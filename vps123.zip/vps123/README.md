# 🐳 Ghost VPS Bot — Docker Edition

A full-featured Discord bot to manage Docker VPS containers — create, give, control and monitor VPS containers right from Discord.

---

## 📥 Installation

### Step 1 — Upload files to your server
```bash
git clone <your-repo>  # or upload manually via SFTP
cd ghostvps_bot
```

### Step 2 — Run the installer (installs Docker + Python packages)
```bash
sudo bash install.sh
```

### Step 3 — Configure the bot
Edit `config.py`:
```python
TOKEN     = "YOUR_BOT_TOKEN"      # From discord.com/developers
ADMIN_IDS = [YOUR_DISCORD_ID]     # Right-click → Copy ID
```

### Step 4 — Run the bot
```bash
python3 bot.py

# Or in background with screen:
screen -S ghostbot python3 bot.py
# Detach: Ctrl+A then D
# Reattach: screen -r ghostbot
```

### Step 5 — In Discord
1. Type `!setup` to configure channels
2. Type `!installcheck` to verify Docker is ready
3. Type `!ticketpanel` in your tickets channel to post the button
4. Use `!help` to see all commands

---

## 🗂 File Structure
```
ghostvps_bot/
├── bot.py           ← Main bot (run this)
├── config.py        ← Edit your token + settings here
├── requirements.txt ← Python dependencies
├── install.sh       ← Installs Docker + deps
├── data/            ← Auto-created databases
│   ├── vps.json
│   ├── invites.json
│   ├── bans.json
│   ├── tickets.json
│   └── ...
└── backups/         ← Auto database backups (every 6h)
```

---

## 👤 User Commands (Everyone)
| Command | Description |
|---|---|
| `!status` | Check your VPS status |
| `!sshx [id]` | Get SSHX web terminal link (via DM) |
| `!tmate [id]` | Get tmate SSH link (via DM) |
| `!invites [@user]` | View invite stats |
| `!topinvites` | Top inviters leaderboard |
| `!tiers` | View VPS invite reward tiers |
| `!ping` | Bot latency |
| `!botinfo` | Bot information |
| `!uptime` | Bot uptime |

---

## 🔑 Admin Commands
| Command | Description |
|---|---|
| `!createvps` | Create a Docker VPS for yourself (wizard) |
| `!givevps @user` | Give a Docker VPS to a user (wizard) |
| `!deletemyvps [id]` | Delete your VPS |
| `!deletesomeonevps @user` | Delete a user's VPS |
| `!startvps @user` | Start user VPS |
| `!stopvps @user` | Stop user VPS |
| `!restartvps @user` | Restart user VPS |
| `!rebuildvps @user` | Wipe & rebuild VPS |
| `!execvps @user <cmd>` | Run command in container |
| `!listvps` | List all VPS with status |
| `!listall` | Full database VPS list |
| `!lookup @user` | User's VPS list |
| `!vpsinfo <id>` | Detailed VPS info |
| `!node` | Node resource usage |
| `!dockerps` | Raw docker ps output |
| `!dockerstats` | Live docker stats |
| `!ban @user [reason]` | Ban user (removes all VPS) |
| `!unban @user [reason]` | Unban user |
| `!banlist` | View all bans |
| `!suspend @user` | Suspend user (stops VPS) |
| `!unsuspend @user` | Unsuspend user |
| `!warn @user [reason]` | Warn a user |
| `!warnings @user` | View user warnings |
| `!clearwarnings @user` | Clear warnings |
| `!addinvites @user <n>` | Add manual invites |
| `!removeinvites @user <n>` | Remove invites |
| `!resetinvites @user` | Reset invites |
| `!all <message>` | Announce to all VPS owners |
| `!shutdown` | Stop all user VPS + disable free |
| `!resume` | Restart all VPS + enable free |
| `!installcheck` | Check Docker status |
| `!setup` | First-time setup wizard |
| `!ticketpanel` | Post the ticket button |
| `!setprefix <p>` | Change prefix |
| `!setlogs #ch` | Set log channel |
| `!setticket #ch` | Set ticket channel |
| `!setannounce #ch` | Set announce channel |
| `!botcustom` | Edit bot status |
| `!backup` | Manual DB backup |
| `!wipeall` | Factory reset |

---

## 🎫 Ticket System
- Post `!ticketpanel` in your support channel
- Users click **Open Ticket** → private channel created
- Admin panel auto-appears: **Lock / Unlock / Claim / Delete**
- Invite reward VPS is auto-delivered inside the ticket

---

## 🐳 How VPS Creation Works
1. Admin runs `!createvps` or `!givevps @user`
2. Bot asks: OS → RAM → CPUs → Storage → Name
3. Bot runs `docker run` with those specs
4. Inside the container: installs `tmate` + `sshx`
5. Bot sends **tmate SSH** and **SSHX web** links to DM
6. DM includes a **control panel** with Start/Stop/Restart/Refresh/SSHX/tmate buttons

---

## 📨 Invite Reward System
- Users invite friends → bot tracks via Discord invite API
- Anti-fake: checks account age + profile picture
- When user reaches an invite threshold → DM notification + `pending_vps = true`
- User opens a ticket → bot auto-delivers the VPS inside the ticket
