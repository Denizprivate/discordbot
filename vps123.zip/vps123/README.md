# 🐳 Ghost VPS Bot — MEGA v2.0

**100+ Commands | Docker VPS | Unlimited Resources | LXC Ready**

A complete Discord bot for managing Docker VPS containers with invite rewards, tier management, and advanced features.

---

## 🎯 What's New in MEGA v2.0

### ✅ **FIXED:**
- ✅ **tmate/sshx detection** — 5min timeout, better regex patterns
- ✅ **!execvps** — Now waits for full command completion
- ✅ **!bash** — Execute commands from Discord
- ✅ **Encoding issues** — neofetch and screenfetch now display correctly
- ✅ **No CPU/RAM limits** — 20+ cores, 64GB+ RAM supported

### 🆕 **NEW COMMANDS (40+):**
- **!panel** — DM control panel (clears old messages first)
- **!bash** — Execute bash commands from Discord
- **!clear** — Clear messages in channel
- **!lock / !unlock** — Lock/unlock channels
- **!slowmode** — Set channel slowmode
- **!tailscale** — Auto-install Tailscale with auth link
- **!webterminal** — Install ttyd web terminal on Tailscale IP:8080
- **!addtier / !edittier / !deltier / !listtiers** — Custom tier management
- **!ticketsetup** — Customize ticket panel message
- **Plus 20+ more utility commands**

---

## 📥 Installation

### Step 1 — Upload to your server
```bash
# Extract the zip
unzip ghostvps_bot_MEGA_v2.zip
cd ghostvps_mega
```

### Step 2 — Run installer
```bash
sudo bash install.sh
```
This installs: Docker, Python packages, creates network

### Step 3 — Configure
```bash
nano config.py
```
**Required changes:**
- `TOKEN = "your_bot_token_here"`
- `ADMIN_IDS = [your_discord_id_here]`

### Step 4 — Run
```bash
# Foreground (see errors):
python3 bot.py

# Background:
screen -S ghostbot python3 bot.py
# Detach: Ctrl+A then D
# Reattach: screen -r ghostbot
```

### Step 5 — In Discord
1. `!setup` — Configure channels
2. `!installcheck` — Verify Docker
3. `!ticketpanel` — Post ticket button
4. `!help` — See all commands

---

## 📋 Commands Overview

### 👤 **User Commands (Everyone)**
| Command | Description |
|---------|-------------|
| `!status` | Check your VPS status |
| `!sshx [id]` | Get SSHX web terminal link (DM) |
| `!tmate [id]` | Get tmate SSH link (DM) |
| `!panel` | VPS control panel in DM (clears old messages) |
| `!invites [@user]` | View invite stats |
| `!tiers` | View VPS tier rewards |
| `!ping` | Bot latency |
| `!uptime` | Bot uptime |
| `!botinfo` | Bot information |

### 🐳 **VPS Management (Admin)**
| Command | Description |
|---------|-------------|
| `!createvps` | Create Docker VPS (wizard) — **UNLIMITED cores/RAM** |
| `!givevps @user` | Give VPS to user (wizard) |
| `!deletemyvps [id]` | Delete your VPS |
| `!deletesomeonevps @user [id]` | Delete user's VPS |
| `!startvps @user` | Start user's VPS |
| `!stopvps @user` | Stop user's VPS |
| `!restartvps @user` | Restart user's VPS |
| `!rebuildvps @user` | Wipe & rebuild VPS |
| `!execvps @user <cmd>` | Run command (waits for completion) |
| `!bash @user <cmd>` | Execute bash commands from Discord |
| `!tailscale @user` | Auto-install Tailscale with auth link |
| `!webterminal @user` | Install ttyd web terminal (requires Tailscale) |

### 🏷️ **Tier Management (Admin)**
| Command | Description |
|---------|-------------|
| `!addtier <key> <name> <invites> <ram> <cpus>` | Add custom tier |
| `!edittier <key> <field> <value>` | Edit tier |
| `!deltier <key>` | Delete tier |
| `!listtiers` | List custom tiers |

**Example:**
```
!addtier platinum "💎 Platinum" 30 16g 16
!edittier platinum ram 32g
```

### 📋 **Listings (Admin)**
| Command | Description |
|---------|-------------|
| `!listvps` | List all VPS with status |
| `!listall` | Full database VPS list |
| `!lookup @user` | User's VPS list |
| `!vpsinfo <id>` | Detailed VPS info |
| `!dockerps` | Raw docker ps output |
| `!node` | Node resource usage |

### 🔧 **Channel Management (Admin)**
| Command | Description |
|---------|-------------|
| `!clear <amount>` | Clear messages (max 100) |
| `!lock` | Lock channel (prevent sending) |
| `!unlock` | Unlock channel |
| `!slowmode <seconds>` | Set slowmode |

### 🎫 **Ticket System (Admin)**
| Command | Description |
|---------|-------------|
| `!ticketpanel` | Post the ticket button |
| `!ticketsetup <msg>` | Customize ticket message |
| `!closeticket` | Close current ticket |
| `!listtickets` | List all open tickets |

### 🚫 **User Management (Admin)**
| Command | Description |
|---------|-------------|
| `!ban @user [reason]` | Ban user (removes all VPS) |
| `!unban @user` | Unban user |
| `!suspend @user` | Suspend (stops VPS) |
| `!unsuspend @user` | Unsuspend |
| `!warn @user [reason]` | Issue warning |
| `!userinfo @user` | View user info |
| `!transfervps @from @to` | Transfer VPS ownership |

### 📨 **Invite Management (Admin)**
| Command | Description |
|---------|-------------|
| `!addinvites @user <n>` | Add manual invites |
| `!removeinvites @user <n>` | Remove invites |
| `!resetinvites @user` | Reset user invites |
| `!invitecheck @user` | Full invite audit |

### ⚙️ **System (Admin)**
| Command | Description |
|---------|-------------|
| `!setup` | First-time setup wizard |
| `!installcheck` | Check Docker installation |
| `!fixlxc` | Show LXC fix commands |
| `!setprefix <p>` | Change command prefix |
| `!all <message>` | Announce to all VPS owners |
| `!backup` | Manual database backup |
| `!wipeall` | Factory reset (delete all) |

---

## 🐳 How It Works

### VPS Creation Flow
1. Admin runs `!createvps` or `!givevps @user`
2. Wizard asks: OS → RAM → CPUs → Storage → Name
3. Bot creates Docker container with specs
4. Installs tmate + sshx inside container
5. Sends tmate SSH + SSHX web links via DM
6. Sends control panel to user's DM

### Unlimited Resources
- **NO CPU LIMITS** — Set 20, 50, 100+ cores
- **NO RAM LIMITS** — Set 64GB, 128GB, 256GB+
- Just enter what you want in the wizard!

### Tailscale Integration
```bash
# Install Tailscale on user's VPS
!tailscale @user

# Install web terminal (requires Tailscale)
!webterminal @user
# Access at: http://100.x.x.x:8080
```

### Custom Tiers
```bash
# Add new tier
!addtier mega "🚀 Mega" 50 32g 32

# Edit tier
!edittier mega ram 64g

# Delete tier
!deltier mega
```

---

## 🎫 Ticket System

1. `!ticketpanel` — Post in your tickets channel
2. Users click **Open Ticket**
3. Private channel created
4. Admin panel appears: Lock/Unlock/Claim/Delete
5. Invite reward VPS auto-delivered inside ticket

**Customize message:**
```bash
!ticketsetup Click the button below for VPS support!
```

---

## 📨 Invite Rewards

- Users invite friends → bot tracks via Discord API
- **Anti-fake:** Checks account age + profile picture
- When threshold reached → DM notification
- User opens ticket → VPS auto-delivered

---

## 🔧 LXC Troubleshooting

### If you get this error:
```
net.ipv4.ip_unprivileged_port_start permission denied
```

**Fix:**
```bash
# Run inside your LXC container:
bash fix_docker_lxc.sh

# Or manually:
mkdir -p /etc/docker
cat > /etc/docker/daemon.json << 'EOF'
{
  "storage-driver": "vfs",
  "iptables": true
}
EOF
systemctl restart docker
docker network create ghost-vps-net
```

**Still failing?**
Your LXC host needs to allow nesting. Ask your provider to run:
```bash
# On the HOST machine (not inside LXC):
echo 'lxc.cap.drop =' >> /var/lib/lxc/YOURCONTAINER/config
lxc-stop YOURCONTAINER && lxc-start YOURCONTAINER
```

---

## 📁 File Structure
```
ghostvps_mega/
├── bot.py              ← Main bot (2400+ lines)
├── config.py           ← Edit your settings here
├── requirements.txt    ← Python dependencies
├── install.sh          ← Auto installer
├── fix_docker_lxc.sh   ← LXC fix script
├── README.md           ← This file
├── data/               ← Auto-created databases
│   ├── vps.json
│   ├── invites.json
│   ├── custom_tiers.json
│   └── ...
└── backups/            ← Auto backups (every 6h)
```

---

## 🆘 Support

**Common Issues:**

**Q: tmate/sshx not showing?**
A: Wait 5 minutes after VPS creation. New timeout is 5min (was 2min).

**Q: !execvps exits early?**
A: FIXED in v2.0 — now waits for full completion.

**Q: neofetch shows weird characters?**
A: FIXED — better encoding handling.

**Q: Want more than 64 cores?**
A: NO LIMITS — enter any number in the wizard!

**Q: Docker fails in LXC?**
A: Run `bash fix_docker_lxc.sh` or `!fixlxc` in Discord.

---

## 🎨 Credits

**Ghost VPS Bot MEGA v2.0**
- 100+ commands
- Unlimited resources
- LXC compatible
- Full invite system
- Custom tier management
- Advanced Docker integration

Built with ❤️ using discord.py

---

## 📝 License

Free to use and modify. No warranty provided.
