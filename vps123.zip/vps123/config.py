# ╔══════════════════════════════════════════════════════╗
# ║   GHOST VPS BOT MEGA v2.0 — CONFIGURATION           ║
# ║   Edit this file BEFORE running: python3 bot.py     ║
# ╚══════════════════════════════════════════════════════╝

# ─── BOT SETTINGS ──────────────────────────────────────────
TOKEN  = "YOUR_BOT_TOKEN_HERE"   # discord.com/developers/applications
PREFIX = "!"

# Your Discord User ID(s) — Right-click your name → Copy ID
ADMIN_IDS = [
    123456789012345678,   # ← Replace with your real Discord ID
    # 999888777666555444, # Add more admins here
]

# ─── CHANNELS (optional - set via !setup or paste IDs) ────
LOG_CHANNEL      = None   # Admin log channel ID (int or None)
ANNOUNCE_CHANNEL = None   # Announcement channel ID (int or None)
TICKET_CHANNEL   = None   # Category/channel where tickets are created

# ─── ANTI-FAKE INVITE PROTECTION ───────────────────────────
MIN_ACCOUNT_AGE_DAYS = 30    # Account must be this many days old
REQUIRE_AVATAR       = True  # Invited user must have a profile pic

# ─── INVITE REWARD TIERS ───────────────────────────────────
# UNLIMITED RAM + CPU — set whatever you want!
TIERS = {
    "free": {
        "name":    "🆓 Free",
        "invites": 0,
        "ram":     "512m",
        "cpus":    "1",
        "storage": "5GB",
        "image":   "ubuntu:24.04",
    },
    "bronze": {
        "name":    "🥉 Bronze",
        "invites": 3,
        "ram":     "1g",
        "cpus":    "2",
        "storage": "10GB",
        "image":   "ubuntu:24.04",
    },
    "silver": {
        "name":    "🥈 Silver",
        "invites": 6,
        "ram":     "2g",
        "cpus":    "4",
        "storage": "20GB",
        "image":   "ubuntu:24.04",
    },
    "gold": {
        "name":    "🥇 Gold",
        "invites": 10,
        "ram":     "4g",
        "cpus":    "8",
        "storage": "40GB",
        "image":   "ubuntu:24.04",
    },
    "diamond": {
        "name":    "💎 Diamond",
        "invites": 20,
        "ram":     "16g",
        "cpus":    "20",
        "storage": "100GB",
        "image":   "ubuntu:24.04",
    },
}

# ─── DOCKER DEFAULTS ───────────────────────────────────────
DOCKER_NETWORK = "ghost-vps-net"
DOCKER_RESTART = "unless-stopped"

# Supported OS images (shown in !createvps wizard)
OS_OPTIONS = [
    "ubuntu:24.04",
    "ubuntu:22.04",
    "ubuntu:20.04",
    "debian:12",
    "debian:11",
    "alpine:3.19",
    "centos:7",
    "fedora:40",
    "kalilinux/kali-rolling",
    "archlinux",
    "rockylinux:9",
]
