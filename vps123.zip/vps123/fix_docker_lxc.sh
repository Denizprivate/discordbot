#!/bin/bash
# ╔══════════════════════════════════════════════════════╗
# ║     GHOST VPS BOT — Docker LXC Fix Script           ║
# ║  Fixes: net.ipv4.ip_unprivileged_port_start error   ║
# ║  Run as root inside your LXC container              ║
# ╚══════════════════════════════════════════════════════╝

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'

echo -e "${YELLOW}[1/4] Writing Docker daemon config for LXC...${NC}"
mkdir -p /etc/docker
cat > /etc/docker/daemon.json << 'EOF'
{
  "storage-driver": "vfs",
  "iptables": true,
  "log-driver": "json-file",
  "log-opts": { "max-size": "10m", "max-file": "3" }
}
EOF
echo -e "  ${GREEN}Done — using vfs storage driver (LXC compatible)${NC}"

echo -e "${YELLOW}[2/4] Restarting Docker daemon...${NC}"
systemctl restart docker 2>/dev/null || service docker restart 2>/dev/null || {
    echo -e "${RED}Could not restart Docker. Try: service docker restart${NC}"
    exit 1
}
sleep 3

echo -e "${YELLOW}[3/4] Recreating ghost-vps-net network...${NC}"
docker network rm ghost-vps-net 2>/dev/null || true
docker network create ghost-vps-net
echo -e "  ${GREEN}Network ready${NC}"

echo -e "${YELLOW}[4/4] Testing privileged container...${NC}"
if docker run --rm --privileged --network host ubuntu:24.04 echo "✅ Works!" 2>/dev/null; then
    echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${GREEN}  ✅ All fixed! Start the bot:           ${NC}"
    echo -e "${GREEN}     python3 bot.py                       ${NC}"
    echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
else
    echo -e "${RED}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${RED}  ❌ Still failing.                                        ${NC}"
    echo -e "${RED}  Your LXC needs nesting enabled by the host.             ${NC}"
    echo -e "${RED}                                                           ${NC}"
    echo -e "${RED}  Ask your provider to run on the HOST machine:           ${NC}"
    echo -e "${YELLOW}  echo 'lxc.cap.drop =' >> /var/lib/lxc/YOURCNAME/config  ${NC}"
    echo -e "${YELLOW}  lxc-stop YOURCNAME && lxc-start YOURCNAME               ${NC}"
    echo -e "${RED}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
fi
