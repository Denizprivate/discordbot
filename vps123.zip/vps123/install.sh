#!/bin/bash
# ╔══════════════════════════════════════════════════════╗
# ║         GHOST VPS BOT — INSTALL SCRIPT              ║
# ╚══════════════════════════════════════════════════════╝

set -e
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'

echo -e "${BLUE}"
echo "  ██████╗ ██╗  ██╗ ██████╗ ███████╗████████╗"
echo "  ██╔════╝ ██║  ██║██╔═══██╗██╔════╝╚══██╔══╝"
echo "  ██║  ███╗███████║██║   ██║███████╗   ██║   "
echo "  ██║   ██║██╔══██║██║   ██║╚════██║   ██║   "
echo "  ╚██████╔╝██║  ██║╚██████╔╝███████║   ██║   "
echo "   ╚═════╝ ╚═╝  ╚═╝ ╚═════╝ ╚══════╝   ╚═╝   "
echo "             VPS BOT — Install Script"
echo -e "${NC}"

echo -e "${YELLOW}[1/6] Checking system...${NC}"
if [ "$EUID" -ne 0 ]; then
    echo -e "${RED}Please run as root: sudo bash install.sh${NC}"
    exit 1
fi

OS=$(lsb_release -si 2>/dev/null || echo "Unknown")
echo -e "  OS Detected: ${GREEN}$OS${NC}"

echo -e "${YELLOW}[2/6] Updating packages...${NC}"
apt-get update -qq

echo -e "${YELLOW}[3/6] Installing dependencies...${NC}"
apt-get install -y -qq \
    curl wget git python3 python3-pip python3-venv \
    ca-certificates gnupg lsb-release tmate screen htop

echo -e "${YELLOW}[4/6] Installing Docker...${NC}"
if command -v docker &>/dev/null; then
    echo -e "  ${GREEN}Docker already installed: $(docker --version)${NC}"
else
    install -m 0755 -d /etc/apt/keyrings
    curl -fsSL https://download.docker.com/linux/ubuntu/gpg | \
        gpg --dearmor -o /etc/apt/keyrings/docker.gpg
    chmod a+r /etc/apt/keyrings/docker.gpg
    echo \
      "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] \
      https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" | \
      tee /etc/apt/sources.list.d/docker.list > /dev/null
    apt-get update -qq
    apt-get install -y -qq docker-ce docker-ce-cli containerd.io
    systemctl enable --now docker
    echo -e "  ${GREEN}Docker installed: $(docker --version)${NC}"
fi

echo -e "${YELLOW}[5/6] Creating Docker network for VPS containers...${NC}"
docker network create ghost-vps-net 2>/dev/null || echo -e "  ${GREEN}Network already exists${NC}"

echo -e "${YELLOW}[6/6] Installing Python packages...${NC}"
pip3 install -r requirements.txt --break-system-packages -q

echo ""
echo -e "${GREEN}╔══════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║        Installation Complete! ✅             ║${NC}"
echo -e "${GREEN}╠══════════════════════════════════════════════╣${NC}"
echo -e "${GREEN}║  Next steps:                                  ║${NC}"
echo -e "${GREEN}║  1. Edit config.py with your bot token        ║${NC}"
echo -e "${GREEN}║  2. Set your Discord ID in ADMIN_IDS          ║${NC}"
echo -e "${GREEN}║  3. Run: python3 bot.py                       ║${NC}"
echo -e "${GREEN}║                                               ║${NC}"
echo -e "${GREEN}║  To run in background:                        ║${NC}"
echo -e "${GREEN}║     screen -S ghostbot python3 bot.py         ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════════╝${NC}"
